// Re-export Firebase objects from the index file for backward compatibility
import { auth, db, storage } from './index';

export { auth, db, storage };
export default { auth, db, storage }; 