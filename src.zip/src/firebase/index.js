// Firebase configuration
import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDJEXBp5GGKAiUxxCRJzuBTDr_jFBGG1LU",
  authDomain: "bookmyspot-a8653.firebaseapp.com",
  projectId: "bookmyspot-a8653",
  storageBucket: "bookmyspot-a8653.appspot.com",
  messagingSenderId: "953078792435",
  appId: "1:953078792435:web:5cc8bd7e465dcf2ef94a27"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);
const storage = getStorage(app);

export { auth, db, storage };
export default app; 