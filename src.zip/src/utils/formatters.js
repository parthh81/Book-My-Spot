/**
 * Utility functions for formatting dates and currency
 */

/**
 * Formats a date string to a more readable format
 * @param {string} dateString - ISO date string to format
 * @param {boolean} includeTime - Whether to include the time in the formatted string
 * @return {string} Formatted date string
 */
export const formatDate = (dateString, includeTime = false) => {
  if (!dateString) return '';
  
  const date = new Date(dateString);
  
  // Format options
  const options = { 
    day: 'numeric', 
    month: 'short', 
    year: 'numeric'
  };
  
  if (includeTime) {
    options.hour = '2-digit';
    options.minute = '2-digit';
  }
  
  return date.toLocaleDateString('en-IN', options);
};

/**
 * Formats a number as Indian currency
 * @param {number} amount - Amount to format
 * @param {boolean} abbreviated - Whether to abbreviate large numbers (e.g., 10K, 1.5L)
 * @return {string} Formatted currency string without the symbol
 */
export const formatCurrency = (amount, abbreviated = false) => {
  if (amount === null || amount === undefined) return '';
  
  if (abbreviated) {
    if (amount >= 10000000) {
      return (amount / 10000000).toFixed(1) + 'Cr';
    } else if (amount >= 100000) {
      return (amount / 100000).toFixed(1) + 'L';
    } else if (amount >= 1000) {
      return (amount / 1000).toFixed(1) + 'K';
    }
  }
  
  // Format with thousands separators for Indian numbering system
  return new Intl.NumberFormat('en-IN').format(amount);
};

/**
 * Formats percentage values
 * @param {number} value - Percentage value to format
 * @param {number} decimalPlaces - Number of decimal places to include
 * @return {string} Formatted percentage string
 */
export const formatPercentage = (value, decimalPlaces = 0) => {
  if (value === null || value === undefined) return '';
  return value.toFixed(decimalPlaces) + '%';
};

/**
 * Truncates text to a specified length and adds ellipsis if needed
 * @param {string} text - Text to truncate
 * @param {number} maxLength - Maximum length to allow
 * @return {string} Truncated text
 */
export const truncateText = (text, maxLength = 50) => {
  if (!text) return '';
  
  if (text.length <= maxLength) return text;
  return text.substring(0, maxLength) + '...';
}; 