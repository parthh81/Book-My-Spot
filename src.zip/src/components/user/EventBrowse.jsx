import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { FaCalendarAlt, FaStar, FaUsers, FaMapMarkerAlt, FaSearch, FaSyncAlt, FaSort } from 'react-icons/fa';
import EventService from '../../services/EventService';
import '../../styles/events.css';

// Fallback event categories if API fails
const fallbackEventCategories = [
  {
    id: 1,
    title: "Weddings",
    description: "Find the perfect venue for your special day",
    image: "https://images.pexels.com/photos/169198/pexels-photo-169198.jpeg?auto=compress&cs=tinysrgb&w=600&h=400",
    count: 120
  },
  {
    id: 2,
    title: "Corporate Events",
    description: "Professional venues for meetings and conferences",
    image: "https://images.pexels.com/photos/2774556/pexels-photo-2774556.jpeg?auto=compress&cs=tinysrgb&w=600&h=400",
    count: 85
  },
  {
    id: 3,
    title: "Birthday Parties",
    description: "Celebrate your birthday at exciting venues",
    image: "https://images.pexels.com/photos/587741/pexels-photo-587741.jpeg?auto=compress&cs=tinysrgb&w=600&h=400",
    count: 64
  },
  {
    id: 4,
    title: "Anniversary Celebrations",
    description: "Romantic venues for your special milestone",
    image: "https://images.pexels.com/photos/1024960/pexels-photo-1024960.jpeg?auto=compress&cs=tinysrgb&w=600&h=400",
    count: 42
  },
  {
    id: 5,
    title: "Family Gatherings",
    description: "Spacious venues for family get-togethers",
    image: "https://images.pexels.com/photos/3184183/pexels-photo-3184183.jpeg?auto=compress&cs=tinysrgb&w=600&h=400",
    count: 56
  },
  {
    id: 6,
    title: "Engagement Ceremonies",
    description: "Beautiful venues to celebrate your engagement",
    image: "https://images.pexels.com/photos/1456706/pexels-photo-1456706.jpeg?auto=compress&cs=tinysrgb&w=600&h=400",
    count: 38
  }
];

// Updated fallback events without name and date
const fallbackUpcomingEvents = [
  {
    id: 101,
    description: "Explore the latest wedding trends and meet top vendors",
    image: "https://images.pexels.com/photos/1456417/pexels-photo-1456417.jpeg?auto=compress&cs=tinysrgb&w=600&h=400",
    location: "Royal Grand Palace, Ahmedabad",
    category: "Wedding"
  },
  {
    id: 102,
    description: "Network with industry leaders and learn from experts",
    image: "https://images.pexels.com/photos/2774556/pexels-photo-2774556.jpeg?auto=compress&cs=tinysrgb&w=600&h=400",
    location: "Modern Event Center, Delhi",
    category: "Corporate"
  },
  {
    id: 103,
    description: "Celebrate diverse cultures with music, dance, and food",
    image: "https://images.pexels.com/photos/2263436/pexels-photo-2263436.jpeg?auto=compress&cs=tinysrgb&w=600&h=400",
    location: "Riverside Retreat, Mumbai",
    category: "Festival"
  }
];

const EventBrowse = () => {
  const navigate = useNavigate();
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedLocation, setSelectedLocation] = useState('All Locations');
  const [sortOrder, setSortOrder] = useState('Newest First');
  
  // Available locations
  const locations = [
    'All Locations',
    'Mumbai',
    'Delhi',
    'Bangalore',
    'Hyderabad',
    'Ahmedabad',
    'Chennai',
    'Kolkata',
    'Pune'
  ];

  // Sort options
  const sortOptions = [
    'Newest First',
    'Price: Low to High',
    'Price: High to Low',
    'Rating: High to Low'
  ];
  
  // Fetch events from API
  const fetchEventData = async () => {
    setLoading(true);
    setError(null);
    
    try {
      // Fetch all available events
      const eventsData = await EventService.getAllEvents();
      console.log('Fetched events from API:', eventsData);
      
      if (eventsData && eventsData.length > 0) {
        // Format the events data
        const formattedEvents = eventsData.map(event => ({
          id: event._id,
          title: event.name || event.eventType || event.category || 'Event',
          description: event.description || 'No description available',
          image: event.image || 'https://images.pexels.com/photos/2263436/pexels-photo-2263436.jpeg?auto=compress&cs=tinysrgb&w=600&h=400',
          location: event.location || 'TBD',
          city: event.location?.split(',').pop()?.trim() || 'Mumbai',
          date: event.date ? new Date(event.date) : new Date(),
          formattedDate: event.date ? new Date(event.date).toLocaleDateString() : 'Date TBD',
          category: event.category || event.eventType || 'Event',
          rating: (Math.random() * (5 - 4) + 4).toFixed(1), // Random rating between 4.0-5.0
          features: ["Catering", "Parking", "WiFi"].slice(0, Math.floor(Math.random() * 3) + 1), // Random 1-3 features
          capacity: `${event.capacity || 100}-${event.capacity ? event.capacity + 100 : 200} guests`, // Use actual capacity if available
          price: `₹${event.price || 30000} onwards` // Use actual price from backend
        }));
        setEvents(formattedEvents);
      } else {
        console.log('No events found from API');
        setEvents([]);
      }
    } catch (err) {
      console.error('Error fetching event data:', err);
      setError('Failed to load events. Please try again later.');
      setEvents([]);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };
  
  useEffect(() => {
    fetchEventData();
  }, []);
  
  // Handle refresh button click
  const handleRefresh = () => {
    setRefreshing(true);
    fetchEventData();
  };

  // Handle search input change
  const handleSearchChange = (e) => {
    setSearchTerm(e.target.value);
  };

  // Handle location change
  const handleLocationChange = (e) => {
    setSelectedLocation(e.target.value);
  };

  // Handle sort order change
  const handleSortChange = (e) => {
    setSortOrder(e.target.value);
  };
  
  // Filter events 
  const filteredEvents = events.filter(event => {
    // Filter by location
    const locationMatch = selectedLocation === 'All Locations' || 
                          event.city === selectedLocation || 
                          event.location.includes(selectedLocation);
    
    // Filter by search term
    const search = searchTerm.toLowerCase();
    const searchMatch = !searchTerm || 
                       (event.title && event.title.toLowerCase().includes(search)) ||
                       (event.description && event.description.toLowerCase().includes(search)) ||
                       (event.category && event.category.toLowerCase().includes(search));
    
    return locationMatch && searchMatch;
  });
  
  // Render loading state
  if (loading) {
    return (
      <div className="container py-5 text-center">
        <div className="spinner-border text-primary" role="status">
          <span className="visually-hidden">Loading events...</span>
        </div>
        <p className="mt-3">Loading available events...</p>
      </div>
    );
  }
  
  // Render error state
  if (error) {
    return (
      <div className="container py-5 text-center">
        <div className="alert alert-danger" role="alert">
          {error}
        </div>
        <button className="btn btn-primary" onClick={fetchEventData}>
          Try Again
        </button>
      </div>
    );
  }

  return (
    <div className="container-fluid py-4">
      {/* Browse Events header with refresh button */}
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2 className="m-0">Browse Events</h2>
        <button 
          className="btn btn-outline-primary d-flex align-items-center"
          onClick={handleRefresh}
          disabled={refreshing}
        >
          <FaSyncAlt className={`me-2 ${refreshing ? 'fa-spin' : ''}`} />
          Refresh Events
        </button>
      </div>
      
      {/* Search, location and filter section */}
      <div className="row g-3 mb-4">
        {/* Search input */}
        <div className="col-md-6">
          <div className="input-group">
            <span className="input-group-text bg-white">
              <FaSearch className="text-muted" />
            </span>
            <input
              type="text"
              className="form-control"
              placeholder="Search for events..."
              value={searchTerm}
              onChange={handleSearchChange}
            />
          </div>
        </div>
        
        {/* Location dropdown */}
        <div className="col-md-3">
          <div className="input-group">
            <span className="input-group-text bg-white">
              <FaMapMarkerAlt className="text-muted" />
            </span>
            <select 
              className="form-select"
              value={selectedLocation}
              onChange={handleLocationChange}
            >
              {locations.map((location, index) => (
                <option key={index} value={location}>{location}</option>
              ))}
            </select>
          </div>
        </div>
        
        {/* Sort dropdown */}
        <div className="col-md-3">
          <div className="input-group">
            <span className="input-group-text bg-white">
              <FaSort className="text-muted" />
            </span>
            <select 
              className="form-select"
              value={sortOrder}
              onChange={handleSortChange}
            >
              {sortOptions.map((option, index) => (
                <option key={index} value={option}>{option}</option>
              ))}
            </select>
          </div>
        </div>
      </div>
      
      {/* Events heading */}
      <h3 className="mb-4">Available Events ({filteredEvents.length})</h3>
      
      {/* Events cards */}
      {filteredEvents.length === 0 ? (
        <div className="text-center py-5">
          <FaCalendarAlt size={48} className="text-muted mb-3" />
          <h4>No events found</h4>
          <p className="text-muted">Try adjusting your search criteria or check back later.</p>
        </div>
      ) : (
        <div className="row g-4">
          {filteredEvents.map(event => (
            <div key={event.id} className="col-md-6 col-lg-4">
              <div className="card h-100 venue-card">
                {/* Card image with rating */}
                <div className="position-relative">
                  <img 
                    src={event.image} 
                    className="card-img-top" 
                    alt={event.title}
                    style={{ height: '200px', objectFit: 'cover' }}
                    onError={(e) => {
                      e.target.onerror = null;
                      e.target.src = 'https://via.placeholder.com/600x400?text=No+Image';
                    }}
                  />
                  <div className="position-absolute top-0 end-0 m-2">
                    <span className="badge bg-warning text-dark px-2 py-1 rounded-pill">
                      <FaStar className="me-1" /> {event.rating}
                    </span>
                  </div>
                  <div className="position-absolute top-0 start-0 m-2">
                    <span className="badge bg-primary px-2 py-1 rounded-pill">
                      {event.category}
                    </span>
                  </div>
                </div>
                
                {/* Card body */}
                <div className="card-body">
                  <div className="d-flex align-items-center mb-2">
                    <h5 className="card-title mb-0">{event.title}</h5>
                    <span className="ms-auto text-muted small">
                      <FaMapMarkerAlt className="me-1" /> {event.city}
                    </span>
                  </div>
                  
                  <p className="card-text text-muted small mb-3" style={{minHeight: "40px"}}>
                    {event.description.substring(0, 100)}{event.description.length > 100 ? '...' : ''}
                  </p>
                  
                  <div className="event-details mb-3">
                    <div className="d-flex align-items-center mb-2">
                      <FaCalendarAlt className="text-muted me-2" />
                      <span className="small">{event.formattedDate}</span>
                    </div>
                    <div className="d-flex align-items-center mb-2">
                      <FaUsers className="text-muted me-2" />
                      <span className="small">{event.capacity}</span>
                    </div>
                  </div>
                  
                  {/* Features/amenities */}
                  <div className="event-features mb-3">
                    {event.features.map((feature, index) => (
                      <span key={index} className="badge bg-light text-dark me-2 mb-1">
                        {feature}
                      </span>
                    ))}
                  </div>
                </div>
                
                {/* Card footer */}
                <div className="card-footer bg-white d-flex justify-content-between align-items-center">
                  <span className="price fw-bold text-primary">{event.price}</span>
                  <Link to={`/event/${event.id}`} className="btn btn-sm btn-outline-primary px-3">
                    View Details
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default EventBrowse;