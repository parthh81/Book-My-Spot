import React, { useState, useEffect } from 'react';
import { Link, useParams, useNavigate } from 'react-router-dom';
import { FaArrowLeft, FaMapMarkerAlt, FaCalendarAlt, FaUsers, FaClock, FaTag, FaHeart, FaShareAlt, FaRegCalendarCheck } from 'react-icons/fa';
import EventService from '../../services/EventService';

const EventDetails = () => {
  const { eventId } = useParams();
  const navigate = useNavigate();
  const [event, setEvent] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isInterested, setIsInterested] = useState(false);
  
  // Fetch event data
  useEffect(() => {
    const fetchEventDetails = async () => {
      setLoading(true);
      try {
        // Fetch event details from the API
        const eventData = await EventService.getEventById(eventId);
        
        if (eventData) {
          console.log("Event data received:", eventData);
          
          // Format the data as needed
          const formattedEvent = {
            id: eventData._id || eventData.id || eventId,
            title: eventData.name || eventData.title || 'Unnamed Event',
            description: eventData.description || 'No description available',
            image: eventData.image || 'https://images.pexels.com/photos/2263436/pexels-photo-2263436.jpeg?auto=compress&cs=tinysrgb&w=600&h=400',
            date: eventData.date ? new Date(eventData.date) : new Date(),
            location: eventData.location || 'Location not specified',
            category: eventData.category || eventData.eventType || 'Event',
            organizer: eventData.organizer || 'Event Organizer',
            duration: eventData.duration || '3 hours',
            price: eventData.price || 'Free',
            capacity: eventData.capacity || '100+ guests',
            attendees: eventData.attendees || []
          };
          
          console.log("Formatted event:", formattedEvent);
          setEvent(formattedEvent);
        } else {
          // Use fallback data if API returns nothing
          setError('Event not found');
        }
      } catch (err) {
        console.error(`Error fetching event details for ID ${eventId}:`, err);
        setError('Failed to load event details. Please try again later.');
      } finally {
        setLoading(false);
      }
    };
    
    if (eventId) {
      fetchEventDetails();
    }
  }, [eventId]);
  
  const handleBack = () => {
    navigate(-1);
  };
  
  const toggleInterest = () => {
    setIsInterested(!isInterested);
    // TODO: Implement interest tracking with API
  };
  
  const handleRegister = () => {
    // Navigate to registration/booking form
    navigate(`/booking/${event.id}`, { 
      state: { 
        eventId: event.id,
        eventTitle: event.title,
        date: event.date,
        price: event.price,
        category: event.category,
        isEvent: true,
        venueLocation: event.location || 'No location specified',
        image: event.image
      } 
    });
  };
  
  const formatDate = (date) => {
    if (!(date instanceof Date)) return 'Date not available';
    
    return date.toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };
  
  const formatTime = (date) => {
    if (!(date instanceof Date)) return 'Time not available';
    
    return date.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit'
    });
  };
  
  // Loading state
  if (loading) {
    return (
      <div className="loading-container">
        <div className="loading-spinner"></div>
        <p>Loading event details...</p>
      </div>
    );
  }
  
  // Error state
  if (error) {
    return (
      <div className="error-container">
        <p>{error}</p>
        <button onClick={() => window.location.reload()}>Try Again</button>
        <button onClick={() => navigate('/events/browse')}>Browse Events</button>
      </div>
    );
  }
  
  // Not found state
  if (!event) {
    return (
      <div className="no-events-container">
        <h3>Event not found</h3>
        <p>Sorry, the event you're looking for doesn't exist or has been removed.</p>
        <button onClick={() => navigate('/events/browse')}>Browse Events</button>
      </div>
    );
  }
  
  return (
    <div className="event-details-container">
      {/* Back Button */}
      <div className="back-nav">
        <button className="back-btn" onClick={handleBack}>
          <FaArrowLeft /> Back
        </button>
        <div className="breadcrumbs">
          <Link to="/">Home</Link> / <Link to="/events/browse">Events</Link> / <span>{event.title}</span>
        </div>
      </div>
      
      {/* Event Header */}
      <div className="event-detail-header">
        <div className="event-header-image-container">
          <img src={event.image} alt={event.title} className="event-header-image" />
          <div className="event-category-badge">{event.category}</div>
        </div>
        
        <div className="event-header-content">
          <h1 className="event-title">{event.title}</h1>
          
          <div className="event-meta">
            <div className="event-meta-item">
              <FaCalendarAlt />
              <span>{formatDate(event.date)}</span>
            </div>
            
            <div className="event-meta-item">
              <FaClock />
              <span>{formatTime(event.date)} • {event.duration}</span>
            </div>
            
            <div className="event-meta-item">
              <FaMapMarkerAlt />
              <span>{event.location}</span>
            </div>
            
            <div className="event-meta-item">
              <FaUsers />
              <span>{event.capacity}</span>
            </div>
            
            <div className="event-meta-item">
              <FaTag />
              <span>{typeof event.price === 'number' ? `₹${event.price}` : event.price}</span>
            </div>
          </div>
          
          <div className="event-actions">
            <button 
              className={`interest-btn ${isInterested ? 'interested' : ''}`}
              onClick={toggleInterest}
            >
              <FaHeart /> {isInterested ? 'Interested' : 'Mark Interest'}
            </button>
            
            <button className="share-btn">
              <FaShareAlt /> Share
            </button>
            
            <button className="register-btn" onClick={handleRegister}>
              <FaRegCalendarCheck /> Register Now
            </button>
          </div>
        </div>
      </div>
      
      {/* Event Body */}
      <div className="event-detail-body">
        <div className="event-main-content">
          <div className="event-detail-card">
            <h2>About This Event</h2>
            <div className="event-description-full">
              {event.description}
            </div>
          </div>
          
          {/* Optional: If you have more details to show */}
          <div className="event-detail-card">
            <h2>Event Schedule</h2>
            <div className="event-schedule">
              <p>No schedule information available for this event.</p>
            </div>
          </div>
        </div>
        
        <div className="event-sidebar">
          <div className="event-detail-card">
            <h2>Organizer</h2>
            <div className="organizer-info">
              <FaUsers className="organizer-icon" />
              <div>
                <h3>{event.organizer}</h3>
                <p>Event Organizer</p>
              </div>
            </div>
          </div>
          
          <div className="event-detail-card">
            <h2>Venue Information</h2>
            <div className="venue-info">
              <p><FaMapMarkerAlt /> {event.location}</p>
              <div className="venue-map">
                {/* Map would go here */}
                <div className="map-placeholder">
                  <p>Location Map</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EventDetails; 