import React, { useState, useEffect } from 'react';
import { Link, useParams, useNavigate, useLocation } from 'react-router-dom';
import { FaCalendarAlt, FaUsers, FaClock, FaCheck, FaTimes, FaArrowLeft, FaCreditCard, FaMapMarkerAlt, FaTag, FaRupeeSign } from 'react-icons/fa';
import axios from 'axios';
import AuthService from '../../services/AuthService';
import EventService from '../../services/EventService';
import '../../styles/bookingForm.css';
import { toast } from 'react-hot-toast';

const BookingForm = () => {
  const { venueId } = useParams();
  const location = useLocation();
  const navigate = useNavigate();
  
  // Extract booking details from location state
  const { 
    isEvent, 
    eventId, 
    venueId: locationVenueId, 
    eventTitle, 
    venueTitle, 
    price, 
    image, 
    date, 
    category,
    eventType,
    venueLocation
  } = location.state || {};
  
  // Validate if we have required data
  useEffect(() => {
    if (!location.state || (!eventId && !locationVenueId)) {
      navigate('/');
      alert('Invalid booking request. Please try again.');
    }
  }, [location.state, navigate, eventId, locationVenueId]);
  
  // Form state
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    guests: isEvent ? 1 : 2,
    startDate: date || '',
    endDate: date || '',
    additionalRequests: '',
  });
  
  // Derived states
  const [numberOfDays, setNumberOfDays] = useState(1);
  const [totalPrice, setTotalPrice] = useState(calculateBasePrice());
  
  // Validation errors
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  
  // Get user data from AuthService on component mount
  useEffect(() => {
    const userInfo = AuthService.getUserInfo();
    
    if (userInfo.id) {
      setFormData(prev => ({
        ...prev,
        name: userInfo.firstName && userInfo.lastName ? `${userInfo.firstName} ${userInfo.lastName}` : prev.name,
        email: userInfo.email || prev.email
      }));
    } else {
      console.warn('User ID not found in session storage');
    }
  }, []);
  
  // Calculate number of days whenever dates change
  useEffect(() => {
    if (formData.startDate && formData.endDate) {
      const start = new Date(formData.startDate);
      const end = new Date(formData.endDate);
      
      // Check if dates are valid
      if (!isNaN(start.getTime()) && !isNaN(end.getTime())) {
        // Calculate difference in days
        const diffTime = Math.abs(end - start);
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1; // +1 to include both start and end days
        
        setNumberOfDays(diffDays > 0 ? diffDays : 1);
      }
    }
  }, [formData.startDate, formData.endDate]);
  
  // Update total price whenever number of days changes
  useEffect(() => {
    setTotalPrice(calculateTotalPrice());
  }, [numberOfDays]);
  
  // Function to calculate base price
  function calculateBasePrice() {
    if (!price) return 0;
    
    // If price is a string with currency symbol
    if (typeof price === 'string' && price.includes('₹')) {
      return parseInt(price.replace(/[^\d]/g, '')) || 0;
    }
    
    // If price is a number
    if (typeof price === 'number') {
      return price;
    }
    
    return 0;
  }
  
  // Function to calculate total price
  function calculateTotalPrice() {
    const basePrice = calculateBasePrice();
    const serviceFee = !isEvent ? 999 : 0;
    return (basePrice * numberOfDays) + serviceFee;
  }
  
  // Handle form input changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
    
    // Clear validation error when field is edited
    if (errors[name]) {
      setErrors({
        ...errors,
        [name]: null
      });
    }
    
    // Adjust end date if start date is changed to a date after end date
    if (name === 'startDate' && formData.endDate && new Date(value) > new Date(formData.endDate)) {
      setFormData(prev => ({
        ...prev,
        endDate: value
      }));
    }
  };
  
  // Form validation
  const validateForm = () => {
    const newErrors = {};
    
    // Required fields
    if (!formData.name.trim()) newErrors.name = 'Name is required';
    if (!formData.email.trim()) newErrors.email = 'Email is required';
    else if (!/\S+@\S+\.\S+/.test(formData.email)) newErrors.email = 'Email is invalid';
    
    if (!formData.phone.trim()) newErrors.phone = 'Phone number is required';
    else if (!/^\d{10}$/.test(formData.phone)) newErrors.phone = 'Phone number must be 10 digits';
    
    // Date validation
    if (!isEvent) {
      if (!formData.startDate) newErrors.startDate = 'Start date is required';
      if (!formData.endDate) newErrors.endDate = 'End date is required';
      
      if (formData.startDate && formData.endDate) {
        const start = new Date(formData.startDate);
        const end = new Date(formData.endDate);
        
        if (start > end) {
          newErrors.endDate = 'End date cannot be before start date';
        }
      }
    }
    
    if (formData.guests < 1) newErrors.guests = 'At least 1 guest is required';
    
    return newErrors;
  };
  
  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Form validation
    const formErrors = validateForm();
    if (Object.keys(formErrors).length > 0) {
      setErrors(formErrors);
      toast.error('Please fill in all required fields');
      return;
    }
    
    setLoading(true);
    
    try {
      // Create booking data object with all required fields
      const bookingData = {
        userId: AuthService.getUserInfo()?.id,
        eventId: isEvent ? eventId : null,
        venueId: !isEvent ? (locationVenueId || venueId) : null,
        venueTitle: venueTitle,
        eventTitle: eventTitle,
        name: formData.name,
        email: formData.email,
        phone: formData.phone,
        numberOfGuests: parseInt(formData.guests),
        startDate: formData.startDate,
        endDate: formData.endDate,
        numberOfDays: numberOfDays,
        location: venueLocation || 'Venue location not specified',
        image: image || '',
        category: category || 'General Event',
        basePrice: calculateBasePrice(),
        totalPrice: totalPrice,
        additionalRequests: formData.additionalRequests,
        status: 'pending'
      };
      
      console.log('Sending booking data:', bookingData);
      
      // Send to appropriate API endpoint
      let response;
      if (isEvent) {
        response = await EventService.bookEvent(bookingData);
      } else {
        response = await EventService.bookVenue(bookingData);
      }
      
      console.log('Booking response:', response);
      
      // Handle success
      setSuccess(true);
      toast.success(`${isEvent ? 'Event' : 'Venue'} booked successfully! Proceeding to payment...`);
      
      // Redirect to payment page with booking details
      setTimeout(() => {
        navigate('/payment', { 
          state: { 
            bookingId: response._id || response.id,
            eventTitle: isEvent ? eventTitle : null,
            venueTitle: !isEvent ? venueTitle : null,
            totalAmount: totalPrice,
            bookingDetails: {
              name: formData.name,
              email: formData.email,
              phone: formData.phone,
              date: isEvent ? date : formData.startDate,
              endDate: !isEvent ? formData.endDate : null,
              numberOfGuests: formData.guests,
              isEvent: isEvent,
              image: image
            }
          }
        });
      }, 2000);
      
    } catch (error) {
      console.error('Booking error:', error);
      setErrors({
        submit: error.message || `Failed to book ${isEvent ? 'event' : 'venue'}. Please try again.`
      });
      toast.error(error.message || `Failed to book ${isEvent ? 'event' : 'venue'}`);
    } finally {
      setLoading(false);
    }
  };
  
  const handleBack = () => {
    navigate(-1);
  };
  
  // Format price display
  const formatPrice = (priceString) => {
    if (!priceString) return 'Free';
    
    // If it's already a string like "₹50,000", return as is
    if (typeof priceString === 'string' && priceString.includes('₹')) {
      return priceString;
    }
    
    // If it's "Free" or any other string, return as is
    if (typeof priceString === 'string') {
      return priceString;
    }
    
    // If it's a number, format it
    return `₹${priceString.toLocaleString('en-IN')}`;
  };
  
  const formatDate = (dateString) => {
    if (!dateString) return 'Not specified';
    
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };
  
  // Get minimum date (today) for date pickers
  const getMinDate = () => {
    const today = new Date();
    return today.toISOString().split('T')[0];
  };
  
  // If no data or redirecting, show minimal loading
  if (!location.state) {
    return <div className="loading-spinner">Loading...</div>;
  }
  
  // Success screen
  if (success) {
    return (
      <div className="booking-success-container">
        <div className="booking-success">
          <div className="success-icon">
            <FaCheck />
          </div>
          <h2>Booking Successful!</h2>
          <p>Thank you for your booking. A confirmation has been sent to your email.</p>
          <p>Redirecting to your bookings...</p>
        </div>
      </div>
    );
  }
  
  return (
    <div className="booking-form-container">
      <div className="booking-details-section">
        <div className="booking-image">
          <img src={image} alt={isEvent ? eventTitle : venueTitle} />
        </div>
        
        <div className="booking-summary">
          <h2>{isEvent ? 'Event Registration' : 'Venue Booking'}</h2>
          <h3>{isEvent ? eventTitle : venueTitle}</h3>
          
          <div className="booking-meta">
            <div className="meta-item">
              <FaCalendarAlt />
              <span>
                {isEvent 
                  ? formatDate(date) 
                  : (formData.startDate && formData.endDate 
                      ? `${formatDate(formData.startDate)} to ${formatDate(formData.endDate)}` 
                      : 'Select dates')}
              </span>
            </div>
            
            {isEvent && category && (
              <div className="meta-item">
                <FaTag />
                <span>{category}</span>
              </div>
            )}
            
            {!isEvent && eventType && (
              <div className="meta-item">
                <FaTag />
                <span>{eventType}</span>
              </div>
            )}
            
            <div className="meta-item">
              <FaRupeeSign />
              <span>{formatPrice(price)} {!isEvent && '/ day'}</span>
            </div>
          </div>
          
          <div className="price-summary">
            <div className="price-row">
              <span>{isEvent ? 'Registration Fee' : 'Venue Charges'}</span>
              <span>{formatPrice(calculateBasePrice())} {!isEvent && `× ${numberOfDays} days`}</span>
            </div>
            
            {!isEvent && numberOfDays > 1 && (
              <div className="price-row">
                <span>Subtotal</span>
                <span>{formatPrice(calculateBasePrice() * numberOfDays)}</span>
              </div>
            )}
            
            {!isEvent && (
              <>
                <div className="price-row">
                  <span>Service Fee</span>
                  <span>₹999</span>
                </div>
                <div className="price-row total">
                  <span>Total</span>
                  <span>{formatPrice(totalPrice)}</span>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
      
      <div className="booking-form-section">
        <h2>Complete Your {isEvent ? 'Registration' : 'Booking'}</h2>
        
        {errors.submit && (
          <div className="error-alert">
            {errors.submit}
          </div>
        )}
        
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="name">Full Name</label>
            <input
              type="text"
              id="name"
              name="name"
              value={formData.name}
              onChange={handleChange}
              className={errors.name ? 'error' : ''}
              placeholder="Enter your full name"
            />
            {errors.name && <span className="error-message">{errors.name}</span>}
          </div>
          
          <div className="form-row">
            <div className="form-group">
              <label htmlFor="email">Email</label>
              <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                className={errors.email ? 'error' : ''}
                placeholder="Enter your email"
              />
              {errors.email && <span className="error-message">{errors.email}</span>}
            </div>
            
            <div className="form-group">
              <label htmlFor="phone">Phone Number</label>
              <input
                type="tel"
                id="phone"
                name="phone"
                value={formData.phone}
                onChange={handleChange}
                className={errors.phone ? 'error' : ''}
                placeholder="Enter 10-digit number"
                maxLength="10"
              />
              {errors.phone && <span className="error-message">{errors.phone}</span>}
            </div>
          </div>
          
          {/* Date selection for venue bookings */}
          {!isEvent && (
            <div className="form-row">
              <div className="form-group">
                <label htmlFor="startDate">Start Date</label>
                <input
                  type="date"
                  id="startDate"
                  name="startDate"
                  value={formData.startDate}
                  onChange={handleChange}
                  className={errors.startDate ? 'error' : ''}
                  min={getMinDate()}
                />
                {errors.startDate && <span className="error-message">{errors.startDate}</span>}
              </div>
              
              <div className="form-group">
                <label htmlFor="endDate">End Date</label>
                <input
                  type="date"
                  id="endDate"
                  name="endDate"
                  value={formData.endDate}
                  onChange={handleChange}
                  className={errors.endDate ? 'error' : ''}
                  min={formData.startDate || getMinDate()}
                />
                {errors.endDate && <span className="error-message">{errors.endDate}</span>}
              </div>
            </div>
          )}
          
          <div className="form-row">
            <div className="form-group">
              <label htmlFor="guests">Number of Guests</label>
              <input
                type="number"
                id="guests"
                name="guests"
                value={formData.guests}
                onChange={handleChange}
                className={errors.guests ? 'error' : ''}
                min="1"
                max={isEvent ? "10" : "1000"}
              />
              {errors.guests && <span className="error-message">{errors.guests}</span>}
            </div>
            
            {/* Empty div for layout balance */}
            <div className="form-group"></div>
          </div>
          
          <div className="form-group">
            <label htmlFor="additionalRequests">Additional Requests (Optional)</label>
            <textarea
              id="additionalRequests"
              name="additionalRequests"
              value={formData.additionalRequests}
              onChange={handleChange}
              placeholder="Any special requirements or requests..."
              rows="3"
            ></textarea>
          </div>
          
          <div className="form-actions">
            <button 
              type="button" 
              className="cancel-btn"
              onClick={handleBack}
            >
              Cancel
            </button>
            <button 
              type="submit" 
              className="submit-btn"
              disabled={loading}
            >
              {loading ? 'Processing...' : (isEvent ? 'Pay Now' : 'Pay Now')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default BookingForm; 