import React, { useState, useEffect } from 'react';
import { Link, Outlet, useLocation, useNavigate } from 'react-router-dom';
import { 
  FaCalendarAlt, 
  FaBookmark, 
  FaStar, 
  FaUser, 
  FaSignOutAlt
} from 'react-icons/fa';
import { MdMenu, MdClose } from "react-icons/md";
import AuthService from '../../services/AuthService';

export const UserSidebar = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const [isMobile, setIsMobile] = useState(window.innerWidth <= 991);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userName, setUserName] = useState('User');
  const [userInitials, setUserInitials] = useState('U');
  
  // Use AuthService to get user data
  useEffect(() => {
    const userInfo = AuthService.getUserInfo();
    const firstName = userInfo.firstName || 'User';
    const lastName = userInfo.lastName || '';
    
    setUserName(firstName);
    
    // Set user initials
    if (firstName && lastName) {
      setUserInitials(`${firstName.charAt(0)}${lastName.charAt(0)}`);
    } else if (firstName) {
      setUserInitials(firstName.charAt(0));
    }
  }, []);

  // Handle window resize
  useEffect(() => {
    const handleResize = () => {
      const mobile = window.innerWidth <= 991;
      setIsMobile(mobile);
      if (!mobile) setMobileMenuOpen(false);
    };
    
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Close mobile menu when route changes
  useEffect(() => {
    setMobileMenuOpen(false);
  }, [location]);

  // Check if current path matches the link
  const isActive = (path) => {
    return location.pathname === path || 
           (path !== "/user" && location.pathname.startsWith(path));
  };

  // Toggle mobile menu
  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  // Handle logout
  const handleLogout = () => {
    // Use AuthService for logout
    AuthService.logout();
    navigate('/login');
  };

  return (
    <div className="sidebar-layout">
      {isMobile && (
        <div className="mobile-header">
          <button 
            className="mobile-menu-toggle" 
            onClick={toggleMobileMenu}
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? <MdClose /> : <MdMenu />}
          </button>
          <span className="mobile-title">BookMySpot</span>
        </div>
      )}
      
      {isMobile && mobileMenuOpen && (
        <div className="mobile-overlay" onClick={() => setMobileMenuOpen(false)}></div>
      )}
      
      <div className={`app-sidebar ${isMobile && mobileMenuOpen ? 'mobile-open' : ''}`}>
        <div className="sidebar-header">
          <Link to="/user" className="sidebar-logo">BookMySpot</Link>
        </div>
        
        <div className="user-info">
          <div className="user-avatar">
            {userInitials}
          </div>
          <div className="user-details">
            <h5>{userName}</h5>
          </div>
        </div>
        
        <nav className="sidebar-nav">
          <ul className="nav-list">
            <li className="nav-item">
              <Link to="/user/profile" className={`nav-link ${isActive('/user/profile') ? 'active' : ''}`}>
                <span className="nav-icon"><FaUser /></span>
                <span>My Profile</span>
              </Link>
            </li>
            
            <li className="nav-item">
              <Link to="/user/bookings" className={`nav-link ${isActive('/user/bookings') ? 'active' : ''}`}>
                <span className="nav-icon"><FaCalendarAlt /></span>
                <span>My Bookings</span>
              </Link>
            </li>
            
            <li className="nav-item">
              <Link to="/events/browse" className={`nav-link ${isActive('/events/browse') ? 'active' : ''}`}>
                <span className="nav-icon"><FaBookmark /></span>
                <span>Browse Events</span>
              </Link>
            </li>
            
            <li className="nav-item">
              <Link to="/venues/browse" className={`nav-link ${isActive('/venues/browse') ? 'active' : ''}`}>
                <span className="nav-icon"><FaStar /></span>
                <span>Browse Venues</span>
              </Link>
            </li>
          </ul>
        </nav>
        
        <div className="sidebar-footer">
          <button className="sign-out-btn" onClick={handleLogout}>
            <FaSignOutAlt />
            Logout
          </button>
        </div>
      </div>
      
      <main className={`main-content ${isMobile ? 'mobile-shift' : ''}`}>
        <Outlet />
      </main>
    </div>
  );
};