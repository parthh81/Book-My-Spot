import React, { useState, useEffect } from "react";
import { Link, Outlet, useLocation, useNavigate } from "react-router-dom";
import { 
  FaHome, 
  FaCalendarAlt, 
  FaUsers, 
  FaCog, 
  FaUser,
  FaSignOutAlt,
  FaTimes,
  FaChartLine,
  FaTicketAlt,
  FaTachometerAlt,
  FaUserCircle
} from "react-icons/fa";
import AuthService from '../../services/AuthService';
import { onAuthStateChanged } from 'firebase/auth';
import { auth, db } from '../../firebase';
import { doc, getDoc } from 'firebase/firestore';
import '../../styles/sidebar.css';
import { MdDashboard, MdSettings, MdEvent, MdLogout, MdMenu, MdClose } from "react-icons/md";
import { useAuth } from '../../context/AuthContext';

export const OrganizerSidebar = ({ children }) => {
  const { user, loading, logout } = useAuth();
  const location = useLocation();
  const [isMobile, setIsMobile] = useState(window.innerWidth <= 991);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userInitials, setUserInitials] = useState('');
  const [userName, setUserName] = useState('');
  const [isOrganizer, setIsOrganizer] = useState(false);

  // Check if user has organizer role
  useEffect(() => {
    if (user && user.role === 'organizer') {
      setIsOrganizer(true);
    } else {
      setIsOrganizer(false);
    }
  }, [user]);

  // Get user initials for avatar
  useEffect(() => {
    if (user) {
      const getUserInitials = () => {
        if (!user.name) return 'U';
        const nameParts = user.name.split(' ');
        if (nameParts.length > 1) {
          return `${nameParts[0][0]}${nameParts[1][0]}`.toUpperCase();
        }
        return nameParts[0][0].toUpperCase();
      };
      setUserInitials(getUserInitials());
    }
  }, [user]);

  // Format user name properly
  useEffect(() => {
    if (user) {
      const formatName = (name) => {
        if (!name) return '';
        return name.split(' ').map(part => 
          part.charAt(0).toUpperCase() + part.slice(1).toLowerCase()
        ).join(' ');
      };
      setUserName(formatName(user.name));
    }
  }, [user]);

  // Handle window resize
  useEffect(() => {
    const handleResize = () => {
      const mobile = window.innerWidth <= 991;
      setIsMobile(mobile);
      if (!mobile) setMobileMenuOpen(false);
    };
    
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Close mobile menu when route changes
  useEffect(() => {
    setMobileMenuOpen(false);
  }, [location]);

  // Handle logout
  const handleLogout = async () => {
    try {
      await logout();
    } catch (error) {
      console.error('Logout failed:', error);
    }
  };

  // Check if a route is active
  const isActive = (path) => {
    return location.pathname === path || 
           (path !== "/organizer" && location.pathname.startsWith(path));
  };

  // Toggle mobile menu
  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  // Main menu items
  const menuItems = [
    {
      path: '/organizer/dashboard',
      icon: <MdDashboard />,
      label: 'Dashboard'
    },
    {
      path: '/organizer/events',
      icon: <MdEvent />,
      label: 'Events'
    },
    {
      path: '/organizer/bookings',
      icon: <FaTicketAlt />,
      label: 'Bookings'
    },
    {
      path: '/organizer/attendees',
      icon: <FaUsers />,
      label: 'Attendees'
    },
    {
      path: '/organizer/profile',
      icon: <FaUser />,
      label: 'Profile'
    },
    {
      path: '/organizer/settings',
      icon: <MdSettings />,
      label: 'Settings'
    }
  ];

  if (loading) {
    return <div className="loading-container">Loading...</div>;
  }

  if (!isOrganizer) {
    return children;
  }

  return (
    <div className="sidebar-layout">
      {isMobile && (
        <div className="mobile-header">
          <button 
            className="mobile-menu-toggle" 
            onClick={toggleMobileMenu}
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? <MdClose /> : <MdMenu />}
          </button>
          <span className="mobile-title">BookMySpot</span>
        </div>
      )}
      
      {isMobile && mobileMenuOpen && (
        <div className="mobile-overlay" onClick={() => setMobileMenuOpen(false)}></div>
      )}
      
      <div className={`app-sidebar ${isMobile && mobileMenuOpen ? 'mobile-open' : ''}`}>
        <div className="sidebar-header">
          <Link to="/organizer/dashboard" className="sidebar-logo">BookMySpot</Link>
        </div>
        
        <div className="user-info">
          <div className="user-avatar">
            {userInitials}
          </div>
          <div className="user-details">
            <h5>{userName}</h5>
            <p>{user?.email}</p>
          </div>
        </div>
        
        <nav className="sidebar-nav">
          <ul className="nav-list">
            {menuItems.map((item, index) => (
              <li key={index} className="nav-item">
                <Link
                  to={item.path}
                  className={`nav-link ${isActive(item.path) ? 'active' : ''}`}
                  onClick={() => isMobile && setMobileMenuOpen(false)}
                >
                  <span className="nav-icon">{item.icon}</span>
                  <span>{item.label}</span>
                </Link>
              </li>
            ))}
          </ul>
        </nav>
        
        <div className="sidebar-footer">
          <button className="sign-out-btn" onClick={handleLogout}>
            <MdLogout />
            Sign Out
          </button>
        </div>
      </div>
      
      <main className={`main-content ${isMobile ? 'mobile-shift' : ''}`}>
        {children}
      </main>
    </div>
  );
};

// Helper function to get the page title based on the current route
const getPageTitle = (pathname) => {
  if (pathname === '/organizer' || pathname === '/organizer/dashboard') {
    return 'Dashboard';
  } else if (pathname.includes('/events')) {
    return 'Events';
  } else if (pathname.includes('/addevent')) {
    return 'Add Event';
  } else if (pathname.includes('/bookings')) {
    return 'Bookings';
  } else if (pathname.includes('/profile')) {
    return 'Profile';
  } else {
    return 'Organizer Portal';
  }
};

export default OrganizerSidebar; 