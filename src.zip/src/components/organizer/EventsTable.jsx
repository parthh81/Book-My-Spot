import React, { useEffect, useState } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import axios from "axios";
import ConfigService from '../../services/ConfigService';
import { 
  FaEdit, 
  FaTrash, 
  FaSearch, 
  FaPlus, 
  FaFilter, 
  FaEye, 
  FaCalendarAlt, 
  FaChevronDown, 
  FaChevronLeft, 
  FaChevronRight,
  FaSort,
  FaSortUp,
  FaSortDown,
  FaEllipsisV,
  FaCheck,
  FaTimes,
  FaDownload,
  FaCopy,
  FaExclamationTriangle,
  FaMapMarkerAlt,
  FaUsers,
  FaMoneyBillWave,
  FaArrowRight
} from "react-icons/fa";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { 
  faClock
} from '@fortawesome/free-solid-svg-icons';
import { formatDate } from '../../utils/formatters';
import '../../styles/events.css';
import EventService from '../../services/EventService';
import Swal from 'sweetalert2';
import { collection, getDocs, doc, deleteDoc, query, where } from 'firebase/firestore';
import { db } from '../../firebase';
import { useAuth } from '../../context/AuthContext';
import { MdEdit, MdDelete, MdVisibility, MdAdd } from 'react-icons/md';
import { format } from 'date-fns';
import EventForm from './EventForm';
import EventDetails from './EventDetails';

// Sample event data that will be used if no events are returned from the API
const sampleEvents = [
  {
    _id: 'sample_event_1',
    name: 'Beach Wedding Ceremony',
    description: 'A beautiful beach wedding ceremony with ocean views and stunning sunset.',
    eventType: 'Wedding',
    category: 'Wedding',
    location: 'Royal Garden Palace, Mumbai',
    date: new Date('2025-04-13'),
    price: 150000,
    capacity: 200,
    status: 'active',
    image: 'https://images.unsplash.com/photo-1519225421980-715cb0215aed?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80'
  }
];

// Define styles object for consistent styling
const customStyles = {
  cardContainer: {
    border: 'none',
    borderRadius: '0.5rem',
    boxShadow: '0 .125rem .25rem rgba(0, 0, 0, 0.075)',
    marginBottom: '1rem',
    overflow: 'hidden'
  },
  cardHeader: {
    backgroundColor: '#fff',
    borderBottom: '1px solid rgba(0,0,0,.125)',
    padding: '1rem 1.25rem'
  },
  cardFooter: {
    backgroundColor: '#fff',
    borderTop: '1px solid rgba(0,0,0,.125)',
    padding: '0.75rem 1.25rem'
  },
  tableResponsive: {
    width: '100%',
    overflowX: 'auto'
  },
  pagination: {
    display: 'flex',
    padding: '0',
    margin: '0',
    listStyle: 'none'
  },
  pageItem: {
    margin: '0 2px'
  },
  pageLink: {
    position: 'relative',
    display: 'block',
    padding: '0.375rem 0.75rem',
    color: '#0d6efd',
    backgroundColor: '#fff',
    border: '1px solid #dee2e6',
    borderRadius: '0.25rem',
    textDecoration: 'none'
  },
  pageItemActive: {
    zIndex: 3,
    color: '#fff',
    backgroundColor: '#0d6efd',
    borderColor: '#0d6efd'
  },
  badge: {
    display: 'inline-block',
    padding: '0.35em 0.65em',
    fontSize: '0.75em',
    fontWeight: '700',
    lineHeight: '1',
    textAlign: 'center',
    whiteSpace: 'nowrap',
    verticalAlign: 'baseline',
    borderRadius: '0.25rem'
  },
  primaryButton: {
    backgroundColor: '#4c6ef5',
    color: 'white',
    border: 'none',
    borderRadius: '0.375rem',
    padding: '0.625rem 1.25rem',
    fontWeight: '500',
    display: 'flex',
    alignItems: 'center',
    gap: '0.5rem'
  }
};

const EventsTable = () => {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedEvent, setSelectedEvent] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [editingEvent, setEditingEvent] = useState(null);
  const [filters, setFilters] = useState({
    eventType: 'all',
    status: 'all',
    dateRange: 'all'
  });
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(6);
  const [totalItems, setTotalItems] = useState(0);
  const [sortField, setSortField] = useState("date");
  const [sortDirection, setSortDirection] = useState("desc");
  const [viewMode, setViewMode] = useState("grid"); // Always use grid view
  const [selectedEvents, setSelectedEvents] = useState([]);
  const [activeEvent, setActiveEvent] = useState(null);
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [eventTypes, setEventTypes] = useState([]);
  const [statuses, setStatuses] = useState([]);
  const [useSampleData, setUseSampleData] = useState(false);
  const [alertMessage, setAlertMessage] = useState(null);
  const { user } = useAuth();

  const navigate = useNavigate();
  const location = useLocation(); // Get access to location state

  // Configure axios to use the backend URL
  const API_BASE_URL = "http://localhost:3200";
  axios.defaults.baseURL = API_BASE_URL;

  // Add a state to track if the component is mounted
  const [isMounted, setIsMounted] = useState(false);

  // Check for location state and refresh events if coming back from event creation
  useEffect(() => {
    if (location.state && location.state.eventCreated) {
      console.log("Detected return from event creation, refreshing events list");
      fetchEvents();
      
      // Clear the location state to prevent repeated fetches
      navigate(location.pathname, { replace: true, state: {} });
    }
  }, [location.state]);

  // Fetch events when component mounts and when dependencies change
  useEffect(() => {
    fetchEvents();
    setIsMounted(true);

    // Clean up when the component unmounts
    return () => {
      setIsMounted(false);
    };
  }, [currentPage, itemsPerPage, sortField, sortDirection, filters.eventType, filters.status, useSampleData]);

  const fetchEvents = async () => {
    setLoading(true);
    
    try {
      if (user) {
        const q = query(collection(db, 'events'), where('organizerId', '==', user.uid));
        const querySnapshot = await getDocs(q);
        
        const eventsList = querySnapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data(),
          date: doc.data().date.toDate()
        }));
        
        // Sort events by date (newest first)
        eventsList.sort((a, b) => b.date - a.date);
        
        setEvents(eventsList);
      }
    } catch (error) {
      console.error('Error fetching events:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSort = (field) => {
    if (field === sortField) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const handleChangePage = (newPage) => {
    if (newPage > 0 && newPage <= Math.ceil(totalItems / itemsPerPage)) {
      setCurrentPage(newPage);
    }
  };

  const handleChangeItemsPerPage = (e) => {
    setItemsPerPage(Number(e.target.value));
    setCurrentPage(1);
  };

  const handleSelectEvent = (eventId) => {
    if (selectedEvents.includes(eventId)) {
      setSelectedEvents(selectedEvents.filter(id => id !== eventId));
    } else {
      setSelectedEvents([...selectedEvents, eventId]);
    }
  };

  const handleSelectAllEvents = () => {
    if (selectedEvents.length === events.length) {
      setSelectedEvents([]);
    } else {
      setSelectedEvents(events.map(event => event._id));
    }
  };

  const handleViewDetails = (event) => {
    setSelectedEvent(event);
    setShowModal(true);
    console.log("View details for event:", event.name);
  };

  const handleEdit = (eventId) => {
    // Find the event to edit
    const eventToEdit = events.find(event => event._id === eventId);
    if (eventToEdit) {
      setEditingEvent(eventToEdit);
      setShowEditModal(true);
      
      // Close details modal if it's open
      if (showModal) {
        setShowModal(false);
      }
    }
  };

  const handleSaveEvent = async (updatedEvent) => {
    try {
      // First try to update the event via API
      if (updatedEvent._id && !updatedEvent._id.startsWith('event_')) {
        // This is an existing event with a real ID from the database
        await EventService.updateEvent(updatedEvent._id, updatedEvent);
      } else {
        // This is a local event that hasn't been saved to the database yet
        // We'll use createEvent to save it properly
        const newEvent = await EventService.createEvent(updatedEvent);
        updatedEvent._id = newEvent._id || updatedEvent._id;
      }
      
      console.log("Event saved to API:", updatedEvent);
      
      // Also update localStorage as a backup
      const savedEvents = JSON.parse(localStorage.getItem('organizer_events') || '[]');
      const updatedEvents = savedEvents.map(event => 
        event._id === updatedEvent._id ? updatedEvent : event
      );
      
      // If the event wasn't in the array (new event), add it
      if (!updatedEvents.some(e => e._id === updatedEvent._id)) {
        updatedEvents.push(updatedEvent);
      }
      
      localStorage.setItem('organizer_events', JSON.stringify(updatedEvents));
      
      // Update the event in local state
      const updatedLocalEvents = events.map(event => 
        event._id === updatedEvent._id ? updatedEvent : event
      );
      
      // If the event wasn't in the array (new event), add it
      if (!updatedLocalEvents.some(e => e._id === updatedEvent._id)) {
        updatedLocalEvents.push(updatedEvent);
      }
      
      setEvents(updatedLocalEvents);
      setTotalItems(updatedLocalEvents.length);
      setShowEditModal(false);
      
      // Refresh events list from the server to ensure we have the latest data
      fetchEvents();
    } catch (error) {
      console.error("Error saving event:", error);
      alert("There was an error saving the event. Please try again.");
      
      // Still update localStorage as a fallback
      const savedEvents = JSON.parse(localStorage.getItem('organizer_events') || '[]');
      const updatedEvents = savedEvents.map(event => 
        event._id === updatedEvent._id ? updatedEvent : event
      );
      
      if (!updatedEvents.some(e => e._id === updatedEvent._id)) {
        updatedEvents.push(updatedEvent);
      }
      
      localStorage.setItem('organizer_events', JSON.stringify(updatedEvents));
      
      // Also update local state
      const updatedLocalEvents = events.map(event => 
        event._id === updatedEvent._id ? updatedEvent : event
      );
      
      if (!updatedLocalEvents.some(e => e._id === updatedEvent._id)) {
        updatedLocalEvents.push(updatedEvent);
      }
      
      setEvents(updatedLocalEvents);
      setTotalItems(updatedLocalEvents.length);
      setShowEditModal(false);
    }
  };

  const handleDelete = async (eventId) => {
    try {
      const result = await Swal.fire({
        title: 'Delete Event?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#f05537',
        cancelButtonColor: '#6c757d',
        confirmButtonText: 'Yes, delete it!'
      });
      
      if (result.isConfirmed) {
        // Delete event
        await EventService.deleteEvent(eventId);
        
        // Filter out the deleted event
        setEvents(events.filter(event => event._id !== eventId));
        
        // Show success message
        setAlertMessage({
          type: 'success',
          text: 'Event deleted successfully!'
        });
        
        // Auto-dismiss alert after 3 seconds
        setTimeout(() => {
          setAlertMessage(null);
        }, 3000);
      }
    } catch (error) {
      console.error('Error deleting event:', error);
      setAlertMessage({
        type: 'danger',
        text: `Error deleting event: ${error.message || 'Unknown error'}`
      });
    }
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(amount);
  };

  const renderPagination = () => {
    const totalPages = Math.ceil(totalItems / itemsPerPage);
    
    return (
      <div className="organizer-pagination-container">
        <div className="organizer-pagination-info">
          Showing {Math.min((currentPage - 1) * itemsPerPage + 1, totalItems)} to {Math.min(currentPage * itemsPerPage, totalItems)} of {totalItems} events
        </div>
        
        <div className="organizer-pagination">
          <button 
            className="organizer-pagination-btn" 
            onClick={() => handleChangePage(currentPage - 1)}
            disabled={currentPage === 1}
          >
            <FaChevronLeft />
          </button>
          
          {[...Array(totalPages)].map((_, index) => {
            // Show first page, last page, and pages around current page
            const pageNumber = index + 1;
            if (
              pageNumber === 1 || 
              pageNumber === totalPages || 
              (pageNumber >= currentPage - 1 && pageNumber <= currentPage + 1)
            ) {
              return (
                <button 
                  key={pageNumber}
                  className={`organizer-pagination-btn ${pageNumber === currentPage ? 'active' : ''}`}
                  onClick={() => handleChangePage(pageNumber)}
                >
                  {pageNumber}
                </button>
              );
            } else if (
              (pageNumber === currentPage - 2 && currentPage > 3) || 
              (pageNumber === currentPage + 2 && currentPage < totalPages - 2)
            ) {
              return <span key={pageNumber} className="organizer-pagination-ellipsis">...</span>;
            } else {
              return null;
            }
          })}
          
          <button 
            className="organizer-pagination-btn" 
            onClick={() => handleChangePage(currentPage + 1)}
            disabled={currentPage === totalPages}
          >
            <FaChevronRight />
          </button>
        </div>
        
        <div className="organizer-pagination-perpage">
          <select 
            value={itemsPerPage} 
            onChange={handleChangeItemsPerPage}
            className="organizer-select"
          >
            <option value={6}>6 per page</option>
            <option value={12}>12 per page</option>
            <option value={24}>24 per page</option>
            <option value={48}>48 per page</option>
          </select>
        </div>
      </div>
    );
  };

  const renderEvents = () => {
    if (loading) {
      return (
        <div className="d-flex justify-content-center p-5">
          <div className="spinner-border text-primary" role="status">
            <span className="visually-hidden">Loading events...</span>
          </div>
        </div>
      );
    }

    if (events.length === 0) {
      return (
        <div className="text-center py-5" style={{ border: 'none', outline: 'none' }}>
          <FaCalendarAlt size={48} className="text-muted mb-3" />
          <h4>No events found</h4>
          <p className="text-muted">Create your first event or adjust your filters.</p>
          <button 
            className="btn btn-primary mt-3"
            onClick={() => navigate('/organizer/add-event')}
            style={{ backgroundColor: "#f05537", borderColor: "#f05537", border: 'none' }}
          >
            <FaPlus className="me-2" /> Create New Event
          </button>
        </div>
      );
    }

    // Apply filters and search
    let filteredEvents = [...events];
    
    // Apply search
    if (searchTerm) {
      filteredEvents = filteredEvents.filter(event => 
        event.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        event.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        event.eventType?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        event.location?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    
    // Apply event type filter
    if (filters.eventType !== 'all') {
      filteredEvents = filteredEvents.filter(event => 
        event.eventType === filters.eventType || event.category === filters.eventType
      );
    }
    
    // Apply status filter
    if (filters.status !== 'all') {
      filteredEvents = filteredEvents.filter(event => event.status === filters.status);
    }
    
    // Apply date range filter
    if (filters.dateRange !== 'all') {
      const now = new Date();
      if (filters.dateRange === 'upcoming') {
        filteredEvents = filteredEvents.filter(event => new Date(event.date) > now);
      } else if (filters.dateRange === 'past') {
        filteredEvents = filteredEvents.filter(event => new Date(event.date) < now);
      } else if (filters.dateRange === 'today') {
        filteredEvents = filteredEvents.filter(event => {
          const eventDate = new Date(event.date);
          return eventDate.getDate() === now.getDate() && 
                 eventDate.getMonth() === now.getMonth() && 
                 eventDate.getFullYear() === now.getFullYear();
        });
      } else if (filters.dateRange === 'week') {
        const weekFromNow = new Date();
        weekFromNow.setDate(weekFromNow.getDate() + 7);
        filteredEvents = filteredEvents.filter(event => {
          const eventDate = new Date(event.date);
          return eventDate > now && eventDate <= weekFromNow;
        });
      } else if (filters.dateRange === 'month') {
        const monthFromNow = new Date();
        monthFromNow.setMonth(monthFromNow.getMonth() + 1);
        filteredEvents = filteredEvents.filter(event => {
          const eventDate = new Date(event.date);
          return eventDate > now && eventDate <= monthFromNow;
        });
      }
    }
    
    // If we have no matching events after filtering
    if (filteredEvents.length === 0) {
      return (
        <div className="text-center py-5" style={{ border: 'none', outline: 'none' }}>
          <FaCalendarAlt size={48} className="text-muted mb-3" />
          <h4>No matching events found</h4>
          <p className="text-muted">Try adjusting your filters or search terms.</p>
          <button 
            className="btn btn-outline-secondary mt-3"
            onClick={() => {
              setSearchTerm('');
              setFilters({
                eventType: 'all',
                status: 'all',
                dateRange: 'all'
              });
            }}
            style={{ border: '1px solid #e2e8f0' }}
          >
            Clear Filters
          </button>
        </div>
      );
    }
    
    // Apply sorting
    filteredEvents.sort((a, b) => {
      if (sortField === 'name') {
        return sortDirection === 'asc' 
          ? (a.name || '').localeCompare(b.name || '') 
          : (b.name || '').localeCompare(a.name || '');
      } else if (sortField === 'date') {
        return sortDirection === 'asc' 
          ? new Date(a.date) - new Date(b.date) 
          : new Date(b.date) - new Date(a.date);
      } else if (sortField === 'price') {
        return sortDirection === 'asc' 
          ? (a.price || 0) - (b.price || 0) 
          : (b.price || 0) - (a.price || 0);
      } else if (sortField === 'capacity') {
        return sortDirection === 'asc' 
          ? (a.capacity || 0) - (b.capacity || 0) 
          : (b.capacity || 0) - (a.capacity || 0);
      }
      return 0;
    });
    
    // Paginate events
    const indexOfLastEvent = currentPage * itemsPerPage;
    const indexOfFirstEvent = indexOfLastEvent - itemsPerPage;
    const currentEvents = filteredEvents.slice(indexOfFirstEvent, indexOfLastEvent);
    
    return (
      <div className="container-fluid p-3">
        <div className="row g-3">
          {currentEvents.map((event) => (
            <div className="col-md-4 col-sm-6" key={event._id}>
              <div className="card event-card h-100 shadow-sm">
                {/* Top badges */}
                <div className="position-relative">
                  <div className="position-absolute top-0 start-0 m-2 z-index-1">
                    <span className="badge bg-danger px-2 py-1">
                      {event.eventType || event.category || 'Event'}
                    </span>
                  </div>
                  <div className="position-absolute top-0 end-0 m-2 z-index-1">
                    <span className={`badge px-2 py-1 ${event.status === 'active' ? 'bg-success' : 'bg-secondary'}`}>
                      {event.status === 'active' ? 'Active' : 'Inactive'}
                    </span>
                  </div>
                  
                  {/* Event image */}
                  <div className="card-img-container">
                    <img
                      src={event.image || 'https://via.placeholder.com/600x400?text=No+Image'}
                      alt={event.name}
                      className="card-img-top"
                      onError={(e) => {
                        e.target.onerror = null;
                        e.target.src = 'https://via.placeholder.com/600x400?text=No+Image';
                      }}
                    />
                  </div>
                </div>
                
                {/* Event details */}
                <div className="card-body p-3">
                  {/* Event title */}
                  <h5 className="card-title fw-bold mb-2">{event.name}</h5>
                  
                  {/* Location with icon */}
                  <div className="event-location mb-1">
                    <FaMapMarkerAlt className="text-muted me-1" style={{ fontSize: "0.8rem" }} />
                    <small className="text-muted" style={{ fontSize: "0.8rem" }}>
                      {event.location ? (
                        event.location.length > 35 ? event.location.substring(0, 35) + '...' : event.location
                      ) : 'Location not specified'}
                    </small>
                  </div>
                  
                  {/* Date with icon */}
                  <div className="event-date mb-2">
                    <FaCalendarAlt className="text-muted me-1" style={{ fontSize: "0.8rem" }} />
                    <small className="text-muted" style={{ fontSize: "0.8rem" }}>
                      {new Date(event.date).getDate()} {new Date(event.date).toLocaleString('default', { month: 'short' })} {new Date(event.date).getFullYear()}
                    </small>
                  </div>
                  
                  {/* Price and capacity */}
                  <div className="d-flex justify-content-between align-items-center mt-auto">
                    <div>
                      <FaMoneyBillWave className="text-muted me-1" style={{ fontSize: "0.8rem" }} />
                      <small className="text-muted" style={{ fontSize: "0.8rem" }}>
                        ₹{formatCurrency(event.price) || 'Free'}
                      </small>
                    </div>
                    <div>
                      <FaUsers className="text-muted me-1" style={{ fontSize: "0.8rem" }} />
                      <small className="text-muted" style={{ fontSize: "0.8rem" }}>
                        {event.capacity || 'Unlimited'}
                      </small>
                    </div>
                  </div>
                </div>
                
                {/* Action buttons in footer */}
                <div className="card-footer d-flex justify-content-center">
                  <div className="d-flex gap-2">
                    <button
                      className="btn btn-sm btn-outline-danger px-3"
                      onClick={() => handleViewDetails(event)}
                    >
                      View
                    </button>
                    <button
                      className="btn btn-sm btn-outline-secondary"
                      onClick={() => handleEdit(event._id)}
                    >
                      <FaEdit />
                    </button>
                    <button
                      className="btn btn-sm btn-outline-secondary"
                      onClick={() => handleDelete(event._id)}
                    >
                      <FaTrash />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  };

  // Create a form component for editing events
  const EditEventForm = ({ event, onSave, onCancel }) => {
    const [formData, setFormData] = useState({
      name: event.name,
      eventType: event.eventType,
      date: new Date(event.date).toISOString().split('T')[0],
      capacity: event.capacity,
      cityName: event.cityId?.name || '',
      areaName: event.areaId?.name || '',
      price: event.price,
      description: event.description || '',
      status: event.status
    });
    
    const handleChange = (e) => {
      const { name, value } = e.target;
      setFormData({
        ...formData,
        [name]: value
      });
    };
    
    const handleSubmit = (e) => {
      e.preventDefault();
      
      // Create updated event object
      const updatedEvent = {
        ...event,
        name: formData.name,
        eventType: formData.eventType,
        date: new Date(formData.date),
        capacity: parseInt(formData.capacity),
        cityId: { ...event.cityId, name: formData.cityName },
        areaId: { ...event.areaId, name: formData.areaName },
        price: parseInt(formData.price),
        description: formData.description,
        status: formData.status
      };
      
      onSave(updatedEvent);
    };
    
    return (
      <form onSubmit={handleSubmit} className="edit-event-form">
        <div className="row mb-3">
          <div className="col-md-12">
            <label className="form-label">Event Name</label>
            <input
              type="text"
              name="name"
              value={formData.name}
              onChange={handleChange}
              required
              className="form-control"
            />
          </div>
        </div>
        
        <div className="row mb-3">
          <div className="col-md-6">
            <label className="form-label">Event Type</label>
            <select
              name="eventType"
              value={formData.eventType}
              onChange={handleChange}
              className="form-select"
            >
              {eventTypes.map(type => (
                <option key={type} value={type}>{type}</option>
              ))}
            </select>
          </div>
            
          <div className="col-md-6">
            <label className="form-label">Status</label>
            <select
              name="status"
              value={formData.status}
              onChange={handleChange}
              className="form-select"
            >
              {statuses.map(status => (
                <option key={status} value={status}>{status}</option>
              ))}
            </select>
          </div>
        </div>
        
        <div className="row mb-3">
          <div className="col-md-6">
            <label className="form-label">Date</label>
            <input 
              type="date" 
              name="date"
              value={formData.date}
              onChange={handleChange}
              required
              className="form-control"
            />
          </div>

          <div className="col-md-6">
            <label className="form-label">Capacity</label>
            <input 
              type="number" 
              name="capacity"
              value={formData.capacity}
              onChange={handleChange}
              min="1"
              required
              className="form-control"
            />
          </div>
        </div>
        
        <div className="row mb-3">
          <div className="col-md-6">
            <label className="form-label">City</label>
            <input 
              type="text" 
              name="cityName"
              value={formData.cityName}
              onChange={handleChange}
              className="form-control"
            />
          </div>
          
          <div className="col-md-6">
            <label className="form-label">Venue</label>
            <input 
              type="text" 
              name="areaName"
              value={formData.areaName}
              onChange={handleChange}
              className="form-control"
            />
          </div>
        </div>
        
        <div className="row mb-3">
          <div className="col-md-12">
            <label className="form-label">Price (₹)</label>
            <input 
              type="number" 
              name="price"
              value={formData.price}
              onChange={handleChange}
              min="0"
              required
              className="form-control"
            />
          </div>
        </div>
                  
        <div className="row mb-3">
          <div className="col-md-12">
            <label className="form-label">Description</label>
            <textarea 
              name="description"
              value={formData.description}
              onChange={handleChange}
              rows="3"
              className="form-control"
            ></textarea>
          </div>
        </div>
                  
        <div className="d-flex justify-content-end gap-2 mt-4">
          <button type="button" className="btn btn-outline-secondary" onClick={onCancel}>
            Cancel
          </button>
          <button type="submit" className="btn btn-primary">
            Save Changes
          </button>
        </div>
      </form>
    );
  };

  return (
    <div className="events-management" style={{ border: 'none', outline: 'none', padding: '1.5rem' }}>
      {/* Alert messages */}
      {alertMessage && (
        <div className={`alert alert-${alertMessage.type} alert-dismissible fade show`} role="alert">
          {alertMessage.text}
          <button type="button" className="btn-close" onClick={() => setAlertMessage(null)}></button>
        </div>
      )}
      
      {/* Header section */}
      <div className="events-management-header">
        <h2 className="events-title">
          <FaCalendarAlt className="me-2" /> Manage Events
        </h2>
        <button
          className="create-event-btn"
          onClick={() => navigate('/organizer/add-event')}
        >
          <FaPlus className="me-1" /> Create New Event
        </button>
      </div>
      
      {/* Filters and search bar */}
      <div className="card shadow-sm border-0 mb-4">
        <div className="card-body p-3">
          <div className="d-flex flex-wrap gap-2 align-items-center">
            <div className="search-bar me-auto">
              <div className="search-input-container">
                <FaSearch className="search-icon" />
                <input
                  type="text"
                  className="search-input"
                  placeholder="Search events..."
                  value={searchTerm}
                  onChange={e => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
            
            <select
              className="filter-select"
              value={filters.eventType}
              onChange={e => setFilters({...filters, eventType: e.target.value})}
            >
              <option value="all">All Event Types</option>
              {eventTypes.map((type, index) => (
                <option key={index} value={type}>{type}</option>
              ))}
            </select>
            
            <select
              className="filter-select"
              value={filters.status}
              onChange={e => setFilters({...filters, status: e.target.value})}
            >
              <option value="all">All Statuses</option>
              {statuses.map((status, index) => (
                <option key={index} value={status}>{status}</option>
              ))}
            </select>
            
            <select
              className="filter-select"
              value={filters.dateRange}
              onChange={e => setFilters({...filters, dateRange: e.target.value})}
            >
              <option value="all">All Dates</option>
              <option value="upcoming">Upcoming</option>
              <option value="past">Past</option>
              <option value="today">Today</option>
              <option value="week">This Week</option>
              <option value="month">This Month</option>
            </select>
            
            <button
              className="filter-button"
              onClick={() => {
                setSearchTerm('');
                setFilters({
                  eventType: 'all',
                  status: 'all',
                  dateRange: 'all'
                });
              }}
            >
              <FaTimes className="me-1" /> Clear
            </button>
          </div>
        </div>
      </div>
      
      {/* Event cards grid */}
      <div className="card shadow-sm border-0 mb-4" style={{ border: 'none', borderRadius: '0', boxShadow: 'none' }}>
        <div className="card-body p-0" style={{ border: 'none', outline: 'none' }}>
          {renderEvents()}
        </div>
      </div>
      
      {/* Pagination */}
      {events.length > 0 && !loading && (
        <div className="organizer-pagination-container">{renderPagination()}</div>
      )}
      
      {/* Modals */}
      {renderEventDetailsModal()}
      {renderEditModal()}
    </div>
  );
};

export default EventsTable;
