import React, { useEffect, useState } from "react";
import { motion } from "framer-motion";
import axios from "axios";
import { 
  FaSearch, 
  FaFilter, 
  FaChevronDown, 
  FaCheckCircle, 
  FaTimesCircle, 
  FaQuestionCircle,
  FaEnvelope,
  FaPhoneAlt,
  FaEye,
  FaChevronLeft,
  FaChevronRight,
  FaSortUp,
  FaSortDown,
  FaSort,
  FaCalendarAlt,
  FaCreditCard,
  FaUserCheck,
  FaUserTimes,
  FaUserClock,
  FaDownload,
  FaPrint,
  FaTimes,
  FaTicketAlt,
  FaExclamationTriangle,
  FaMoneyBill,
  FaCheck,
  FaUserCircle,
  FaMapMarkerAlt
} from "react-icons/fa";
import { Link } from "react-router-dom";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { 
  faSearch, faFilter, faEye, faEdit, faTrash, 
  faUser, faEnvelope, faPhone, faCalendar, faMoneyBill,
  faTicketAlt, faCheck, faClock, faTimes, faSort,
  faSortUp, faSortDown, faChevronLeft, faChevronRight,
  faUsers, faCheckCircle, faHourglassHalf, faBan
} from '@fortawesome/free-solid-svg-icons';
import { formatDate, formatCurrency } from '../../utils/formatters';
import '../../styles/bookings.css';
import { Dropdown } from 'react-bootstrap';
import EventService from '../../services/EventService';

const BookingManagement = () => {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [filterEvent, setFilterEvent] = useState("all");
  const [events, setEvents] = useState([]);
  const [showDetailsModal, setShowDetailsModal] = useState(false);
  const [selectedBooking, setSelectedBooking] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);
  const [totalItems, setTotalItems] = useState(0);
  const [totalPages, setTotalPages] = useState(0);
  const [sortField, setSortField] = useState("date");
  const [sortDirection, setSortDirection] = useState("desc");
  const [selectedBookings, setSelectedBookings] = useState([]);
  const [showPrintModal, setShowPrintModal] = useState(false);
  const [dateRange, setDateRange] = useState({
    startDate: "",
    endDate: ""
  });
  const [totalStats, setTotalStats] = useState({
    totalBookings: 0,
    pendingBookings: 0,
    confirmedBookings: 0,
    cancelledBookings: 0,
    totalRevenue: 0
  });
  const [pendingApprovals, setPendingApprovals] = useState([]);
  const [alertMessage, setAlertMessage] = useState(null);

  // Configure axios to use the backend URL
  const API_BASE_URL = "http://localhost:3200";
  axios.defaults.baseURL = API_BASE_URL;

  useEffect(() => {
    fetchBookingsAndEvents();
  }, [currentPage, itemsPerPage, sortField, sortDirection]);

  useEffect(() => {
    const fetchPendingApprovals = async () => {
      try {
        const data = await EventService.getPendingBookings();
        setPendingApprovals(data || []);
      } catch (error) {
        console.error('Error fetching pending approval requests:', error);
      }
    };
    
    fetchPendingApprovals();
  }, []);

  const fetchBookingsAndEvents = async () => {
    setLoading(true);
    try {
      // In a real app, this would be an API call
      // const response = await axios.get(
      //   `${API_BASE_URL}/api/bookings?page=${currentPage}&status=${filterStatus}&eventId=${filterEvent}&search=${searchTerm}&sortBy=${sortField}&sortDirection=${sortDirection}`
      // );
      
      // For demo purposes using mock data
      await new Promise(resolve => setTimeout(resolve, 800)); // Simulate API delay
      
      // Mock events data
      const demoEvents = [
        { id: 1, title: 'Wedding Ceremony' },
        { id: 2, title: 'Corporate Event' },
        { id: 3, title: 'Birthday Party' },
        { id: 4, title: 'Anniversary Celebration' }
      ];
      
      // Mock bookings data
      const demoBookings = [
        {
          id: 'BK001',
          eventType: 'Wedding Ceremony',
          eventTypeId: 1,
          venueName: 'Royal Grand Palace',
          date: '2023-12-15',
          price: 50000,
          status: 'confirmed',
          customer: {
            name: 'Rahul Sharma',
            email: 'rahul.sharma@example.com',
            phone: '+91 9876543210',
            address: 'Mumbai, Maharashtra'
          },
          bookingDetails: {
            guestCount: 200,
            bookingDate: '2023-10-05',
            notes: 'Need special decoration and catering service'
          }
        },
        {
          id: 'BK002',
          eventType: 'Corporate Event',
          eventTypeId: 2,
          venueName: 'Business Convention Center',
          date: '2023-11-28',
          price: 35000,
          status: 'pending',
          customer: {
            name: 'Priya Singh',
            email: 'priya.singh@example.com',
            phone: '+91 8765432109',
            address: 'Delhi, India'
          },
          bookingDetails: {
            guestCount: 150,
            bookingDate: '2023-10-10',
            notes: 'Projector and sound system required'
          }
        },
        {
          id: 'BK003',
          eventType: 'Birthday Party',
          eventTypeId: 3,
          venueName: 'Celebration Garden',
          date: '2023-12-05',
          price: 25000,
          status: 'cancelled',
          customer: {
            name: 'Amit Patel',
            email: 'amit.patel@example.com',
            phone: '+91 7654321098',
            address: 'Ahmedabad, Gujarat'
          },
          bookingDetails: {
            guestCount: 50,
            bookingDate: '2023-09-20',
            notes: 'Cancellation due to personal reasons'
          }
        },
        {
          id: 'BK004',
          eventType: 'Anniversary Celebration',
          eventTypeId: 4,
          venueName: 'Seaside Resort',
          date: '2023-12-20',
          price: 40000,
          status: 'confirmed',
          customer: {
            name: 'Neha Gupta',
            email: 'neha.gupta@example.com',
            phone: '+91 6543210987',
            address: 'Goa, India'
          },
          bookingDetails: {
            guestCount: 80,
            bookingDate: '2023-10-15',
            notes: 'Beachside setup preferred'
          }
        },
        {
          id: 'BK005',
          eventType: 'Wedding Ceremony',
          eventTypeId: 1,
          venueName: 'Heritage Palace',
          date: '2024-01-10',
          price: 65000,
          status: 'confirmed',
          customer: {
            name: 'Aditya Verma',
            email: 'aditya.verma@example.com',
            phone: '+91 5432109876',
            address: 'Jaipur, Rajasthan'
          },
          bookingDetails: {
            guestCount: 300,
            bookingDate: '2023-10-18',
            notes: 'Traditional Rajasthani theme'
          }
        },
        {
          id: 'BK006',
          eventType: 'Corporate Event',
          eventTypeId: 2,
          venueName: 'Tech Hub Conference Center',
          date: '2023-12-12',
          price: 30000,
          status: 'pending',
          customer: {
            name: 'Ravi Kumar',
            email: 'ravi.kumar@example.com',
            phone: '+91 4321098765',
            address: 'Bangalore, Karnataka'
          },
          bookingDetails: {
            guestCount: 120,
            bookingDate: '2023-10-25',
            notes: 'High-speed internet and tech setup required'
          }
        },
        {
          id: 'BK007',
          eventType: 'Birthday Party',
          eventTypeId: 3,
          venueName: 'Fun Zone',
          date: '2023-11-30',
          price: 20000,
          status: 'confirmed',
          customer: {
            name: 'Sanjay Mehta',
            email: 'sanjay.mehta@example.com',
            phone: '+91 3210987654',
            address: 'Chennai, Tamil Nadu'
          },
          bookingDetails: {
            guestCount: 40,
            bookingDate: '2023-10-05',
            notes: 'Kids-friendly setup with games'
          }
        },
        {
          id: 'BK008',
          eventType: 'Anniversary Celebration',
          eventTypeId: 4,
          venueName: 'Luxury Hotel Banquet',
          date: '2024-02-05',
          price: 45000,
          status: 'pending',
          customer: {
            name: 'Meera Reddy',
            email: 'meera.reddy@example.com',
            phone: '+91 2109876543',
            address: 'Hyderabad, Telangana'
          },
          bookingDetails: {
            guestCount: 90,
            bookingDate: '2023-10-28',
            notes: 'Special decorations for silver jubilee'
          }
        },
        {
          id: 'BK009',
          eventType: 'Wedding Ceremony',
          eventTypeId: 1,
          venueName: 'Garden Grand',
          date: '2024-01-25',
          price: 55000,
          status: 'confirmed',
          customer: {
            name: 'Vikram Singh',
            email: 'vikram.singh@example.com',
            phone: '+91 1098765432',
            address: 'Lucknow, Uttar Pradesh'
          },
          bookingDetails: {
            guestCount: 250,
            bookingDate: '2023-11-01',
            notes: 'Open air arrangement with tent'
          }
        },
        {
          id: 'BK010',
          eventType: 'Corporate Event',
          eventTypeId: 2,
          venueName: 'Business Tower',
          date: '2023-12-18',
          price: 38000,
          status: 'cancelled',
          customer: {
            name: 'Kiran Shah',
            email: 'kiran.shah@example.com',
            phone: '+91 0987654321',
            address: 'Pune, Maharashtra'
          },
          bookingDetails: {
            guestCount: 140,
            bookingDate: '2023-10-12',
            notes: 'Cancellation due to budget constraints'
          }
        }
      ];
      
      // Filter bookings based on search term, status, and event type
      let filteredBookings = [...demoBookings];
      
      // Apply status filter
      if (filterStatus !== 'all') {
        filteredBookings = filteredBookings.filter(booking => booking.status === filterStatus);
      }
      
      // Apply event type filter
      if (filterEvent !== 'all') {
        filteredBookings = filteredBookings.filter(booking => booking.eventTypeId === parseInt(filterEvent));
      }
      
      // Apply search term filter (search in name, venue, email, booking ID)
      if (searchTerm.trim() !== '') {
        const searchLower = searchTerm.toLowerCase();
        filteredBookings = filteredBookings.filter(booking =>
          booking.id.toLowerCase().includes(searchLower) ||
          booking.venueName.toLowerCase().includes(searchLower) ||
          booking.customer.name.toLowerCase().includes(searchLower) ||
          booking.customer.email.toLowerCase().includes(searchLower)
        );
      }
      
      // Apply sorting
      filteredBookings.sort((a, b) => {
        let comparison = 0;
        
        if (sortField === 'date') {
          comparison = new Date(a.date) - new Date(b.date);
        } else if (sortField === 'price') {
          comparison = a.price - b.price;
        } else if (sortField === 'name') {
          comparison = a.customer.name.localeCompare(b.customer.name);
        } else if (sortField === 'venue') {
          comparison = a.venueName.localeCompare(b.venueName);
        }
        
        return sortDirection === 'asc' ? comparison : -comparison;
      });
      
      // Calculate pagination
      const totalItems = filteredBookings.length;
      const totalPages = Math.ceil(totalItems / itemsPerPage);
      const startIndex = (currentPage - 1) * itemsPerPage;
      const paginatedBookings = filteredBookings.slice(startIndex, startIndex + itemsPerPage);
      
      // Calculate total statistics
      const totalStats = filteredBookings.reduce((stats, booking) => {
        stats.totalBookings++;
        stats.totalRevenue += booking.price;
        
        if (booking.status === 'confirmed') stats.confirmedBookings++;
        else if (booking.status === 'pending') stats.pendingBookings++;
        else if (booking.status === 'cancelled') stats.cancelledBookings++;
        
        return stats;
      }, {
        totalBookings: 0,
        confirmedBookings: 0,
        pendingBookings: 0,
        cancelledBookings: 0,
        totalRevenue: 0
      });
      
      // Update state
      setEvents(demoEvents);
      setBookings(paginatedBookings);
      setTotalItems(totalItems);
      setTotalPages(totalPages);
      setTotalStats(totalStats);
    } catch (error) {
      console.error("Error fetching bookings:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleViewDetails = (bookingId) => {
    if (selectedBooking === bookingId) {
      setSelectedBooking(null);
    } else {
      setSelectedBooking(bookingId);
    }
  };

  const handleStatusChange = async (bookingId, newStatus) => {
    try {
      setLoading(true);
      
      // In a real app, this would be an API call
      // await axios.patch(`${API_BASE_URL}/api/bookings/${bookingId}`, { status: newStatus });
      
      // For demo, simulate API call
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // Update local state
      setBookings(bookings.map(booking => 
        booking.id === bookingId ? { ...booking, status: newStatus } : booking
      ));
      
      // Update statistics based on status change
      const updatedStats = { ...totalStats };
      
      // Find the booking being updated
      const bookingToUpdate = bookings.find(booking => booking.id === bookingId);
      if (bookingToUpdate) {
        // Decrement the old status count
        if (bookingToUpdate.status === 'confirmed') updatedStats.confirmedBookings--;
        else if (bookingToUpdate.status === 'pending') updatedStats.pendingBookings--;
        else if (bookingToUpdate.status === 'cancelled') updatedStats.cancelledBookings--;
        
        // Increment the new status count
        if (newStatus === 'confirmed') updatedStats.confirmedBookings++;
        else if (newStatus === 'pending') updatedStats.pendingBookings++;
        else if (newStatus === 'cancelled') updatedStats.cancelledBookings++;
      }
      
      setTotalStats(updatedStats);
      
      alert(`Booking ${bookingId} status updated to ${newStatus}`);
    } catch (error) {
      console.error(`Error updating booking status:`, error);
      alert('Failed to update booking status');
    } finally {
      setLoading(false);
    }
  };

  const handleContactCustomer = (email) => {
    window.location.href = `mailto:${email}`;
  };

  const handleSort = (field) => {
    if (sortField === field) {
      // Toggle direction if same field
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      // New field, default to descending
      setSortField(field);
      setSortDirection('desc');
    }
  };

  const handleSearch = (e) => {
    e.preventDefault();
    setCurrentPage(1); // Reset to first page when searching
    // The API call is triggered by useEffect when searchTerm changes
  };

  const handleFilterChange = (status) => {
    setFilterStatus(status);
    setCurrentPage(1); // Reset to first page when filtering
  };

  const handleEventFilterChange = (eventId) => {
    setFilterEvent(eventId);
    setCurrentPage(1); // Reset to first page when filtering
  };

  const handlePageChange = (page) => {
    setCurrentPage(page);
  };

  const handleApprovalRequest = async (bookingId, approved, reason = '') => {
    try {
      await EventService.approveBooking(bookingId, approved, reason);
      // Remove the approved/rejected booking from the list
      setPendingApprovals(pendingApprovals.filter(booking => booking._id !== bookingId));
      
      // Show success message
      setAlertMessage({
        type: 'success',
        message: `Booking ${approved ? 'approved' : 'rejected'} successfully`
      });
    } catch (error) {
      console.error(`Error ${approved ? 'approving' : 'rejecting'} booking:`, error);
      setAlertMessage({
        type: 'danger',
        message: `Failed to ${approved ? 'approve' : 'reject'} booking. Please try again.`
      });
    }
  };

  // Render pagination controls
  const renderPagination = () => {
    const totalPages = Math.ceil(totalItems / itemsPerPage);
    
    if (totalPages <= 1) return null;
    
    const pages = [];
    const maxVisiblePages = 5;
    
    let startPage = Math.max(1, currentPage - Math.floor(maxVisiblePages / 2));
    let endPage = Math.min(totalPages, startPage + maxVisiblePages - 1);
    
    if (endPage - startPage + 1 < maxVisiblePages) {
      startPage = Math.max(1, endPage - maxVisiblePages + 1);
    }
    
    for (let i = startPage; i <= endPage; i++) {
      pages.push(
        <li key={i} className={`page-item ${currentPage === i ? 'active' : ''}`}>
          <button className="page-link" onClick={() => handlePageChange(i)}>
            {i}
          </button>
        </li>
      );
    }
    
    return (
      <nav>
        <ul className="pagination justify-content-center">
          <li className={`page-item ${currentPage === 1 ? 'disabled' : ''}`}>
            <button 
              className="page-link" 
              onClick={() => handlePageChange(currentPage - 1)}
              disabled={currentPage === 1}
            >
              Previous
            </button>
          </li>
          
          {startPage > 1 && (
            <>
              <li className="page-item">
                <button className="page-link" onClick={() => handlePageChange(1)}>1</button>
              </li>
              {startPage > 2 && <li className="page-item disabled"><span className="page-link">...</span></li>}
            </>
          )}
          
          {pages}
          
          {endPage < totalPages && (
            <>
              {endPage < totalPages - 1 && <li className="page-item disabled"><span className="page-link">...</span></li>}
              <li className="page-item">
                <button className="page-link" onClick={() => handlePageChange(totalPages)}>{totalPages}</button>
              </li>
            </>
          )}
          
          <li className={`page-item ${currentPage === totalPages ? 'disabled' : ''}`}>
            <button 
              className="page-link" 
              onClick={() => handlePageChange(currentPage + 1)}
              disabled={currentPage === totalPages}
            >
              Next
            </button>
          </li>
        </ul>
      </nav>
    );
  };

  // Get status badge class
  const getStatusBadgeClass = (status) => {
    switch (status) {
      case 'confirmed':
        return 'badge bg-success';
      case 'pending':
        return 'badge bg-warning text-dark';
      case 'cancelled':
        return 'badge bg-danger';
      default:
        return 'badge bg-secondary';
    }
  };

  // Format date
  const formatDate = (dateString) => {
    try {
      return format(new Date(dateString), 'dd MMM yyyy');
    } catch (error) {
      return dateString;
    }
  };

  // Format currency
  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(amount);
  };

  return (
    <motion.div 
      className="booking-management-container"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.3 }}
    >
      <h1 className="page-title">Booking Management</h1>
      
      {/* Stats Cards */}
      <div className="row stats-cards mb-4">
        <div className="col-md-3 mb-3">
          <div className="card stats-card">
            <div className="card-body">
              <h5 className="card-title">Total Bookings</h5>
              <p className="card-text stats-value">{totalStats.totalBookings}</p>
            </div>
          </div>
        </div>
        
        <div className="col-md-3 mb-3">
          <div className="card stats-card confirmed-card">
            <div className="card-body">
              <h5 className="card-title">Confirmed</h5>
              <p className="card-text stats-value">{totalStats.confirmedBookings}</p>
            </div>
          </div>
        </div>
        
        <div className="col-md-3 mb-3">
          <div className="card stats-card pending-card">
            <div className="card-body">
              <h5 className="card-title">Pending</h5>
              <p className="card-text stats-value">{totalStats.pendingBookings}</p>
            </div>
          </div>
        </div>
        
        <div className="col-md-3 mb-3">
          <div className="card stats-card revenue-card">
            <div className="card-body">
              <h5 className="card-title">Total Revenue</h5>
              <p className="card-text stats-value">{formatCurrency(totalStats.totalRevenue)}</p>
            </div>
          </div>
        </div>
      </div>
      
      {/* Filters and Search */}
      <div className="row mb-4">
        <div className="col-md-4 mb-3">
          <form onSubmit={handleSearch}>
            <div className="input-group">
              <input
                type="text"
                className="form-control"
                placeholder="Search bookings..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
              <button className="btn btn-primary" type="submit">
                <FaSearch />
              </button>
            </div>
          </form>
        </div>
        
        <div className="col-md-4 mb-3">
          <div className="dropdown">
            <Dropdown>
              <Dropdown.Toggle variant="outline-secondary" className="w-100">
                <FaFilter className="me-2" />
                {filterStatus === 'all' ? 'All Statuses' : 
                 filterStatus === 'confirmed' ? 'Confirmed' :
                 filterStatus === 'pending' ? 'Pending' : 'Cancelled'}
              </Dropdown.Toggle>
              
              <Dropdown.Menu>
                <Dropdown.Item onClick={() => handleFilterChange('all')}>All Statuses</Dropdown.Item>
                <Dropdown.Item onClick={() => handleFilterChange('confirmed')}>Confirmed</Dropdown.Item>
                <Dropdown.Item onClick={() => handleFilterChange('pending')}>Pending</Dropdown.Item>
                <Dropdown.Item onClick={() => handleFilterChange('cancelled')}>Cancelled</Dropdown.Item>
              </Dropdown.Menu>
            </Dropdown>
          </div>
        </div>
        
        <div className="col-md-4 mb-3">
          <div className="dropdown">
            <Dropdown>
              <Dropdown.Toggle variant="outline-secondary" className="w-100">
                <FaCalendarAlt className="me-2" />
                {filterEvent === 'all' ? 'All Event Types' : 
                 events.find(e => e.id === parseInt(filterEvent))?.title || 'Select Event Type'}
              </Dropdown.Toggle>
              
              <Dropdown.Menu>
                <Dropdown.Item onClick={() => handleEventFilterChange('all')}>All Event Types</Dropdown.Item>
                {events.map(event => (
                  <Dropdown.Item 
                    key={event.id} 
                    onClick={() => handleEventFilterChange(event.id)}
                  >
                    {event.title}
                  </Dropdown.Item>
                ))}
              </Dropdown.Menu>
            </Dropdown>
          </div>
        </div>
      </div>
      
      {/* Pending Approval Requests Section */}
      {pendingApprovals.length > 0 && (
        <div className="mb-5">
          <div className="card border-0 shadow-sm">
            <div className="card-header bg-white py-3">
              <h5 className="mb-0 fw-bold">Pending Approval Requests</h5>
            </div>
            <div className="card-body p-0">
              <div className="table-responsive">
                <table className="table table-hover mb-0">
                  <thead className="bg-light">
                    <tr>
                      <th>Customer</th>
                      <th>Event Type</th>
                      <th>Contact</th>
                      <th>Guest Count</th>
                      <th>Total Amount</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {pendingApprovals.map(booking => (
                      <tr key={booking._id}>
                        <td>{booking.contactName}</td>
                        <td>{booking.eventType}</td>
                        <td>
                          <div>{booking.contactEmail}</div>
                          <div>{booking.contactPhone}</div>
                        </td>
                        <td>{booking.guestCount}</td>
                        <td>₹{booking.totalAmount.toLocaleString('en-IN')}</td>
                        <td>
                          <button
                            className="btn btn-sm btn-success me-2"
                            onClick={() => handleApprovalRequest(booking._id, true)}
                          >
                            Approve
                          </button>
                          <button
                            className="btn btn-sm btn-danger"
                            onClick={() => {
                              const reason = prompt('Please provide a reason for rejection:');
                              if (reason !== null) {
                                handleApprovalRequest(booking._id, false, reason);
                              }
                            }}
                          >
                            Reject
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      )}
      
      {/* Bookings Table */}
      {loading ? (
        <div className="text-center my-5">
          <div className="spinner-border text-primary" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
          <p className="mt-2">Loading bookings...</p>
        </div>
      ) : bookings.length === 0 ? (
        <div className="alert alert-info text-center">
          <p className="mb-0">No bookings found. Try changing your filters.</p>
        </div>
      ) : (
        <div className="table-responsive">
          <table className="table table-hover booking-table">
            <thead>
              <tr>
                <th scope="col">Booking ID</th>
                <th 
                  scope="col" 
                  className="sortable"
                  onClick={() => handleSort('name')}
                >
                  Customer Name
                  {sortField === 'name' && (
                    sortDirection === 'asc' ? <FaChevronUp className="ms-1" /> : <FaChevronDown className="ms-1" />
                  )}
                </th>
                <th 
                  scope="col" 
                  className="sortable"
                  onClick={() => handleSort('venue')}
                >
                  Venue
                  {sortField === 'venue' && (
                    sortDirection === 'asc' ? <FaChevronUp className="ms-1" /> : <FaChevronDown className="ms-1" />
                  )}
                </th>
                <th 
                  scope="col" 
                  className="sortable"
                  onClick={() => handleSort('date')}
                >
                  Event Date
                  {sortField === 'date' && (
                    sortDirection === 'asc' ? <FaChevronUp className="ms-1" /> : <FaChevronDown className="ms-1" />
                  )}
                </th>
                <th 
                  scope="col" 
                  className="sortable text-end"
                  onClick={() => handleSort('price')}
                >
                  Amount
                  {sortField === 'price' && (
                    sortDirection === 'asc' ? <FaChevronUp className="ms-1" /> : <FaChevronDown className="ms-1" />
                  )}
                </th>
                <th scope="col" className="text-center">Status</th>
                <th scope="col" className="text-center">Actions</th>
              </tr>
            </thead>
            <tbody>
              {bookings.map(booking => (
                <React.Fragment key={booking.id}>
                  <tr className={selectedBooking === booking.id ? 'expanded-row' : ''}>
                    <td>{booking.id}</td>
                    <td>{booking.customer.name}</td>
                    <td>{booking.venueName}</td>
                    <td>{formatDate(booking.date)}</td>
                    <td className="text-end">{formatCurrency(booking.price)}</td>
                    <td className="text-center">
                      <span className={getStatusBadgeClass(booking.status)}>
                        {booking.status.charAt(0).toUpperCase() + booking.status.slice(1)}
                      </span>
                    </td>
                    <td className="text-center">
                      <div className="d-flex justify-content-center gap-2">
                        <button 
                          className="btn btn-sm btn-primary"
                          onClick={() => handleViewDetails(booking.id)}
                          title="View Details"
                        >
                          <FaEye />
                        </button>
                        
                        <Dropdown>
                          <Dropdown.Toggle variant="outline-secondary" size="sm">
                            Status
                          </Dropdown.Toggle>
                          
                          <Dropdown.Menu>
                            <Dropdown.Item 
                              onClick={() => handleStatusChange(booking.id, 'confirmed')}
                              disabled={booking.status === 'confirmed'}
                            >
                              <FaCheck className="text-success me-2" /> Confirm
                            </Dropdown.Item>
                            <Dropdown.Item 
                              onClick={() => handleStatusChange(booking.id, 'pending')}
                              disabled={booking.status === 'pending'}
                            >
                              <FaCalendarAlt className="text-warning me-2" /> Mark as Pending
                            </Dropdown.Item>
                            <Dropdown.Item 
                              onClick={() => handleStatusChange(booking.id, 'cancelled')}
                              disabled={booking.status === 'cancelled'}
                            >
                              <FaTimes className="text-danger me-2" /> Cancel
                            </Dropdown.Item>
                          </Dropdown.Menu>
                        </Dropdown>
                      </div>
                    </td>
                  </tr>
                  
                  {selectedBooking === booking.id && (
                    <tr className="details-row">
                      <td colSpan="7">
                        <div className="booking-details">
                          <div className="row">
                            <div className="col-md-6">
                              <h5 className="details-heading">Customer Information</h5>
                              <div className="customer-info">
                                <p>
                                  <FaUserCircle className="me-2" /> 
                                  <strong>Name:</strong> {booking.customer.name}
                                </p>
                                <p>
                                  <FaEnvelope className="me-2" /> 
                                  <strong>Email:</strong> {booking.customer.email}
                                  <button 
                                    className="btn btn-sm btn-link ms-2"
                                    onClick={() => handleContactCustomer(booking.customer.email)}
                                  >
                                    Contact
                                  </button>
                                </p>
                                <p>
                                  <FaPhoneAlt className="me-2" /> 
                                  <strong>Phone:</strong> {booking.customer.phone}
                                </p>
                                <p>
                                  <FaMapMarkerAlt className="me-2" /> 
                                  <strong>Location:</strong> {booking.customer.address}
                                </p>
                              </div>
                            </div>
                            
                            <div className="col-md-6">
                              <h5 className="details-heading">Booking Details</h5>
                              <div className="booking-info">
                                <p><strong>Event Type:</strong> {booking.eventType}</p>
                                <p><strong>Venue:</strong> {booking.venueName}</p>
                                <p><strong>Guest Count:</strong> {booking.bookingDetails.guestCount}</p>
                                <p><strong>Booking Date:</strong> {formatDate(booking.bookingDetails.bookingDate)}</p>
                                <p><strong>Event Date:</strong> {formatDate(booking.date)}</p>
                                <p><strong>Amount:</strong> {formatCurrency(booking.price)}</p>
                                <p><strong>Status:</strong> <span className={getStatusBadgeClass(booking.status)}>
                                  {booking.status.charAt(0).toUpperCase() + booking.status.slice(1)}
                                </span></p>
                                {booking.bookingDetails.notes && (
                                  <div className="notes-section">
                                    <p><strong>Notes:</strong></p>
                                    <p className="notes-text">{booking.bookingDetails.notes}</p>
                                  </div>
                                )}
                              </div>
                            </div>
                          </div>
                        </div>
                      </td>
                    </tr>
                  )}
                </React.Fragment>
              ))}
            </tbody>
          </table>
        </div>
      )}
      
      {/* Pagination */}
      <div className="d-flex justify-content-between align-items-center mt-4">
        <div>
          Showing {totalItems > 0 ? (currentPage - 1) * itemsPerPage + 1 : 0} to {Math.min(currentPage * itemsPerPage, totalItems)} of {totalItems} bookings
        </div>
        {renderPagination()}
      </div>
      
      {/* Alert Messages */}
      {alertMessage && (
        <div className={`alert alert-${alertMessage.type} mt-4`}>
          {alertMessage.message}
        </div>
      )}
      
      <style jsx>{`
        .booking-management-container {
          padding: 20px;
        }
        
        .page-title {
          margin-bottom: 30px;
          font-weight: 600;
        }
        
        .stats-cards .card {
          border-radius: 10px;
          box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
          transition: transform 0.2s ease;
        }
        
        .stats-cards .card:hover {
          transform: translateY(-5px);
        }
        
        .stats-card .card-title {
          font-size: 0.9rem;
          font-weight: 600;
          color: #6c757d;
          margin-bottom: 5px;
        }
        
        .stats-value {
          font-size: 1.8rem;
          font-weight: 700;
          margin-bottom: 0;
        }
        
        .confirmed-card {
          border-left: 5px solid #28a745;
        }
        
        .pending-card {
          border-left: 5px solid #ffc107;
        }
        
        .revenue-card {
          border-left: 5px solid #0d6efd;
        }
        
        .booking-table {
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }
        
        .booking-table th {
          background-color: #f8f9fa;
        }
        
        .sortable {
          cursor: pointer;
          user-select: none;
        }
        
        .expanded-row {
          background-color: #f8f9fa;
        }
        
        .details-row td {
          padding: 0;
        }
        
        .booking-details {
          padding: 20px;
          background-color: #f8f9fa;
          border-top: 1px solid #dee2e6;
        }
        
        .details-heading {
          font-size: 1.1rem;
          font-weight: 600;
          margin-bottom: 15px;
          color: #495057;
        }
        
        .notes-section {
          margin-top: 10px;
          padding: 10px;
          background-color: rgba(255, 255, 255, 0.5);
          border-radius: 5px;
        }
        
        .notes-text {
          font-style: italic;
          color: #666;
        }
      `}</style>
    </motion.div>
  );
};

export default BookingManagement; 