import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  FaArrowLeft, 
  FaArrowRight,
  FaCheck,
  FaImage,
  FaPlus,
  FaTrash,
  FaWifi,
  FaParking,
  FaSnowflake, 
  FaUtensils,
  FaMusic,
  FaBuilding,
  FaSave
} from 'react-icons/fa';
import EventService from '../../services/EventService';
import './AddEvent.css'; // Import the CSS file

export const AddEvent = () => {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [eventImagePreview, setEventImagePreview] = useState(null);
  const [venueImagePreviews, setVenueImagePreviews] = useState([]);
  const [errors, setErrors] = useState({});
  const [alertMessage, setAlertMessage] = useState(null);
  
  // State for event categories
  const [eventCategories, setEventCategories] = useState([]);
  const [loadingCategories, setLoadingCategories] = useState(false);
  
  // Form data
  const [formData, setFormData] = useState({
    // Step 1: Event Details
    eventType: '',
    categoryId: '',  // Added categoryId field
    description: '',
    eventImage: null,
    
    // Step 2: Location
    city: '',
    area: '',
    
    // Step 3: Venue Details
    venueName: '',
    venueDescription: '',
    address: '',
    capacity: '',
    price: '',
    amenities: [],
    venueImages: [],
    contactInfo: {
      phone: '',
      email: '',
      website: ''
    }
  });
  
  // Fetch event categories from API
  useEffect(() => {
    const fetchEventCategories = async () => {
      setLoadingCategories(true);
      try {
        const categories = await EventService.getEventCategories();
        if (categories && categories.length > 0) {
          setEventCategories(categories);
          console.log('Fetched event categories:', categories);
        } else {
          // Use fallback categories if API fails
          setEventCategories([
            { id: 1, title: 'Wedding', description: 'Wedding ceremonies and receptions' },
            { id: 2, title: 'Corporate Event', description: 'Business meetings and conferences' },
            { id: 3, title: 'Birthday Party', description: 'Birthday celebrations' },
            { id: 4, title: 'Anniversary Celebration', description: 'Anniversary parties' },
            { id: 5, title: 'Family Gathering', description: 'Family get-togethers' },
            { id: 6, title: 'Engagement Ceremony', description: 'Engagement celebrations' }
          ]);
        }
      } catch (error) {
        console.error('Error fetching event categories:', error);
      } finally {
        setLoadingCategories(false);
      }
    };
    
    fetchEventCategories();
  }, []);
  
  // Available event types from categories
  const eventTypes = eventCategories.map(category => category.title);
  
  const cities = [
    'Mumbai',
    'Delhi',
    'Bangalore',
    'Hyderabad',
    'Chennai',
    'Kolkata',
    'Ahmedabad',
    'Pune'
  ];
  
  const availableAmenities = [
    'Catering', 
    'Parking', 
    'WiFi', 
    'AC', 
    'Projector', 
    'Decoration', 
    'DJ', 
    'Open Air'
  ];
  
  // Handle form change
  const handleChange = (e) => {
    const { name, value } = e.target;
    
    if (name.includes('.')) {
      const [parent, child] = name.split('.');
      setFormData({
        ...formData,
        [parent]: {
          ...formData[parent],
          [child]: value
        }
      });
    } else {
      // Special handling for eventType to also set categoryId
      if (name === 'eventType') {
        const selectedCategory = eventCategories.find(cat => cat.title === value);
        setFormData({
          ...formData,
          [name]: value,
          categoryId: selectedCategory ? selectedCategory.id : ''
        });
      } else {
        setFormData({
          ...formData,
          [name]: value
        });
      }
    }
  };
  
  // Handle event image upload
  const handleEventImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setFormData({
        ...formData,
        eventImage: file
      });
      
      const reader = new FileReader();
      reader.onloadend = () => {
        setEventImagePreview(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };
  
  // Handle venue images upload
  const handleVenueImagesChange = (e) => {
    const files = Array.from(e.target.files);
    if (files.length > 0) {
      setFormData({
        ...formData,
        venueImages: [...formData.venueImages, ...files]
      });
      
      files.forEach(file => {
        const reader = new FileReader();
        reader.onloadend = () => {
          setVenueImagePreviews(prev => [...prev, reader.result]);
        };
        reader.readAsDataURL(file);
      });
    }
  };
  
  // Remove venue image
  const handleRemoveVenueImage = (index) => {
    const updatedImages = [...formData.venueImages];
    updatedImages.splice(index, 1);
    
    const updatedPreviews = [...venueImagePreviews];
    updatedPreviews.splice(index, 1);
    
    setFormData({
      ...formData,
      venueImages: updatedImages
    });
    setVenueImagePreviews(updatedPreviews);
  };
  
  // Toggle amenity selection
  const handleAmenityToggle = (amenity) => {
    if (formData.amenities.includes(amenity)) {
      setFormData({
        ...formData,
        amenities: formData.amenities.filter(a => a !== amenity)
      });
    } else {
      setFormData({
        ...formData,
        amenities: [...formData.amenities, amenity]
      });
    }
  };
  
  // Step validation
  const validateStep = (step) => {
    const newErrors = {};
    
    if (step === 1) {
      if (!formData.eventType) newErrors.eventType = 'Event type is required';
    } else if (step === 2) {
      if (!formData.city) newErrors.city = 'City is required';
    } else if (step === 3) {
      if (!formData.venueName.trim()) newErrors.venueName = 'Venue name is required';
      if (!formData.address.trim()) newErrors.address = 'Address is required';
      if (!formData.capacity.trim()) newErrors.capacity = 'Capacity is required';
      if (!formData.price.trim()) newErrors.price = 'Price is required';
      if (!formData.contactInfo.phone.trim()) newErrors.phone = 'Phone number is required';
      if (!formData.contactInfo.email.trim()) newErrors.email = 'Email is required';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  // Move to next step
  const handleNext = () => {
    if (validateStep(currentStep)) {
      setCurrentStep(currentStep + 1);
      window.scrollTo(0, 0);
    }
  };
  
  // Move to previous step
  const handlePrevious = () => {
    setCurrentStep(currentStep - 1);
    window.scrollTo(0, 0);
  };
  
  // Submit form
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateStep(3)) return;
    
    setLoading(true);
    setAlertMessage(null);
    
    try {
      // Convert form data to match API format - exactly as the backend model expects
      const eventData = {
        name: formData.venueName || formData.eventType, // Use venueName as event name or fallback to eventType
        eventType: formData.eventType,
        description: formData.description,
        location: `${formData.address}, ${formData.area}, ${formData.city}`,
        date: new Date(), // Current date as default
        capacity: parseInt(formData.capacity),
        price: parseInt(formData.price) || 0,
        category: formData.eventType,
        categoryId: parseInt(formData.categoryId) || eventCategories.find(cat => cat.title === formData.eventType)?.id || 1,
        duration: "3 hours", // Default duration
        status: "active", // Make sure the event is active by default
        organizer: JSON.parse(sessionStorage.getItem('user') || '{}')._id,
        contact: {
          email: formData.contactInfo.email,
          phone: formData.contactInfo.phone
        }
      };
      
      // Add image data if available
      if (eventImagePreview) {
        eventData.image = eventImagePreview;
      }
      
      console.log('Creating event with data:', eventData);
      
      // Save to backend API
      const savedEvent = await EventService.createEvent(eventData);
      console.log('Event saved successfully:', savedEvent);
      
      // Show success message
      setAlertMessage({
        type: 'success',
        text: 'Event created successfully! Redirecting to events page...'
      });
      
      // Clear form data from localStorage to prevent stale data
      localStorage.removeItem('eventFormData');
      
      // Reset form
      setFormData({
        eventType: '',
        categoryId: '',
        description: '',
        eventImage: null,
        city: '',
        area: '',
        venueName: '',
        venueDescription: '',
        address: '',
        capacity: '',
        price: '',
        amenities: [],
        venueImages: [],
        contactInfo: {
          phone: '',
          email: '',
          website: ''
        }
      });
      setEventImagePreview(null);
      setVenueImagePreviews([]);
      setErrors({});
      
      // Navigate to events page with success parameter
      setTimeout(() => {
        navigate('/organizer/events', { 
          state: { 
            eventCreated: true, 
            eventId: savedEvent._id || 'new_event',
            message: 'Event created successfully'
          }
        });
      }, 2000);
    } catch (error) {
      console.error('Error creating event:', error);
      setAlertMessage({
        type: 'danger',
        text: `Error creating event: ${error.message || 'Unknown error occurred'}`
      });
    } finally {
      setLoading(false);
      window.scrollTo(0, 0); // Scroll to top to make sure the alert is visible
    }
  };
  
  // Get amenity icon
  const getAmenityIcon = (amenity) => {
    switch(amenity) {
      case 'WiFi': return <FaWifi />;
      case 'Parking': return <FaParking />;
      case 'AC': return <FaSnowflake />;
      case 'Catering': return <FaUtensils />;
      case 'DJ': return <FaMusic />;
      default: return <FaBuilding />;
    }
  };
  
  // Render step content
  const renderStepContent = () => {
    // Add fallback content
    let content = <div className="alert alert-danger">Error loading form content</div>;
    
    try {
      switch (currentStep) {
        case 1:
          content = (
            <div className="step-content">
              <h4 className="mb-3">Event Details</h4>
              <div className="mb-3">
                <label htmlFor="eventType" className="form-label">Event Category</label>
                {loadingCategories ? (
                  <div className="d-flex align-items-center">
                    <div className="spinner-border spinner-border-sm me-2" role="status">
                      <span className="visually-hidden">Loading...</span>
                    </div>
                    <span>Loading categories...</span>
                  </div>
                ) : (
                  <select
                    className={`form-select ${errors.eventType ? 'is-invalid' : ''}`}
                    id="eventType"
                    name="eventType"
                    value={formData.eventType}
                    onChange={handleChange}
                  >
                    <option value="">Select Event Category</option>
                    {eventCategories.map((category) => (
                      <option key={category.id} value={category.title}>{category.title}</option>
                    ))}
                  </select>
                )}
                {errors.eventType && <div className="invalid-feedback">{errors.eventType}</div>}
                {formData.eventType && (
                  <small className="text-muted">
                    {eventCategories.find(cat => cat.title === formData.eventType)?.description || 'Create an event in this category'}
                  </small>
                )}
              </div>
              
              <div className="mb-3">
                <label htmlFor="description" className="form-label">Description</label>
                <textarea
                  className="form-control"
                  id="description"
                  name="description"
                  rows="4"
                  value={formData.description}
                  onChange={handleChange}
                  placeholder="Describe your event"
                ></textarea>
              </div>
              
              <div className="mb-3">
                <label className="form-label">Event Image</label>
                <div className="d-flex align-items-center">
                  <button
                    type="button"
                    className="btn btn-outline-secondary me-2"
                    onClick={() => document.getElementById('eventImageInput').click()}
                  >
                    <FaImage className="me-2" /> Choose Image
                  </button>
                  <small className="text-muted">Recommended size: 1200x600px</small>
                </div>
                <input
                  type="file"
                  className="d-none"
                  id="eventImageInput"
                  accept="image/*"
                  onChange={handleEventImageChange}
                />
                
                {eventImagePreview && (
                  <div className="mt-3">
                    <img
                      src={eventImagePreview}
                      alt="Event preview"
                      className="img-thumbnail"
                      style={{ maxHeight: '200px' }}
                    />
                  </div>
                )}
              </div>
            </div>
          );
          break;
          
        case 2:
          content = (
            <div className="step-content">
              <h4 className="mb-4">Event Location</h4>
              
              <div className="mb-3">
                <label htmlFor="city" className="form-label">City *</label>
                <select
                  className={`form-select ${errors.city ? 'is-invalid' : ''}`}
                  id="city"
                  name="city"
                  value={formData.city}
                  onChange={handleChange}
                >
                  <option value="">Select city</option>
                  {cities.map((city, index) => (
                    <option key={index} value={city}>{city}</option>
                  ))}
                </select>
                {errors.city && <div className="invalid-feedback">{errors.city}</div>}
              </div>
              
              <div className="mb-3">
                <label htmlFor="area" className="form-label">Area/Locality</label>
                <input
                  type="text"
                  className="form-control"
                  id="area"
                  name="area"
                  value={formData.area}
                  onChange={handleChange}
                  placeholder="Specify area or locality"
                />
              </div>
            </div>
          );
          break;
          
        case 3:
          content = (
            <div className="step-content">
              <h4 className="mb-4">Venue Details</h4>
              
              <div className="mb-3">
                <label htmlFor="venueName" className="form-label">Venue Name *</label>
                <input
                  type="text"
                  className={`form-control ${errors.venueName ? 'is-invalid' : ''}`}
                  id="venueName"
                  name="venueName"
                  value={formData.venueName}
                  onChange={handleChange}
                  placeholder="Enter venue name"
                />
                {errors.venueName && <div className="invalid-feedback">{errors.venueName}</div>}
              </div>
              
              <div className="mb-3">
                <label htmlFor="venueDescription" className="form-label">Venue Description</label>
                <textarea
                  className="form-control"
                  id="venueDescription"
                  name="venueDescription"
                  rows="3"
                  value={formData.venueDescription}
                  onChange={handleChange}
                  placeholder="Describe the venue"
                ></textarea>
              </div>
              
              <div className="mb-3">
                <label htmlFor="address" className="form-label">Address *</label>
                <textarea
                  className={`form-control ${errors.address ? 'is-invalid' : ''}`}
                  id="address"
                  name="address"
                  rows="2"
                  value={formData.address}
                  onChange={handleChange}
                  placeholder="Full address with landmark"
                ></textarea>
                {errors.address && <div className="invalid-feedback">{errors.address}</div>}
              </div>
              
              <div className="row mb-3">
                <div className="col-md-6">
                  <label htmlFor="capacity" className="form-label">Capacity *</label>
                  <input
                    type="text"
                    className={`form-control ${errors.capacity ? 'is-invalid' : ''}`}
                    id="capacity"
                    name="capacity"
                    value={formData.capacity}
                    onChange={handleChange}
                    placeholder="E.g., 50-200 guests"
                  />
                  {errors.capacity && <div className="invalid-feedback">{errors.capacity}</div>}
                </div>
                <div className="col-md-6">
                  <label htmlFor="price" className="form-label">Price (₹) *</label>
                  <input
                    type="text"
                    className={`form-control ${errors.price ? 'is-invalid' : ''}`}
                    id="price"
                    name="price"
                    value={formData.price}
                    onChange={handleChange}
                    placeholder="Base price"
                  />
                  {errors.price && <div className="invalid-feedback">{errors.price}</div>}
                </div>
              </div>
              
              <div className="mb-3">
                <label className="form-label">Amenities</label>
                <div className="d-flex flex-wrap gap-2">
                  {availableAmenities.map((amenity) => (
                    <button
                      key={amenity}
                      type="button"
                      className={`btn ${formData.amenities.includes(amenity) ? 'btn-primary' : 'btn-outline-secondary'}`}
                      onClick={() => handleAmenityToggle(amenity)}
                      style={formData.amenities.includes(amenity) ? {backgroundColor: "#f05537", borderColor: "#f05537"} : {}}
                    >
                      <span className="me-2">{getAmenityIcon(amenity)}</span>
                      {amenity}
                    </button>
                  ))}
                </div>
              </div>
              
              <div className="mb-3">
                <label className="form-label">Venue Images</label>
                <div className="d-flex align-items-center">
                  <button
                    type="button"
                    className="btn btn-outline-secondary me-2"
                    onClick={() => document.getElementById('venueImagesInput').click()}
                  >
                    <FaPlus className="me-2" /> Add Photos
                  </button>
                  <small className="text-muted">Upload up to 5 photos</small>
                </div>
                <input
                  type="file"
                  className="d-none"
                  id="venueImagesInput"
                  accept="image/*"
                  multiple
                  onChange={handleVenueImagesChange}
                />
                
                {venueImagePreviews.length > 0 && (
                  <div className="d-flex flex-wrap gap-2 mt-3">
                    {venueImagePreviews.map((preview, index) => (
                      <div key={index} className="position-relative">
                        <img
                          src={preview}
                          alt={`Venue image ${index + 1}`}
                          className="img-thumbnail"
                          style={{ width: '120px', height: '80px', objectFit: 'cover' }}
                        />
                        <button
                          type="button"
                          className="btn btn-sm btn-danger position-absolute top-0 end-0"
                          onClick={() => handleRemoveVenueImage(index)}
                        >
                          <FaTrash />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
              
              <div className="mb-3">
                <label htmlFor="phone" className="form-label">Contact Phone *</label>
                <input
                  type="tel"
                  className={`form-control ${errors.phone ? 'is-invalid' : ''}`}
                  id="phone"
                  name="contactInfo.phone"
                  value={formData.contactInfo.phone}
                  onChange={handleChange}
                  placeholder="Contact number"
                />
                {errors.phone && <div className="invalid-feedback">{errors.phone}</div>}
              </div>
              
              <div className="mb-3">
                <label htmlFor="email" className="form-label">Contact Email *</label>
                <input
                  type="email"
                  className={`form-control ${errors.email ? 'is-invalid' : ''}`}
                  id="email"
                  name="contactInfo.email"
                  value={formData.contactInfo.email}
                  onChange={handleChange}
                  placeholder="Email address"
                />
                {errors.email && <div className="invalid-feedback">{errors.email}</div>}
              </div>
              
              <div className="mb-3">
                <label htmlFor="website" className="form-label">Website (Optional)</label>
                <input
                  type="url"
                  className="form-control"
                  id="website"
                  name="contactInfo.website"
                  value={formData.contactInfo.website}
                  onChange={handleChange}
                  placeholder="Website URL"
                />
              </div>
            </div>
          );
          break;
          
        default:
          content = <div>Unknown step: {currentStep}</div>;
      }
    } catch (error) {
      console.error("Error rendering step content:", error);
      content = <div className="alert alert-danger">Error: {error.message}</div>;
    }
    
    return content;
  };
  
  return (
    <div className="container py-4">
      <div className="d-flex align-items-center mb-4">
        <button 
          type="button"
          className="btn btn-light me-3" 
          onClick={() => navigate('/organizer/events')}
        >
          <FaArrowLeft />
        </button>
        <h2 className="mb-0">Create New Event</h2>
      </div>
      
      {/* Debug info */}
      <div className="alert alert-info mb-3">
        Current Step: {currentStep} | Categories: {eventCategories.length}
      </div>
      
      <div className="card shadow-sm mb-4" style={{border: "1px solid #ddd"}}>
        <div className="card-body">
          {/* Progress steps */}
          <div className="mb-4">
            <div className="d-flex justify-content-between">
              <div className={`step ${currentStep >= 1 ? 'active' : ''}`}>
                <div className="step-indicator">
                  {currentStep > 1 ? <FaCheck /> : 1}
                </div>
                <div className="step-label">Event Details</div>
              </div>
              <div className={`step ${currentStep >= 2 ? 'active' : ''}`}>
                <div className="step-indicator">
                  {currentStep > 2 ? <FaCheck /> : 2}
                </div>
                <div className="step-label">Location</div>
              </div>
              <div className={`step ${currentStep >= 3 ? 'active' : ''}`}>
                <div className="step-indicator">3</div>
                <div className="step-label">Venue Details</div>
              </div>
            </div>
            <div className="progress mt-2">
              <div 
                className="progress-bar" 
                role="progressbar" 
                style={{
                  width: `${((currentStep - 1) / 2) * 100}%`,
                  backgroundColor: "#f05537"
                }}
              ></div>
            </div>
          </div>
          
          {/* Form content */}
          <form onSubmit={handleSubmit}>
            {renderStepContent()}
            
            <div className="d-flex justify-content-between mt-4">
              {currentStep > 1 ? (
                <button 
                  type="button" 
                  className="btn btn-outline-secondary" 
                  onClick={handlePrevious}
                >
                  <FaArrowLeft className="me-2" /> Back
                </button>
              ) : (
                <button 
                  type="button" 
                  className="btn btn-outline-secondary" 
                  onClick={() => navigate('/organizer/events')}
                >
                  Cancel
                </button>
              )}
              
              {currentStep < 3 ? (
                <button 
                  type="button" 
                  className="btn btn-primary" 
                  onClick={handleNext}
                  style={{backgroundColor: "#f05537", borderColor: "#f05537"}}
                >
                  Next <FaArrowRight className="ms-2" />
                </button>
              ) : (
                <button 
                  type="submit" 
                  className="btn btn-primary" 
                  disabled={loading}
                  style={{backgroundColor: "#f05537", borderColor: "#f05537"}}
                >
                  {loading ? (
                    <>
                      <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                      Saving...
                    </>
                  ) : (
                    <>
                      <FaSave className="me-2" /> Save Event
                    </>
                  )}
                </button>
              )}
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};