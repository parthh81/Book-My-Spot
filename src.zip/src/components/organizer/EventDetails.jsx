import React from 'react';
import { 
  FaCalendarAlt, 
  FaMapMarkerAlt, 
  FaUsers, 
  FaTag, 
  FaMoneyBillWave,
  FaCheck,
  FaTimes
} from 'react-icons/fa';
import { format } from 'date-fns';

const EventDetails = ({ event, onClose }) => {
  if (!event) {
    return null;
  }

  // Format date
  const formatEventDate = (date) => {
    if (!date) return 'Not scheduled';
    
    const eventDate = date instanceof Date ? date : new Date(date);
    if (isNaN(eventDate.getTime())) return 'Invalid date';
    
    return format(eventDate, 'MMMM d, yyyy');
  };

  // Format price
  const formatPrice = (price) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(price || 0);
  };

  // Status badge color
  const getStatusBadgeClass = (status) => {
    switch(status?.toLowerCase()) {
      case 'active': return 'bg-success';
      case 'draft': return 'bg-secondary';
      case 'cancelled': return 'bg-danger';
      case 'completed': return 'bg-info';
      default: return 'bg-secondary';
    }
  };

  return (
    <div className="event-details">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h3 className="mb-0">Event Details</h3>
        <button 
          type="button" 
          className="btn-close" 
          aria-label="Close" 
          onClick={onClose}
        ></button>
      </div>
      
      {event.image && (
        <div className="event-image mb-4">
          <img 
            src={event.image} 
            alt={event.name} 
            className="img-fluid rounded" 
            style={{ maxHeight: '240px', width: '100%', objectFit: 'cover' }}
          />
        </div>
      )}
      
      <div className="event-header mb-4">
        <h4 className="event-title">{event.name}</h4>
        <div className="d-flex align-items-center mt-2">
          <span className={`badge ${getStatusBadgeClass(event.status)} me-2`}>
            {event.status?.charAt(0).toUpperCase() + event.status?.slice(1) || 'Unknown'}
          </span>
          <span className="text-muted">{event.eventType || event.category}</span>
        </div>
      </div>
      
      <div className="event-info mb-4">
        <div className="row g-3">
          <div className="col-md-6">
            <div className="d-flex align-items-center">
              <FaCalendarAlt className="text-muted me-2" />
              <div>
                <div className="text-muted small">Date</div>
                <div>{formatEventDate(event.date)}</div>
              </div>
            </div>
          </div>
          
          <div className="col-md-6">
            <div className="d-flex align-items-center">
              <FaMapMarkerAlt className="text-muted me-2" />
              <div>
                <div className="text-muted small">Location</div>
                <div>{event.location || 'Not specified'}</div>
              </div>
            </div>
          </div>
          
          <div className="col-md-6">
            <div className="d-flex align-items-center">
              <FaUsers className="text-muted me-2" />
              <div>
                <div className="text-muted small">Capacity</div>
                <div>{event.capacity || 'Not specified'}</div>
              </div>
            </div>
          </div>
          
          <div className="col-md-6">
            <div className="d-flex align-items-center">
              <FaMoneyBillWave className="text-muted me-2" />
              <div>
                <div className="text-muted small">Price</div>
                <div>{formatPrice(event.price)}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {event.description && (
        <div className="event-description mb-4">
          <h5 className="mb-2">Description</h5>
          <p>{event.description}</p>
        </div>
      )}
      
      <div className="organizer-info mb-4">
        <h5 className="mb-2">Organizer Information</h5>
        <div className="card">
          <div className="card-body">
            <div className="d-flex align-items-center">
              <div className="organizer-avatar me-3">
                <div 
                  style={{
                    width: '40px',
                    height: '40px',
                    borderRadius: '50%',
                    backgroundColor: '#f05537',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    color: 'white',
                    fontWeight: 'bold'
                  }}
                >
                  {event.organizer?.name?.charAt(0) || 'O'}
                </div>
              </div>
              <div>
                <h6 className="mb-0">{event.organizer?.name || 'Event Organizer'}</h6>
                <p className="mb-0 text-muted small">{event.organizer?.email || 'No contact information'}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EventDetails; 