import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { motion, AnimatePresence } from 'framer-motion';
import { Line, Pie, Bar } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, PointElement, LineElement, BarElement, ArcElement, Title, Tooltip, Legend, Filler } from 'chart.js';
import { FaCalendarCheck, FaUsers, FaMoneyBillWave, FaCalendarAlt, FaArrowUp, FaArrowDown, FaEye, FaMapMarkerAlt } from 'react-icons/fa';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
  faCalendarAlt as faCalendarAltSolid, faMapMarkerAlt, faChartLine, faTicketAlt, 
  faUsers as faUsersSolid, faMoneyBillWave as faMoneyBillWaveSolid, faCalendarPlus, faUserPlus,
  faChevronRight, faArrowUp as faArrowUpSolid, faArrowDown as faArrowDownSolid
} from '@fortawesome/free-solid-svg-icons';
import { formatDate, formatCurrency } from '../../utils/formatters';
import EventsTable from './EventsTable';
import '../../styles/dashboard.css';

// Register Chart.js components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement, 
  ArcElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

// API base URL
const API_BASE_URL = "http://localhost:3200";

// Placeholder components for other tabs
const BookingsTable = () => (
  <div className="p-4 bg-white rounded-lg shadow">
    <h3 className="text-xl font-semibold mb-4">Bookings</h3>
    <p>Bookings management coming soon...</p>
  </div>
);

const Analytics = () => (
  <div className="p-4 bg-white rounded-lg shadow">
    <h3 className="text-xl font-semibold mb-4">Analytics</h3>
    <p>Analytics dashboard coming soon...</p>
  </div>
);

const OrganizerDashboard = () => {
  const [dashboardData, setDashboardData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [timeFilter, setTimeFilter] = useState('week');
  const navigate = useNavigate();
  
  // Sample user data
  const user = {
    name: 'Alex Johnson',
    role: 'Event Organizer',
    avatar: 'https://randomuser.me/api/portraits/men/32.jpg'
  };
  
  // Chart data
  const bookingChartData = {
      labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
      datasets: [
        {
          label: 'Bookings',
        data: [65, 70, 90, 81, 76, 85, 90, 100, 110, 105, 115, 120],
        fill: true,
        backgroundColor: 'rgba(75, 192, 192, 0.2)',
        borderColor: 'rgba(75, 192, 192, 1)',
        tension: 0.4,
      }
    ]
  };

  const eventDistributionData = {
    labels: ['Corporate', 'Wedding', 'Birthday', 'Conference', 'Others'],
      datasets: [
        {
        data: [30, 25, 15, 20, 10],
          backgroundColor: [
          'rgba(54, 162, 235, 0.8)',
          'rgba(255, 99, 132, 0.8)',
          'rgba(255, 206, 86, 0.8)',
          'rgba(75, 192, 192, 0.8)',
          'rgba(153, 102, 255, 0.8)',
        ],
        borderWidth: 1,
      }
    ]
  };

  const revenueChartData = {
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
    datasets: [
      {
        label: 'Revenue',
        data: [50000, 65000, 75000, 90000, 110000, 95000, 105000, 115000, 125000, 135000, 145000, 160000],
        backgroundColor: 'rgba(255, 159, 64, 0.8)',
      }
    ]
  };

  // Chart options
  const lineChartOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top',
      },
      title: {
        display: false,
      },
    },
    scales: {
      y: {
        beginAtZero: true,
      },
    },
    maintainAspectRatio: false,
  };

  const pieChartOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: 'right',
      },
    },
    maintainAspectRatio: false,
  };

  const barChartOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top',
      },
      title: {
        display: false,
      },
    },
    scales: {
      y: {
        beginAtZero: true,
      },
    },
    maintainAspectRatio: false,
  };

  useEffect(() => {
    // Clear any pre-loaded events
    localStorage.removeItem('organizer_events');
    
    // Simulate API call to fetch dashboard data
    setTimeout(() => {
      const mockData = {
        stats: {
          totalEvents: 0,
          totalBookings: 0,
          totalRevenue: 0,
          totalCustomers: 0,
          pendingBookings: 0,
          upcomingEvents: 0
        },
        recentBookings: [],
        upcomingEvents: []
      };

      setDashboardData(mockData);
      setLoading(false);
    }, 1000);
  }, []);

  const navigateToCreateEvent = () => {
    navigate('/organizer/create-event-flow');
  };

  const handleTabChange = (tab) => {
    setActiveTab(tab);
  };

  // Render stats section
  const renderStats = () => {
    const { stats } = dashboardData;
    
    return (
      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-card-header">
            <h3 className="stat-title">Total Events</h3>
            <div className="stat-icon">
              <FontAwesomeIcon icon={faCalendarAltSolid} />
            </div>
          </div>
          <p className="stat-value">{stats.totalEvents}</p>
          <div className="stat-change positive">
            <FontAwesomeIcon icon={faArrowUpSolid} className="stat-change-icon" />
            <span>12% from last month</span>
          </div>
        </div>
        
        <div className="stat-card success">
          <div className="stat-card-header">
            <h3 className="stat-title">Total Bookings</h3>
            <div className="stat-icon success">
              <FontAwesomeIcon icon={faTicketAlt} />
            </div>
          </div>
          <p className="stat-value">{stats.totalBookings}</p>
          <div className="stat-change positive">
            <FontAwesomeIcon icon={faArrowUpSolid} className="stat-change-icon" />
            <span>8% from last month</span>
          </div>
        </div>
        
        <div className="stat-card warning">
          <div className="stat-card-header">
            <h3 className="stat-title">Total Revenue</h3>
            <div className="stat-icon warning">
              <FontAwesomeIcon icon={faMoneyBillWaveSolid} />
            </div>
          </div>
          <p className="stat-value">₹{formatCurrency(stats.totalRevenue)}</p>
          <div className="stat-change positive">
            <FontAwesomeIcon icon={faArrowUpSolid} className="stat-change-icon" />
            <span>15% from last month</span>
          </div>
        </div>
        
        <div className="stat-card danger">
          <div className="stat-card-header">
            <h3 className="stat-title">Total Users</h3>
            <div className="stat-icon danger">
              <FontAwesomeIcon icon={faUsersSolid} />
            </div>
          </div>
          <p className="stat-value">{stats.totalCustomers}</p>
          <div className="stat-change negative">
            <FontAwesomeIcon icon={faArrowDownSolid} className="stat-change-icon" />
            <span>3% from last month</span>
          </div>
        </div>
      </div>
    );
  };

  // Render recent bookings table
  const renderRecentBookings = () => {
    if (!dashboardData) return null;
    
    return (
      <table className="recent-bookings-table">
        <thead>
          <tr>
            <th>Customer</th>
            <th>Event</th>
            <th>Date</th>
            <th>Amount</th>
            <th>Status</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {dashboardData.recentBookings.map((booking) => (
            <tr key={booking.id}>
              <td>
                <div className="booking-customer">
                  <div className="customer-avatar">
                    {booking.customerInitials}
                  </div>
                  <span className="customer-name">{booking.customerName}</span>
                </div>
              </td>
              <td>
                <span className="event-name">{booking.eventName}</span>
              </td>
              <td>{formatDate(booking.bookingDate)}</td>
              <td className="booking-amount">₹{formatCurrency(booking.amount)}</td>
              <td>
                <span className={`booking-status ${booking.status}`}>
                  {booking.status}
                </span>
              </td>
              <td>
                <div className="action-dropdown">
                  <button className="action-btn">
                    <FontAwesomeIcon icon={faChevronRight} />
                  </button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    );
  };

  // Render upcoming events section
  const renderUpcomingEvents = () => {
    if (!dashboardData) return null;
    
    return (
      <div className="upcoming-events-grid">
        {dashboardData.upcomingEvents.map((event) => (
            <div key={event.id} className="event-card">
              <div className="position-relative">
                <img 
                  src={event.imageUrl} 
                  alt={event.name} 
                  className="event-card-image" 
                  onError={(e) => {
                    e.target.onerror = null;
                    e.target.src = 'https://images.unsplash.com/photo-1492684223066-81342ee5ff30?w=600&auto=format&fit=crop';
                  }}
                />
                <div className="position-absolute top-0 start-0 m-2">
                  <span className="badge bg-primary event-card-tag">{event.eventType}</span>
                </div>
              </div>
              
              <div className="event-card-content">
                <h3 className="event-card-title">{event.name}</h3>
                
                <div className="event-card-info">
                  <div className="event-card-date">
                    <FaCalendarAlt className="icon" />
                    <div className="info-text">
                      {formatDate(event.date)}
                    </div>
                  </div>
                  <div className="event-card-location">
                    <FaMapMarkerAlt className="icon" />
                    <div className="info-text">
                      {event.location}
                    </div>
                  </div>
                </div>
                
                <div className="d-flex justify-content-between align-items-center mt-auto">
                  <Link 
                    to={`/organizer/events/${event.id}`} 
                    className="btn btn-sm btn-outline-primary"
                  >
                    <FaEye className="me-1" /> View Details
                  </Link>
                </div>
              </div>
            </div>
          )
        )}
      </div>
    );
  };

  // Loading state
  if (loading) {
    return (
      <div className="organizer-loading">
        <div className="organizer-spinner"></div>
        <p>Loading dashboard data...</p>
        </div>
    );
  }
  
  // Error state
  if (error) {
    return (
      <div className="organizer-empty-state">
        <div className="organizer-empty-icon">⚠️</div>
        <h2>Oops! Something went wrong</h2>
        <p>{error}</p>
        <button className="organizer-btn organizer-btn-primary" onClick={() => window.location.reload()}>
          Try Again
        </button>
      </div>
    );
  }
  
  return (
    <div className="organizer-dashboard-container">
      {/* Dashboard Content */}
      <div className="dashboard-tabs-container">
        <div className="tabs-header">
          <button
            className={`tab-button ${activeTab === 'dashboard' ? 'active' : ''}`}
            onClick={() => handleTabChange('dashboard')}
          >
            Dashboard
          </button>
          <button
            className={`tab-button ${activeTab === 'events' ? 'active' : ''}`}
            onClick={() => handleTabChange('events')}
          >
            Events
          </button>
          <button
            className={`tab-button ${activeTab === 'bookings' ? 'active' : ''}`}
            onClick={() => handleTabChange('bookings')}
          >
            Bookings
          </button>
          <button
            className={`tab-button ${activeTab === 'analytics' ? 'active' : ''}`}
            onClick={() => handleTabChange('analytics')}
          >
            Analytics
          </button>
          <div className="tabs-actions">
            <button 
              className="btn btn-primary create-event-btn"
              onClick={navigateToCreateEvent}
              style={{backgroundColor: "#f05537", borderColor: "#f05537"}}
            >
              <i className="fas fa-plus me-2"></i> Create Event
            </button>
          </div>
        </div>

        {/* Tab content */}
        <div className="tab-content">
          {activeTab === 'dashboard' && (
            <div className="dashboard-overview">
              <h2 className="section-title mb-4">Dashboard Overview</h2>
              {renderStats()}
              
              <div className="row mt-4">
                <div className="col-md-7">
                  <div className="card mb-4">
                    <div className="card-header d-flex justify-content-between align-items-center">
                      <h3 className="card-title mb-0">Recent Bookings</h3>
                      <button 
                        className="btn btn-sm btn-outline-primary" 
                        onClick={() => handleTabChange('bookings')}
                      >
                        View All
                      </button>
                    </div>
                    <div className="card-body">
                      {renderRecentBookings()}
                    </div>
                  </div>
                </div>
                
                <div className="col-md-5">
                  <div className="card mb-4">
                    <div className="card-header d-flex justify-content-between align-items-center">
                      <h3 className="card-title mb-0">Upcoming Events</h3>
                      <button 
                        className="btn btn-sm btn-outline-primary" 
                        onClick={() => handleTabChange('events')}
                      >
                        View All
                      </button>
                    </div>
                    <div className="card-body">
                      {renderUpcomingEvents()}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
          {activeTab === 'events' && <EventsTable />}
          {activeTab === 'bookings' && <BookingsTable />}
          {activeTab === 'analytics' && <Analytics />}
        </div>
      </div>
    </div>
  );
};

export default OrganizerDashboard; 