import React, { useState, useEffect } from 'react';
import { 
  FaCalendarAlt, 
  FaMapMarkerAlt, 
  FaUsers, 
  FaMoneyBillWave, 
  FaTimes 
} from 'react-icons/fa';
import EventService from '../../services/EventService';

const EventForm = ({ event, onSave, onCancel }) => {
  const initialFormData = {
    name: '',
    description: '',
    eventType: '',
    location: '',
    date: '',
    capacity: '',
    price: '',
    status: 'active',
    image: ''
  };

  const [formData, setFormData] = useState(initialFormData);
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});

  // Event categories
  const eventTypes = [
    'Wedding',
    'Corporate Event',
    'Birthday Party',
    'Anniversary',
    'Conference',
    'Exhibition',
    'Concert',
    'Other'
  ];

  // Statuses
  const statuses = [
    'active',
    'draft',
    'cancelled',
    'completed'
  ];

  useEffect(() => {
    // If event is provided, use it to initialize form
    if (event) {
      setFormData({
        name: event.name || '',
        description: event.description || '',
        eventType: event.eventType || event.category || '',
        location: event.location || '',
        date: event.date ? formatDateForInput(event.date) : '',
        capacity: event.capacity || '',
        price: event.price || '',
        status: event.status || 'active',
        image: event.image || ''
      });
    }
  }, [event]);

  const formatDateForInput = (date) => {
    if (!date) return '';
    
    const d = date instanceof Date ? date : new Date(date);
    if (isNaN(d.getTime())) return '';
    
    return d.toISOString().split('T')[0];
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData(prev => ({
          ...prev,
          image: reader.result
        }));
      };
      reader.readAsDataURL(file);
    }
  };

  const validateForm = () => {
    const newErrors = {};
    
    if (!formData.name.trim()) newErrors.name = 'Event name is required';
    if (!formData.eventType) newErrors.eventType = 'Event type is required';
    if (!formData.location.trim()) newErrors.location = 'Location is required';
    if (!formData.date) newErrors.date = 'Date is required';
    if (!formData.capacity) newErrors.capacity = 'Capacity is required';
    if (!formData.price) newErrors.price = 'Price is required';
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) return;
    
    setLoading(true);
    
    try {
      // Prepare data for saving
      const eventData = {
        ...formData,
        price: parseFloat(formData.price),
        capacity: parseInt(formData.capacity)
      };
      
      if (event?._id) {
        eventData._id = event._id;
      }
      
      // Call the onSave callback with the data
      await onSave(eventData);
      
    } catch (error) {
      console.error('Error saving event:', error);
      setErrors({ submit: 'Failed to save event: ' + error.message });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="event-form-container">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h3 className="mb-0">{event?._id ? 'Edit Event' : 'Create New Event'}</h3>
        <button 
          type="button" 
          className="btn-close" 
          aria-label="Close"
          onClick={onCancel}
        ></button>
      </div>
      
      {errors.submit && (
        <div className="alert alert-danger">{errors.submit}</div>
      )}
      
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label htmlFor="name" className="form-label">Event Name *</label>
          <input
            type="text"
            className={`form-control ${errors.name ? 'is-invalid' : ''}`}
            id="name"
            name="name"
            value={formData.name}
            onChange={handleChange}
            placeholder="Enter event name"
          />
          {errors.name && <div className="invalid-feedback">{errors.name}</div>}
        </div>
        
        <div className="mb-3">
          <label htmlFor="description" className="form-label">Description</label>
          <textarea
            className="form-control"
            id="description"
            name="description"
            rows="3"
            value={formData.description}
            onChange={handleChange}
            placeholder="Describe your event"
          ></textarea>
        </div>
        
        <div className="row mb-3">
          <div className="col-md-6">
            <label htmlFor="eventType" className="form-label">Event Type *</label>
            <select
              className={`form-select ${errors.eventType ? 'is-invalid' : ''}`}
              id="eventType"
              name="eventType"
              value={formData.eventType}
              onChange={handleChange}
            >
              <option value="">Select event type</option>
              {eventTypes.map((type, index) => (
                <option key={index} value={type}>{type}</option>
              ))}
            </select>
            {errors.eventType && <div className="invalid-feedback">{errors.eventType}</div>}
          </div>
          
          <div className="col-md-6">
            <label htmlFor="status" className="form-label">Status</label>
            <select
              className="form-select"
              id="status"
              name="status"
              value={formData.status}
              onChange={handleChange}
            >
              {statuses.map((status, index) => (
                <option key={index} value={status}>{status.charAt(0).toUpperCase() + status.slice(1)}</option>
              ))}
            </select>
          </div>
        </div>
        
        <div className="mb-3">
          <label htmlFor="location" className="form-label">Location *</label>
          <div className="input-group">
            <span className="input-group-text"><FaMapMarkerAlt /></span>
            <input
              type="text"
              className={`form-control ${errors.location ? 'is-invalid' : ''}`}
              id="location"
              name="location"
              value={formData.location}
              onChange={handleChange}
              placeholder="Enter location"
            />
            {errors.location && <div className="invalid-feedback">{errors.location}</div>}
          </div>
        </div>
        
        <div className="row mb-3">
          <div className="col-md-6">
            <label htmlFor="date" className="form-label">Date *</label>
            <div className="input-group">
              <span className="input-group-text"><FaCalendarAlt /></span>
              <input
                type="date"
                className={`form-control ${errors.date ? 'is-invalid' : ''}`}
                id="date"
                name="date"
                value={formData.date}
                onChange={handleChange}
              />
              {errors.date && <div className="invalid-feedback">{errors.date}</div>}
            </div>
          </div>
          
          <div className="col-md-6">
            <label htmlFor="capacity" className="form-label">Capacity *</label>
            <div className="input-group">
              <span className="input-group-text"><FaUsers /></span>
              <input
                type="number"
                className={`form-control ${errors.capacity ? 'is-invalid' : ''}`}
                id="capacity"
                name="capacity"
                value={formData.capacity}
                onChange={handleChange}
                placeholder="Max. attendees"
              />
              {errors.capacity && <div className="invalid-feedback">{errors.capacity}</div>}
            </div>
          </div>
        </div>
        
        <div className="mb-3">
          <label htmlFor="price" className="form-label">Price (₹) *</label>
          <div className="input-group">
            <span className="input-group-text"><FaMoneyBillWave /></span>
            <input
              type="number"
              className={`form-control ${errors.price ? 'is-invalid' : ''}`}
              id="price"
              name="price"
              value={formData.price}
              onChange={handleChange}
              placeholder="Event price"
            />
            {errors.price && <div className="invalid-feedback">{errors.price}</div>}
          </div>
        </div>
        
        <div className="mb-4">
          <label className="form-label">Event Image</label>
          <div className="d-flex align-items-center">
            <input
              type="file"
              className="form-control"
              id="image"
              accept="image/*"
              onChange={handleImageChange}
            />
          </div>
          
          {formData.image && (
            <div className="mt-2">
              <img 
                src={formData.image} 
                alt="Event preview" 
                className="img-thumbnail" 
                style={{ maxHeight: '120px' }} 
              />
            </div>
          )}
        </div>
        
        <div className="d-flex justify-content-end gap-2 mt-4">
          <button 
            type="button" 
            className="btn btn-outline-secondary" 
            onClick={onCancel}
            disabled={loading}
          >
            Cancel
          </button>
          <button 
            type="submit" 
            className="btn btn-primary" 
            disabled={loading}
            style={{backgroundColor: "#f05537", borderColor: "#f05537"}}
          >
            {loading ? (
              <>
                <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                Saving...
              </>
            ) : (
              'Save Event'
            )}
          </button>
        </div>
      </form>
    </div>
  );
};

export default EventForm; 