import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import CustomerService from '../../services/CustomerService';
import '../../styles/customers.css';

const Customers = () => {
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    // Fetch customers using CustomerService
    const fetchCustomers = async () => {
      setLoading(true);
      setError(null);
      try {
        // Always use mock data as fallback
        const customersData = await CustomerService.getAllCustomers(true);
        setCustomers(customersData);
      } catch (error) {
        console.error('Error fetching customers:', error);
        setError('Unable to load customers. Please try again later.');
        setCustomers([]); // Set empty array to avoid undefined errors
      } finally {
        setLoading(false);
      }
    };

    fetchCustomers();
  }, []);

  const filteredCustomers = customers.filter(customer =>
    (customer.name?.toLowerCase() || '').includes(searchTerm.toLowerCase()) ||
    (customer.email?.toLowerCase() || '').includes(searchTerm.toLowerCase())
  );

  const handleViewDetails = (customer) => {
    setSelectedCustomer(customer);
    setShowModal(true);
  };

  // Function to safely display numerical values with appropriate formatting
  const formatCurrency = (amount) => {
    if (amount === undefined || amount === null) return '₹0';
    return `₹${parseInt(amount).toLocaleString('en-IN')}`;
  };

  const formatCount = (count) => {
    if (count === undefined || count === null) return '0';
    return count.toString();
  };

  // Group customers by first letter
  const groupedCustomers = {};
  filteredCustomers.forEach(customer => {
    const firstLetter = (customer.name?.[0] || '?').toUpperCase();
    if (!groupedCustomers[firstLetter]) {
      groupedCustomers[firstLetter] = [];
    }
    groupedCustomers[firstLetter].push(customer);
  });

  return (
    <div className="customers-container">
      <div className="customers-header">
        <h1>Customers</h1>
        <p className="text-muted">Showing all users who have registered in the system</p>
      </div>
      
      <div className="customers-content">
        <div className="search-container">
          <input
            type="text"
            className="form-control search-input"
            placeholder="Search customers by name or email..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        
        {loading ? (
          <div className="loading-container">
            <div className="spinner-border text-primary" role="status">
              <span className="visually-hidden">Loading...</span>
            </div>
          </div>
        ) : error ? (
          <div className="alert alert-warning" role="alert">
            {error}
            <button 
              className="btn btn-sm btn-primary ms-3"
              onClick={() => window.location.reload()}
            >
              Retry
            </button>
          </div>
        ) : filteredCustomers.length === 0 ? (
          <div className="no-customers">
            <p>No customers found</p>
          </div>
        ) : (
          <div className="customers-list">
            {Object.keys(groupedCustomers).sort().map(letter => (
              <div key={letter} className="customer-group">
                <h2 className="group-letter">{letter}</h2>
                {groupedCustomers[letter].map(customer => (
                  <div key={customer.id} className="customer-item">
                    <h3>{customer.name || 'Unnamed User'}</h3>
                    <p>{customer.email || 'No email'}</p>
                    <p>{customer.phone || 'No phone'}</p>
                    
                    <div className="customer-stats">
                      <p>Bookings: {formatCount(customer.totalBookings)}</p>
                      <p>Spent: {formatCurrency(customer.totalSpent)}</p>
                    </div>
                    
                    <button
                      className="btn btn-primary"
                      onClick={() => handleViewDetails(customer)}
                    >
                      View Details
                    </button>
                  </div>
                ))}
              </div>
            ))}
          </div>
        )}
      </div>

      {showModal && selectedCustomer && (
        <div className="modal show d-block" tabIndex="-1">
          <div className="modal-dialog">
            <div className="modal-content">
              <div className="modal-header">
                <h5 className="modal-title">Customer Details</h5>
                <button 
                  type="button" 
                  className="btn-close" 
                  onClick={() => setShowModal(false)}
                ></button>
              </div>
              <div className="modal-body">
                <div className="customer-details">
                  <div className="detail-group">
                    <h4>Personal Information</h4>
                    <p><strong>Name:</strong> {selectedCustomer.name || 'Not provided'}</p>
                    <p><strong>Email:</strong> {selectedCustomer.email || 'Not provided'}</p>
                    <p><strong>Phone:</strong> {selectedCustomer.phone || 'Not provided'}</p>
                  </div>
                  <div className="detail-group">
                    <h4>Booking History</h4>
                    <p><strong>Total Bookings:</strong> {formatCount(selectedCustomer.totalBookings)}</p>
                    <p><strong>Total Spent:</strong> {formatCurrency(selectedCustomer.totalSpent)}</p>
                    <p><strong>Last Booking:</strong> {selectedCustomer.lastBookingDate || 'No bookings yet'}</p>
                  </div>
                  <div className="detail-group">
                    <h4>Preferences</h4>
                    <p><strong>Favorite Event Type:</strong> {selectedCustomer.favoriteEventType || 'Not specified'}</p>
                    <p><strong>Preferred Location:</strong> {selectedCustomer.preferredLocation || 'Not specified'}</p>
                  </div>
                  {selectedCustomer.userData && (
                    <div className="detail-group">
                      <h4>Additional Information</h4>
                      <p><strong>User ID:</strong> {selectedCustomer.userData._id || selectedCustomer.id}</p>
                      <p><strong>Joined:</strong> {new Date(selectedCustomer.userData.createdAt || Date.now()).toLocaleDateString()}</p>
                      <p><strong>Role:</strong> {selectedCustomer.userData.roleId?.name || 'User'}</p>
                    </div>
                  )}
                </div>
              </div>
              <div className="modal-footer">
                <button 
                  type="button" 
                  className="btn btn-secondary" 
                  onClick={() => setShowModal(false)}
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Customers; 