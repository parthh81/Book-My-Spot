import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import axios from 'axios';
import AuthService from '../../services/AuthService';

const Profile = () => {
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    company: 'Event Management Co.',
    bio: 'Experienced event organizer with 5+ years in the industry.',
    address: '123 Event Street, New York, NY 10001'
  });

  // Load user data from AuthService
  useEffect(() => {
    const userInfo = AuthService.getUserInfo();
    setFormData(prev => ({
      ...prev,
      firstName: userInfo.firstName || '',
      lastName: userInfo.lastName || '',
      email: userInfo.email || ''
    }));
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      // Get current user info
      const userInfo = AuthService.getUserInfo();
      
      // Update AuthService with new values
      AuthService.setAuthData({
        ...userInfo,
        firstName: formData.firstName,
        lastName: formData.lastName,
        email: formData.email
      });
      
      // Here you would typically make an API call to update the profile
      console.log('Updating profile:', formData);
      setIsEditing(false);
    } catch (error) {
      console.error('Error updating profile:', error);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="organizer-profile-container"
    >
      <div className="organizer-profile-header">
        <h1>Profile Settings</h1>
        <button
          className="organizer-btn organizer-btn-primary"
          onClick={() => setIsEditing(!isEditing)}
        >
          {isEditing ? 'Cancel' : 'Edit Profile'}
        </button>
      </div>

      <div className="organizer-profile-content">
        <div className="organizer-profile-avatar">
          <div className="organizer-avatar-large">
            <span>{formData.firstName[0]}{formData.lastName[0]}</span>
          </div>
          {isEditing && (
            <button className="organizer-btn organizer-btn-secondary">
              Change Photo
            </button>
          )}
        </div>

        <form onSubmit={handleSubmit} className="organizer-profile-form">
          <div className="organizer-form-group">
            <label>First Name</label>
            <input
              type="text"
              name="firstName"
              value={formData.firstName}
              onChange={handleChange}
              disabled={!isEditing}
            />
          </div>

          <div className="organizer-form-group">
            <label>Last Name</label>
            <input
              type="text"
              name="lastName"
              value={formData.lastName}
              onChange={handleChange}
              disabled={!isEditing}
            />
          </div>

          <div className="organizer-form-group">
            <label>Email</label>
            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              disabled={!isEditing}
            />
          </div>

          <div className="organizer-form-group">
            <label>Phone</label>
            <input
              type="tel"
              name="phone"
              value={formData.phone}
              onChange={handleChange}
              disabled={!isEditing}
            />
          </div>

          <div className="organizer-form-group">
            <label>Company</label>
            <input
              type="text"
              name="company"
              value={formData.company}
              onChange={handleChange}
              disabled={!isEditing}
            />
          </div>

          <div className="organizer-form-group">
            <label>Bio</label>
            <textarea
              name="bio"
              value={formData.bio}
              onChange={handleChange}
              disabled={!isEditing}
              rows="4"
            />
          </div>

          <div className="organizer-form-group">
            <label>Address</label>
            <textarea
              name="address"
              value={formData.address}
              onChange={handleChange}
              disabled={!isEditing}
              rows="2"
            />
          </div>

          {isEditing && (
            <div className="organizer-form-actions">
              <button type="submit" className="organizer-btn organizer-btn-primary">
                Save Changes
              </button>
            </div>
          )}
        </form>
      </div>
    </motion.div>
  );
};

export default Profile; 