import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  FaSearch, FaFilter, FaEdit, FaEye, FaTrashAlt, FaCalendarAlt, 
  FaMapMarkerAlt, FaUsers, FaTicketAlt, FaPlusCircle, FaTag, FaSortAmountDown,
  FaCheckCircle, FaTimesCircle, FaExclamationCircle, FaTrash
} from 'react-icons/fa';
import EventService from '../../services/EventService';

// Sample event data
const sampleEvents = [
  {
    id: 1,
    name: 'New Year Party',
    imageUrl: 'https://images.unsplash.com/photo-1467810563316-b5476525c0f9?w=600&auto=format&fit=crop',
    date: '2023-12-31T23:00:00',
    location: 'Grand Ballroom, Hotel Imperial',
    capacity: 200,
    bookedSeats: 175,
    organizer: 'EventElite',
    organizerId: 101,
    price: 1500,
    status: 'Active',
    eventType: 'Party',
    createdAt: '2023-10-15T14:30:00'
  },
  {
    id: 2,
    name: 'Tech Conference 2024',
    imageUrl: 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=600&auto=format&fit=crop',
    date: '2024-01-15T09:00:00',
    location: 'Convention Center, Tech Park',
    capacity: 500,
    bookedSeats: 320,
    organizer: 'TechEvents',
    organizerId: 102,
    price: 3500,
    status: 'Active',
    eventType: 'Conference',
    createdAt: '2023-09-20T11:45:00'
  },
  {
    id: 3,
    name: 'Wedding Celebration',
    imageUrl: 'https://images.unsplash.com/photo-1519741497674-611481863552?w=600&auto=format&fit=crop',
    date: '2024-02-10T18:30:00',
    location: 'Garden Venue, The Greens',
    capacity: 150,
    bookedSeats: 85,
    organizer: 'WeddingWonders',
    organizerId: 103,
    price: 95000,
    status: 'Active',
    eventType: 'Wedding',
    createdAt: '2023-10-05T16:20:00'
  },
  {
    id: 4,
    name: 'College Alumni Meet',
    imageUrl: 'https://images.unsplash.com/photo-1523580494863-6f3031224c94?w=600&auto=format&fit=crop',
    date: '2024-02-25T16:00:00',
    location: 'University Campus, Main Hall',
    capacity: 300,
    bookedSeats: 120,
    organizer: 'AlumniConnects',
    organizerId: 104,
    price: 750,
    status: 'Active',
    eventType: 'Social',
    createdAt: '2023-11-12T09:15:00'
  },
  {
    id: 5,
    name: 'Startup Networking Mixer',
    imageUrl: 'https://images.unsplash.com/photo-1511578314322-379afb476865?auto=format&fit=crop&w=600',
    date: '2024-01-20T18:00:00',
    location: 'Innovation Hub, Downtown',
    capacity: 100,
    bookedSeats: 98,
    organizer: 'StartupCommunity',
    organizerId: 105,
    price: 1200,
    status: 'Active',
    eventType: 'Networking',
    createdAt: '2023-10-25T10:30:00'
  },
  {
    id: 6,
    name: 'Indian Classical Music Concert',
    imageUrl: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=600',
    date: '2024-03-05T19:00:00',
    location: 'Cultural Center Auditorium',
    capacity: 250,
    bookedSeats: 75,
    organizer: 'MusicMagic',
    organizerId: 106,
    price: 850,
    status: 'Pending Approval',
    eventType: 'Concert',
    createdAt: '2023-12-01T14:10:00'
  }
];

const AdminEventManagement = () => {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [typeFilter, setTypeFilter] = useState('all');
  const [sortBy, setSortBy] = useState('date-asc');
  const [viewMode, setViewMode] = useState('grid');

  // Fetch events on component mount
  useEffect(() => {
    // Simulate API call
    setTimeout(() => {
      setEvents(sampleEvents);
      setLoading(false);
    }, 1000);
  }, []);

  // Filter and sort events
  const getFilteredAndSortedEvents = () => {
    return events
      .filter(event => {
        // Status filter
        if (statusFilter !== 'all' && event.status !== statusFilter) {
          return false;
        }
        
        // Type filter
        if (typeFilter !== 'all' && event.eventType !== typeFilter) {
          return false;
        }
        
        // Search term filter
        if (searchTerm) {
          const term = searchTerm.toLowerCase();
          return (
            event.name.toLowerCase().includes(term) ||
            event.organizer.toLowerCase().includes(term) ||
            event.location.toLowerCase().includes(term) ||
            event.eventType.toLowerCase().includes(term)
          );
        }
        
        return true;
      })
      .sort((a, b) => {
        // Sort by selected criteria
        switch (sortBy) {
          case 'date-asc':
            return new Date(a.date) - new Date(b.date);
          case 'date-desc':
            return new Date(b.date) - new Date(a.date);
          case 'name-asc':
            return a.name.localeCompare(b.name);
          case 'name-desc':
            return b.name.localeCompare(a.name);
          case 'price-asc':
            return a.price - b.price;
          case 'price-desc':
            return b.price - a.price;
          case 'capacity-asc':
            return a.capacity - b.capacity;
          case 'capacity-desc':
            return b.capacity - a.capacity;
          default:
            return 0;
        }
      });
  };

  // Format date for display
  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-IN', {
      day: 'numeric',
      month: 'short',
      year: 'numeric'
    });
  };

  // Format time for display
  const formatTime = (dateString) => {
    return new Date(dateString).toLocaleTimeString('en-IN', {
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  // Format currency
  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(amount);
  };

  // Calculate capacity percentage
  const calculateCapacityPercentage = (booked, total) => {
    return Math.round((booked / total) * 100);
  };

  // Get status badge properties
  const getStatusBadge = (status) => {
    switch (status) {
      case 'Active':
        return { icon: <FaCheckCircle />, class: 'bg-success' };
      case 'Pending Approval':
        return { icon: <FaExclamationCircle />, class: 'bg-warning text-dark' };
      case 'Cancelled':
        return { icon: <FaTimesCircle />, class: 'bg-danger' };
      default:
        return { icon: <FaExclamationCircle />, class: 'bg-secondary' };
    }
  };

  // Handle search
  const handleSearchChange = (e) => {
    setSearchTerm(e.target.value);
  };

  // Handle status filter change
  const handleStatusFilterChange = (e) => {
    setStatusFilter(e.target.value);
  };

  // Handle type filter change
  const handleTypeFilterChange = (e) => {
    setTypeFilter(e.target.value);
  };

  // Handle sort change
  const handleSortChange = (e) => {
    setSortBy(e.target.value);
  };

  // Handle view mode change
  const handleViewModeChange = (mode) => {
    setViewMode(mode);
  };

  // Add function to handle clearing all events
  const handleClearAllEvents = async () => {
    if (window.confirm("Are you sure you want to remove ALL sample data? This action cannot be undone.")) {
      try {
        setLoading(true);
        await EventService.deleteAllEvents();
        alert("All sample events have been successfully removed");
        
        // Refresh the events list (will be empty now)
        setEvents([]);
      } catch (error) {
        console.error("Error removing sample data:", error);
        
        if (error.response && error.response.status === 403) {
          alert("Permission denied: Only admins can delete all events.");
        } else {
          alert("Error removing sample data: " + (error.message || "Unknown error"));
        }
      } finally {
        setLoading(false);
      }
    }
  };

  // Render grid view of events
  const renderGridView = () => {
    const filteredEvents = getFilteredAndSortedEvents();
    
    if (filteredEvents.length === 0) {
      return (
        <div className="text-center py-5">
          <FaCalendarAlt className="text-muted mb-3" style={{ fontSize: '3rem' }} />
          <h4>No events found</h4>
          <p className="text-muted">Try adjusting your filters or search term.</p>
        </div>
      );
    }
    
    return (
      <div className="row g-4">
        {filteredEvents.map(event => {
          const capacityPercentage = calculateCapacityPercentage(event.bookedSeats, event.capacity);
          const statusBadge = getStatusBadge(event.status);
          
          return (
            <div className="col-md-6 col-lg-4" key={event.id}>
              <div className="card h-100 border-0 shadow-sm event-card">
                <div className="position-relative">
                  <img 
                    src={event.imageUrl} 
                    className="card-img-top event-card-image" 
                    alt={event.name} 
                    style={{ height: "180px", objectFit: "cover" }}
                    onError={(e) => {
                      e.target.onerror = null;
                      e.target.src = 'https://images.unsplash.com/photo-1492684223066-81342ee5ff30?w=600&auto=format&fit=crop';
                    }}
                  />
                  <div className="position-absolute top-0 end-0 m-2">
                    <span className={`badge ${statusBadge.class} d-flex align-items-center gap-1`}>
                      {statusBadge.icon} {event.status}
                    </span>
                  </div>
                  <div className="position-absolute top-0 start-0 m-2">
                    <span className="badge bg-primary event-card-tag">{event.eventType}</span>
                  </div>
                </div>
                <div className="card-body event-card-content">
                  <h5 className="card-title event-card-title">{event.name}</h5>
                  
                  <div className="event-card-info">
                    <div className="event-card-date">
                      <FaCalendarAlt className="text-primary icon" />
                      <div className="info-text">{formatDate(event.date)} at {formatTime(event.date)}</div>
                    </div>
                    <div className="event-card-location">
                      <FaMapMarkerAlt className="text-muted icon" />
                      <div className="info-text">{event.location}</div>
                    </div>
                  </div>
                  
                  <div className="d-flex justify-content-between align-items-center mb-2">
                    <span className="text-muted">Organized by:</span>
                    <Link to={`/admin/organizers/${event.organizerId}`} className="text-decoration-none">
                      {event.organizer}
                    </Link>
                  </div>
                  
                  <div className="event-card-capacity mb-3">
                    <div className="d-flex justify-content-between align-items-center mb-1">
                      <span>Capacity</span>
                      <small>{event.bookedSeats}/{event.capacity} ({capacityPercentage}%)</small>
                    </div>
                    <div className="capacity-bar">
                      <div 
                        className="capacity-progress" 
                        style={{ 
                          width: `${capacityPercentage}%`,
                          backgroundColor: capacityPercentage > 85 ? '#dc3545' : capacityPercentage > 60 ? '#ffc107' : '#28a745'
                        }}
                      ></div>
                    </div>
                  </div>
                  
                  <div className="d-flex justify-content-between align-items-center mt-auto">
                    <span className="fs-5 fw-bold text-primary">{formatCurrency(event.price)}</span>
                    <div className="event-card-actions">
                      <Link to={`/admin/events/${event.id}`} className="btn btn-sm btn-outline-primary me-1">
                        <FaEye className="me-1" /> View
                      </Link>
                      <Link to={`/admin/events/edit/${event.id}`} className="btn btn-sm btn-outline-secondary">
                        <FaEdit className="me-1" /> Edit
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    );
  };

  // Render table view of events
  const renderTableView = () => {
    const filteredEvents = getFilteredAndSortedEvents();
    
    if (filteredEvents.length === 0) {
      return (
        <div className="text-center py-5">
          <FaCalendarAlt className="text-muted mb-3" style={{ fontSize: '3rem' }} />
          <h4>No events found</h4>
          <p className="text-muted">Try adjusting your filters or search term.</p>
        </div>
      );
    }
    
    return (
      <div className="table-responsive">
        <table className="table table-hover align-middle">
          <thead className="table-light">
            <tr>
              <th>Name</th>
              <th>Date & Time</th>
              <th>Location</th>
              <th>Organizer</th>
              <th>Capacity</th>
              <th>Price</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredEvents.map(event => {
              const capacityPercentage = calculateCapacityPercentage(event.bookedSeats, event.capacity);
              const statusBadge = getStatusBadge(event.status);
              
              return (
                <tr key={event.id}>
                  <td>
                    <div className="d-flex align-items-center">
                      <img 
                        src={event.imageUrl} 
                        alt={event.name}
                        className="me-2 rounded"
                        style={{ width: '40px', height: '40px', objectFit: 'cover' }}
                        onError={(e) => {
                          e.target.onerror = null;
                          e.target.src = 'https://images.unsplash.com/photo-1492684223066-81342ee5ff30?w=600&auto=format&fit=crop';
                        }}
                      />
                      <div>
                        <div>{event.name}</div>
                        <small className="badge bg-primary">{event.eventType}</small>
                      </div>
                    </div>
                  </td>
                  <td>{formatDate(event.date)}<br /><small className="text-muted">{formatTime(event.date)}</small></td>
                  <td>{event.location}</td>
                  <td>
                    <Link to={`/admin/organizers/${event.organizerId}`} className="text-decoration-none">
                      {event.organizer}
                    </Link>
                  </td>
                  <td>
                    <div className="d-flex flex-column">
                      <small>{event.bookedSeats}/{event.capacity} ({capacityPercentage}%)</small>
                      <div className="progress" style={{ height: '6px' }}>
                        <div 
                          className={`progress-bar ${capacityPercentage > 85 ? 'bg-danger' : capacityPercentage > 60 ? 'bg-warning' : 'bg-success'}`} 
                          style={{ width: `${capacityPercentage}%` }}
                        ></div>
                      </div>
                    </div>
                  </td>
                  <td>{formatCurrency(event.price)}</td>
                  <td>
                    <span className={`badge ${statusBadge.class} d-flex align-items-center gap-1`}>
                      {statusBadge.icon} {event.status}
                    </span>
                  </td>
                  <td>
                    <div className="d-flex gap-1">
                      <Link to={`/admin/events/${event.id}`} className="btn btn-sm btn-outline-primary">
                        <FaEye />
                      </Link>
                      <Link to={`/admin/events/edit/${event.id}`} className="btn btn-sm btn-outline-secondary">
                        <FaEdit />
                      </Link>
                      <button className="btn btn-sm btn-outline-danger">
                        <FaTrashAlt />
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    );
  };

  if (loading) {
    return (
      <div className="d-flex justify-content-center align-items-center p-5">
        <div className="spinner-border text-primary" role="status">
          <span className="visually-hidden">Loading...</span>
        </div>
      </div>
    );
  }

  // Get unique event types for filter
  const eventTypes = ['all', ...new Set(events.map(event => event.eventType))];

  return (
    <div className="container-fluid py-4">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2 className="mb-0">Event Management</h2>
        <div className="d-flex gap-2">
          <button 
            className="btn btn-outline-danger" 
            onClick={handleClearAllEvents}
          >
            <FaTrash className="me-2" /> Remove All Sample Data
          </button>
          <Link to="/admin/events/add" className="btn btn-primary" style={{backgroundColor: "#f05537", borderColor: "#f05537"}}>
            <FaPlusCircle className="me-2" /> Add New Event
          </Link>
        </div>
      </div>

      {/* Filters and Search */}
      <div className="card border-0 shadow-sm mb-4">
        <div className="card-body">
          <div className="row g-3">
            <div className="col-md-4">
              <div className="input-group">
                <span className="input-group-text bg-white">
                  <FaSearch className="text-muted" />
                </span>
                <input 
                  type="text" 
                  className="form-control border-start-0" 
                  placeholder="Search events..." 
                  value={searchTerm}
                  onChange={handleSearchChange}
                />
              </div>
            </div>
            <div className="col-md-2">
              <select 
                className="form-select" 
                value={statusFilter}
                onChange={handleStatusFilterChange}
              >
                <option value="all">All Status</option>
                <option value="Active">Active</option>
                <option value="Pending Approval">Pending Approval</option>
                <option value="Cancelled">Cancelled</option>
              </select>
            </div>
            <div className="col-md-2">
              <select 
                className="form-select"
                value={typeFilter}
                onChange={handleTypeFilterChange}
              >
                {eventTypes.map(type => (
                  <option key={type} value={type}>
                    {type === 'all' ? 'All Types' : type}
                  </option>
                ))}
              </select>
            </div>
            <div className="col-md-2">
              <select 
                className="form-select"
                value={sortBy}
                onChange={handleSortChange}
              >
                <option value="date-asc">Date: Earliest first</option>
                <option value="date-desc">Date: Latest first</option>
                <option value="name-asc">Name: A-Z</option>
                <option value="name-desc">Name: Z-A</option>
                <option value="price-asc">Price: Low to High</option>
                <option value="price-desc">Price: High to Low</option>
                <option value="capacity-asc">Capacity: Low to High</option>
                <option value="capacity-desc">Capacity: High to Low</option>
              </select>
            </div>
            <div className="col-md-2">
              <div className="btn-group w-100">
                <button 
                  className={`btn ${viewMode === 'grid' ? 'btn-primary' : 'btn-outline-primary'}`}
                  onClick={() => handleViewModeChange('grid')}
                  style={{backgroundColor: viewMode === 'grid' ? '#f05537' : 'transparent', borderColor: '#f05537', color: viewMode === 'grid' ? 'white' : '#f05537'}}
                >
                  <i className="fas fa-th"></i> Grid
                </button>
                <button 
                  className={`btn ${viewMode === 'table' ? 'btn-primary' : 'btn-outline-primary'}`}
                  onClick={() => handleViewModeChange('table')}
                  style={{backgroundColor: viewMode === 'table' ? '#f05537' : 'transparent', borderColor: '#f05537', color: viewMode === 'table' ? 'white' : '#f05537'}}
                >
                  <i className="fas fa-list"></i> Table
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Row */}
      <div className="row g-3 mb-4">
        <div className="col-md-3">
          <div className="card border-0 shadow-sm">
            <div className="card-body d-flex align-items-center">
              <div className="rounded-circle p-3 bg-primary bg-opacity-10 me-3">
                <FaCalendarAlt className="text-primary" />
              </div>
              <div>
                <h6 className="text-muted mb-1">Total Events</h6>
                <h4 className="mb-0">{events.length}</h4>
              </div>
            </div>
          </div>
        </div>
        <div className="col-md-3">
          <div className="card border-0 shadow-sm">
            <div className="card-body d-flex align-items-center">
              <div className="rounded-circle p-3 bg-success bg-opacity-10 me-3">
                <FaCheckCircle className="text-success" />
              </div>
              <div>
                <h6 className="text-muted mb-1">Active Events</h6>
                <h4 className="mb-0">{events.filter(e => e.status === 'Active').length}</h4>
              </div>
            </div>
          </div>
        </div>
        <div className="col-md-3">
          <div className="card border-0 shadow-sm">
            <div className="card-body d-flex align-items-center">
              <div className="rounded-circle p-3 bg-warning bg-opacity-10 me-3">
                <FaExclamationCircle className="text-warning" />
              </div>
              <div>
                <h6 className="text-muted mb-1">Pending Approval</h6>
                <h4 className="mb-0">{events.filter(e => e.status === 'Pending Approval').length}</h4>
              </div>
            </div>
          </div>
        </div>
        <div className="col-md-3">
          <div className="card border-0 shadow-sm">
            <div className="card-body d-flex align-items-center">
              <div className="rounded-circle p-3 bg-danger bg-opacity-10 me-3">
                <FaTicketAlt className="text-danger" />
              </div>
              <div>
                <h6 className="text-muted mb-1">Total Bookings</h6>
                <h4 className="mb-0">{events.reduce((total, event) => total + event.bookedSeats, 0)}</h4>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Events List */}
      <div className="card border-0 shadow-sm">
        <div className="card-header bg-white d-flex justify-content-between align-items-center py-3">
          <h5 className="mb-0">
            <FaCalendarAlt className="me-2" />
            {typeFilter === 'all' ? 'All Events' : `${typeFilter} Events`}
            {statusFilter !== 'all' && ` - ${statusFilter}`}
          </h5>
          <div className="d-flex align-items-center">
            <FaSortAmountDown className="me-2 text-muted" />
            <span className="text-muted small">
              {getFilteredAndSortedEvents().length} {getFilteredAndSortedEvents().length === 1 ? 'event' : 'events'} found
            </span>
          </div>
        </div>
        <div className="card-body">
          {viewMode === 'grid' ? renderGridView() : renderTableView()}
        </div>
      </div>
    </div>
  );
};

export default AdminEventManagement; 