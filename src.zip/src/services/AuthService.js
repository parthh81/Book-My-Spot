import { auth, db } from '../firebase';
import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  sendPasswordResetEmail,
  updateProfile,
  onAuthStateChanged
} from 'firebase/auth';
import { 
  doc, 
  setDoc, 
  getDoc, 
  updateDoc, 
  serverTimestamp 
} from 'firebase/firestore';

/**
 * AuthService provides methods for authentication and user management
 */
class AuthService {
  /**
   * Log in a user with email and password
   * @param {string} email - User email
   * @param {string} password - User password
   * @returns {Promise<Object>} The authenticated user
   */
  static async login(email, password) {
    try {
      // Authenticate with Firebase
      const result = await signInWithEmailAndPassword(auth, email, password);
      const user = result.user;
      
      // Get additional user data from Firestore
      const userDoc = await getDoc(doc(db, 'users', user.uid));
      let userData = user;
      
      if (userDoc.exists()) {
        userData = {
          ...user,
          ...userDoc.data()
        };
        
        // Store user data in session storage
        sessionStorage.setItem('user', JSON.stringify({
          uid: user.uid,
          email: user.email,
          name: userData.name || user.displayName,
          role: userData.role || 'user',
          _id: user.uid
        }));
      } else {
        // Create a user document if it doesn't exist
        await setDoc(doc(db, 'users', user.uid), {
          email: user.email,
          name: user.displayName,
          role: 'user',
          createdAt: serverTimestamp()
        });
        
        // Store minimal user data
        sessionStorage.setItem('user', JSON.stringify({
          uid: user.uid,
          email: user.email,
          name: user.displayName,
          role: 'user',
          _id: user.uid
        }));
      }
      
      return userData;
    } catch (error) {
      console.error('Login error:', error);
      throw error;
    }
  }
  
  /**
   * Register a new user
   * @param {string} email - User email
   * @param {string} password - User password
   * @param {Object} userData - Additional user data
   * @returns {Promise<Object>} The newly created user
   */
  static async register(email, password, userData) {
    try {
      // Create user in Firebase Auth
      const result = await createUserWithEmailAndPassword(auth, email, password);
      const user = result.user;
      
      // Update display name if provided
      if (userData.name) {
        await updateProfile(user, {
          displayName: userData.name
        });
      }
      
      // Store additional data in Firestore
      await setDoc(doc(db, 'users', user.uid), {
        email: user.email,
        name: userData.name || '',
        role: userData.role || 'user',
        createdAt: serverTimestamp(),
        ...userData
      });
      
      return user;
    } catch (error) {
      console.error('Registration error:', error);
      throw error;
    }
  }
  
  /**
   * Log out the current user
   */
  static async logout() {
    try {
      await signOut(auth);
      sessionStorage.removeItem('user');
      sessionStorage.removeItem('token');
      return true;
    } catch (error) {
      console.error('Logout error:', error);
      throw error;
    }
  }
  
  /**
   * Send a password reset email
   * @param {string} email - User email
   * @returns {Promise<boolean>} Success status
   */
  static async resetPassword(email) {
    try {
      await sendPasswordResetEmail(auth, email);
      return true;
    } catch (error) {
      console.error('Password reset error:', error);
      throw error;
    }
  }
  
  /**
   * Get current user info from session storage
   * @returns {Object|null} User info or null if not logged in
   */
  static getUserInfo() {
    const userStr = sessionStorage.getItem('user');
    return userStr ? JSON.parse(userStr) : null;
  }
  
  /**
   * Get auth token of the current user
   * @returns {string|null} JWT token or null if not logged in
   */
  static getToken() {
    return sessionStorage.getItem('token');
  }
  
  /**
   * Check if user is authenticated
   * @returns {boolean} True if authenticated, false otherwise
   */
  static isAuthenticated() {
    return !!this.getUserInfo();
  }
  
  /**
   * Validate the current token
   * @returns {Promise<boolean>} True if token is valid
   */
  static async validateToken() {
    try {
      // With Firebase, we rely on the auth state listener
      // This is a placeholder that always returns true if we have a user
      return !!auth.currentUser;
    } catch (error) {
      console.error('Token validation error:', error);
      return false;
    }
  }
  
  /**
   * Update user profile
   * @param {Object} userData - User data to update
   * @returns {Promise<Object>} Updated user data
   */
  static async updateUserProfile(userData) {
    try {
      const user = auth.currentUser;
      
      if (!user) {
        throw new Error('No authenticated user');
      }
      
      // Update display name if provided
      if (userData.name) {
        await updateProfile(user, {
          displayName: userData.name
        });
      }
      
      // Update data in Firestore
      const userRef = doc(db, 'users', user.uid);
      await updateDoc(userRef, {
        ...userData,
        updatedAt: serverTimestamp()
      });
      
      // Get the updated document
      const updatedDoc = await getDoc(userRef);
      const updatedData = updatedDoc.data();
      
      // Update session storage
      const currentUser = this.getUserInfo();
      if (currentUser) {
        sessionStorage.setItem('user', JSON.stringify({
          ...currentUser,
          name: userData.name || currentUser.name,
          ...userData
        }));
      }
      
      return updatedData;
    } catch (error) {
      console.error('Profile update error:', error);
      throw error;
    }
  }
  
  /**
   * Set authentication data manually in session storage.
   * This function is added to support manually setting auth data (used in testing or custom flows).
   * @param {Object} authData - The authentication data to store.
   */
  static setAuthData(authData) {
    if (authData.token) {
      sessionStorage.setItem('token', authData.token);
    }
    sessionStorage.setItem('user', JSON.stringify(authData));
  }
}

export default AuthService;
