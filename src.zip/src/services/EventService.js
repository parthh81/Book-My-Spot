import ApiService from './ApiService';
import ConfigService from './ConfigService';
import AuthService from './AuthService';
import axios from 'axios';

/**
 * EventService provides methods for interacting with event and venue related API endpoints
 */
class EventService {
  /**
   * Fetch all events from the API
   * @returns {Promise<Array>} List of events
   */
  static async getAllEvents(useMockData = true) {
    try {
      console.log('Making request to fetch all events');
      // Use ApiService instead of direct axios
      const response = await ApiService.get('/api/events');
      console.log('Events fetched successfully:', response);
      return response || [];
    } catch (error) {
      console.error('Error fetching events:', error);
      
      // Handle different types of errors with specific messages
      if (error.code === 'ERR_NETWORK' || error.message === 'Network Error') {
        console.warn('Network error detected. Backend server may not be running.');
      } else if (error.response && error.response.status === 500) {
        console.warn('Server error (500) detected. Backend may have internal issues.');
      } else if (error.response && error.response.status === 404) {
        console.warn('Not found (404) error detected. API endpoint may not exist.');
      }
      
      if (!useMockData) {
        // If mock data is not allowed, throw the error
        throw error;
      }
      
      // Return empty array as fallback
      return [];
    }
  }

  /**
   * Fetch events by category ID
   * @param {string} categoryId The category ID to filter events by
   * @returns {Promise<Array>} List of events matching the category
   */
  static async getEventsByCategory(categoryId) {
    try {
      const response = await ApiService.get(`/api/events/category/${categoryId}`);
      return response || [];
    } catch (error) {
      console.error(`Error fetching events for category ${categoryId}:`, error);
      return [];
    }
  }

  /**
   * Fetch event categories
   * @returns {Promise<Array>} List of event categories
   */
  static async getEventCategories() {
    try {
      console.log('Requesting event categories...');
      
      // Try first with the API path, then with legacy path if the first one fails
      try {
        const response = await ApiService.get('/api/categories');
        console.log('Categories fetched successfully from /api/categories:', response);
        return response || [];
      } catch (firstError) {
        console.warn('Error fetching from /api/categories, trying legacy path:', firstError.message);
        const response = await ApiService.get('/category');
        console.log('Categories fetched successfully from legacy path:', response);
        return response || [];
      }
    } catch (error) {
      console.error('Error fetching event categories (all attempts failed):', error);
      
      if (error.code === 'ERR_NETWORK' || error.message === 'Network Error') {
        console.error('Network error - is the backend running?');
        throw new Error('Could not connect to the server. Please make sure the backend server is running on port 3200.');
      }
      
      // Return empty array as fallback
      return [];
    }
  }

  /**
   * Fetch venues by event ID
   * @param {string} eventId The event ID to filter venues by
   * @returns {Promise<Array>} List of venues for this event
   */
  static async getVenuesByEvent(eventId) {
    try {
      const response = await ApiService.get(`/api/events/${eventId}/venues`);
      return response || [];
    } catch (error) {
      console.error(`Error fetching venues for event ${eventId}:`, error);
      return [];
    }
  }

  /**
   * Fetch venues by event category
   * @param {number} categoryId The category ID to filter venues by
   * @returns {Promise<Array>} List of venues for this category
   */
  static async getVenuesByCategory(categoryId) {
    try {
      console.log(`Requesting venues for category ${categoryId}...`);
      
      // Try first with the API path, then with legacy path if the first one fails
      try {
        const response = await ApiService.get(`/api/venues/event/${categoryId}`);
        console.log(`Venues fetched successfully from API path for category ${categoryId}:`, response);
        return response || [];
      } catch (firstError) {
        console.warn(`Error fetching from API path for category ${categoryId}, trying legacy path:`, firstError.message);
        const response = await ApiService.get(`/venue/event/${categoryId}`);
        console.log(`Venues fetched successfully from legacy path for category ${categoryId}:`, response);
        return response || [];
      }
    } catch (error) {
      console.error(`Error fetching venues for category ${categoryId} (all attempts failed):`, error);
      
      if (error.code === 'ERR_NETWORK' || error.message === 'Network Error') {
        console.error('Network error - is the backend running?');
        throw new Error('Could not connect to the server. Please make sure the backend server is running on port 3200.');
      }
      
      // Return empty array as fallback
      return [];
    }
  }

  /**
   * Get all venues
   * @param {boolean} useMockData - Whether to use mock data when API fails
   * @returns {Promise<Array>} List of all venues
   */
  static async getAllVenues(useMockData = true) {
    try {
      console.log('Fetching all venues');
      const response = await ApiService.get('/api/venues');
      return response || [];
    } catch (error) {
      console.error('Error fetching all venues:', error);
      
      if (!useMockData) {
        // If mock data is not allowed, throw the error
        throw error;
      }
      
      // Return fallback venues if API fails
      return [
        {
          id: 1,
          name: "Royal Grand Palace",
          description: "Elegant venue perfect for weddings and grand celebrations with magnificent decor and spacious halls",
          image: "https://images.pexels.com/photos/260922/pexels-photo-260922.jpeg?auto=compress&cs=tinysrgb&w=600&h=400",
          price: 50000,
          rating: 4.9,
          location: "Ahmedabad",
          capacity: "50-500 guests",
          amenities: ["Catering", "Decoration", "Parking", "AC"],
          category: "Banquet Hall"
        },
        {
          id: 2,
          name: "Riverside Retreat",
          description: "Beautiful waterfront venue for memorable occasions with panoramic views and serene atmosphere",
          image: "https://images.pexels.com/photos/169193/pexels-photo-169193.jpeg?auto=compress&cs=tinysrgb&w=600&h=400",
          price: 35000,
          rating: 4.7,
          location: "Mumbai",
          capacity: "100-300 guests",
          amenities: ["Catering", "Parking", "AC", "Swimming Pool"],
          category: "Outdoor"
        },
        {
          id: 3,
          name: "Garden Paradise",
          description: "Beautiful outdoor venue with lush gardens perfect for ceremonies and photography",
          image: "https://images.pexels.com/photos/1128318/pexels-photo-1128318.jpeg?auto=compress&cs=tinysrgb&w=600&h=400",
          price: 40000,
          rating: 4.6,
          location: "Bangalore",
          capacity: "100-400 guests",
          amenities: ["Catering", "Decoration", "Parking", "Power Backup"],
          category: "Garden"
        },
        {
          id: 4,
          name: "Beach View Resort",
          description: "Stunning beachfront venue for destination weddings and parties with sea views",
          image: "https://images.pexels.com/photos/338504/pexels-photo-338504.jpeg?auto=compress&cs=tinysrgb&w=600&h=400",
          price: 75000,
          rating: 4.8,
          location: "Mumbai",
          capacity: "50-250 guests",
          amenities: ["Catering", "Decoration", "Parking", "AC", "Rooms", "Swimming Pool"],
          category: "Beach"
        }
      ];
    }
  }
  
  /**
   * Get details for a specific venue
   * @param {string} venueId The venue ID
   * @returns {Promise<Object>} Venue details
   */
  static async getVenueDetails(venueId) {
    try {
      console.log(`Requesting venue details for ID: ${venueId}`);
      const response = await ApiService.get(`/api/venues/${venueId}`);
      return response || null;
    } catch (error) {
      console.error(`Error fetching venue ${venueId}:`, error);
      
      // If venue not found (404) and ID is numeric, use fallback data
      if (error.response && error.response.status === 404) {
        // Try to get a venue from the fallback data
        const fallbackVenues = [
          {
            id: 1,
            title: "Royal Grand Palace",
            description: "Elegant venue perfect for weddings and grand celebrations with magnificent decor and spacious halls",
            image: "https://images.pexels.com/photos/260922/pexels-photo-260922.jpeg?auto=compress&cs=tinysrgb&w=600&h=400",
            price: "₹50,000 onwards",
            rating: 4.9,
            location: "Ahmedabad",
            capacity: "50-500 guests",
            amenities: ["Catering", "Decoration", "Parking", "AC"]
          },
          {
            id: 2,
            title: "Riverside Retreat",
            description: "Beautiful waterfront venue for memorable occasions with panoramic views and serene atmosphere",
            image: "https://images.pexels.com/photos/169193/pexels-photo-169193.jpeg?auto=compress&cs=tinysrgb&w=600&h=400",
            price: "₹35,000 onwards",
            rating: 4.7,
            location: "Mumbai",
            capacity: "100-300 guests",
            amenities: ["Catering", "Parking", "AC", "Swimming Pool"]
          }
        ];
        
        const numericId = parseInt(venueId);
        if (!isNaN(numericId) && numericId > 0 && numericId <= fallbackVenues.length) {
          console.log(`Using fallback data for venue ID ${venueId}`);
          return fallbackVenues[numericId - 1];
        }
      }
      
      return null;
    }
  }

  /**
   * Search venues by keyword
   * @param {string} searchTerm The search keyword
   * @returns {Promise<Array>} List of venues matching the search term
   */
  static async searchVenues(searchTerm) {
    try {
      const response = await ApiService.get('/api/venues/search', { term: searchTerm });
      return response || [];
    } catch (error) {
      console.error(`Error searching venues with term "${searchTerm}":`, error);
      return [];
    }
  }

  /**
   * Filter venues by multiple criteria
   * @param {Object} filters Object containing filter criteria
   * @returns {Promise<Array>} Filtered list of venues
   */
  static async filterVenues(filters) {
    try {
      const response = await ApiService.get('/api/venues/filter', filters);
      return response || [];
    } catch (error) {
      console.error('Error filtering venues:', error);
      return [];
    }
  }
  
  /**
   * Get venues by category and location
   * @param {number} categoryId The category ID to filter venues by
   * @param {string} location The location to filter venues by (optional)
   * @returns {Promise<Array>} List of venues matching the criteria
   */
  static async getVenuesByCategoryAndLocation(categoryId, location = null) {
    try {
      const params = { categoryId };
      if (location && location !== 'All Locations') {
        params.location = location;
      }
      
      const response = await ApiService.get('/api/events/venues/filter', params);
      return response || [];
    } catch (error) {
      console.error(`Error fetching venues for category ${categoryId} and location ${location || 'any'}:`, error);
      return [];
    }
  }

  /**
   * Create a new event
   * @param {Object} eventData Event data to be saved
   * @returns {Promise<Object>} Created event data
   */
  static async createEvent(eventData) {
    try {
      // Ensure required fields are present
      const requiredFields = ['description', 'location', 'category', 'categoryId'];
      for (const field of requiredFields) {
        if (!eventData[field]) {
          console.error(`Missing required field: ${field}`);
          throw new Error(`Missing required field: ${field}`);
        }
      }
      
      // Ensure categoryId is a number
      if (typeof eventData.categoryId === 'string') {
        eventData.categoryId = parseInt(eventData.categoryId);
      }
      
      // Ensure price is a number
      if (eventData.price && typeof eventData.price === 'string') {
        eventData.price = parseInt(eventData.price);
      }
      
      // Create a direct axios request with the auth token
      const token = localStorage.getItem('token');
      const headers = token ? { Authorization: `Bearer ${token}` } : {};
      
      console.log('Sending event data to API:', eventData);
      
      // Make a direct axios request instead of using ApiService
      const response = await axios.post(`${ConfigService.getApiUrl()}/api/events`, eventData, { headers });
      return response.data || null;
    } catch (error) {
      console.error('Error creating event:', error);
      
      // Create a mock event for testing purposes
      const mockEvent = {
        _id: `event_${Date.now()}`,
        ...eventData,
        createdAt: new Date(),
        updatedAt: new Date()
      };
      
      return mockEvent;
    }
  }

  /**
   * Create a new venue
   * @param {Object} venueData Venue data to be saved
   * @returns {Promise<Object>} Created venue data
   */
  static async createVenue(venueData) {
    try {
      // Ensure price is a number
      if (venueData.price && typeof venueData.price === 'string') {
        venueData.price = parseInt(venueData.price);
      }
      
      // Ensure suitableEvents contains numbers
      if (venueData.suitableEvents && Array.isArray(venueData.suitableEvents)) {
        venueData.suitableEvents = venueData.suitableEvents.map(id => 
          typeof id === 'string' ? parseInt(id) : id
        );
      }
      
      // Use ApiService which will automatically include the auth token
      const response = await ApiService.post('/api/venues', venueData);
      return response || null;
    } catch (error) {
      console.error('Error creating venue:', error);
      throw error;
    }
  }

  /**
   * Update an existing event
   * @param {string} eventId Event ID to update
   * @param {Object} eventData Updated event data
   * @returns {Promise<Object>} Updated event data
   */
  static async updateEvent(eventId, eventData) {
    try {
      // Use ApiService which will automatically include the auth token
      const response = await ApiService.put(`/api/events/${eventId}`, eventData);
      return response || null;
    } catch (error) {
      console.error(`Error updating event ${eventId}:`, error);
      throw error;
    }
  }

  /**
   * Delete an event
   * @param {string} eventId Event ID to delete
   * @returns {Promise<Object>} Response data
   */
  static async deleteEvent(eventId) {
    try {
      // Use ApiService which will automatically include the auth token
      const response = await ApiService.delete(`/api/events/${eventId}`);
      return response || { success: true };
    } catch (error) {
      console.error(`Error deleting event ${eventId}:`, error);
      throw error;
    }
  }

  /**
   * Get pending booking requests for an organizer
   * @returns {Promise<Array>} List of pending booking requests
   */
  static async getPendingBookings() {
    try {
      const response = await ApiService.get('/booking/pending');
      return response.data || [];
    } catch (error) {
      console.error('Error fetching pending bookings:', error);
      return [];
    }
  }

  /**
   * Approve or reject a booking request
   * @param {string} bookingId Booking ID to approve/reject
   * @param {boolean} approved Whether to approve the booking
   * @param {string} reason Reason for rejection (only needed if approved is false)
   * @returns {Promise<Object>} Updated booking data
   */
  static async approveBooking(bookingId, approved, reason = '') {
    try {
      const response = await ApiService.put(`/booking/approve/${bookingId}`, {
        approved,
        reason
      });
      return response || null;
    } catch (error) {
      console.error(`Error ${approved ? 'approving' : 'rejecting'} booking ${bookingId}:`, error);
      throw error;
    }
  }

  /**
   * Delete all events (admin only)
   * @returns {Promise<Object>} Response data
   */
  static async deleteAllEvents() {
    try {
      // First clear all related data from localStorage
      localStorage.removeItem('organizer_events');
      localStorage.removeItem('events');
      localStorage.removeItem('sample_events');
      localStorage.removeItem('eventCategories');
      localStorage.removeItem('venues');
      localStorage.removeItem('selectedCategoryId');
      localStorage.removeItem('selectedCategoryTitle');
      
      // Also clear sessionStorage
      sessionStorage.removeItem('selectedCategoryId');
      sessionStorage.removeItem('selectedCategoryTitle');
      sessionStorage.removeItem('events');
      
      // Then try to use the API to delete server-side events
      try {
        // Use ApiService which will automatically include the auth token
        const response = await ApiService.delete('/api/events/admin/all');
        return response || { success: true, message: 'All events deleted successfully' };
      } catch (apiError) {
        console.warn('API request to delete all events failed:', apiError.message);
        // Return success anyway since we've cleared localStorage
        return { success: true, message: 'All events deleted from localStorage' };
      }
    } catch (error) {
      console.error('Error in deleteAllEvents:', error);
      throw error;
    }
  }

  // Helper method to check if a string looks like a MongoDB ObjectId
  static isValidObjectId(id) {
    const objectIdPattern = /^[0-9a-fA-F]{24}$/;
    return objectIdPattern.test(id);
  }

  /**
   * Fetch event by ID
   * @param {string} eventId The event ID to fetch
   * @returns {Promise<Object>} Event details
   */
  static async getEventById(eventId) {
    try {
      console.log(`Requesting event details for ID: ${eventId}`);
      
      // Try first with the API path, then with legacy path if the first one fails
      try {
        const response = await ApiService.get(`/api/events/${eventId}`);
        console.log(`Event details fetched successfully from API path for ID ${eventId}:`, response);
        
        // Process organizer data if it's an ID
        if (response && response.organizer && (typeof response.organizer === 'string') && 
            this.isValidObjectId(response.organizer)) {
          try {
            // Try to get user info from AuthService cache/storage
            const currentUser = AuthService.getUser();
            
            // If organizer ID matches current user, use current user's name
            if (currentUser && currentUser._id === response.organizer) {
              response.organizer = `${currentUser.firstName || ''} ${currentUser.lastName || ''}`.trim() || 'You';
            } else {
              // Otherwise, try to get organizer info from userId field if it's populated
              if (response.userId && response.userId.firstName) {
                response.organizer = `${response.userId.firstName || ''} ${response.userId.lastName || ''}`.trim();
              } else {
                // If no name is found, use a default name
                if (!response.organizer || response.organizer.trim().length === 0) {
                  response.organizer = 'Event Organizer';
                }
              }
            }
          } catch (err) {
            console.error('Error formatting organizer name:', err);
            response.organizer = 'Event Organizer';
          }
        }
        
        return response || null;
      } catch (firstError) {
        console.warn(`Error fetching from API path for event ${eventId}, trying legacy path:`, firstError.message);
        const response = await ApiService.get(`/event/${eventId}`);
        console.log(`Event details fetched successfully from legacy path for ID ${eventId}:`, response);
        
        // Apply the same organizer name formatting for legacy path
        if (response && response.organizer && (typeof response.organizer === 'string')) {
          if (!response.organizer || response.organizer.trim().length === 0) {
            response.organizer = 'Event Organizer';
          }
        }
        
        return response || null;
      }
    } catch (error) {
      console.error(`Error fetching event ${eventId} (all attempts failed):`, error);
      
      if (error.code === 'ERR_NETWORK' || error.message === 'Network Error') {
        console.error('Network error - is the backend running?');
        throw new Error('Could not connect to the server. Please make sure the backend server is running on port 3200.');
      }
      
      // Return null if event not found
      return null;
    }
  }

  /**
   * Book an event 
   * @param {Object} bookingData Event booking details
   * @returns {Promise<Object>} Booking response
   */
  static async bookEvent(bookingData) {
    try {
      const token = AuthService.getToken();
      
      if (!token) {
        throw new Error('Authentication required to book an event');
      }
      
      // Format the date properly - events can have different start and end dates
      let startDate, endDate;
      try {
        // Parse start date
        if (typeof bookingData.startDate === 'string') {
          startDate = new Date(bookingData.startDate);
        } else if (bookingData.startDate instanceof Date) {
          startDate = bookingData.startDate;
        } else {
          startDate = new Date(); // Fallback to current date
        }
        
        // Parse end date (same as start date for single-day events)
        if (typeof bookingData.endDate === 'string' && bookingData.endDate) {
          endDate = new Date(bookingData.endDate);
        } else if (bookingData.endDate instanceof Date) {
          endDate = bookingData.endDate;
        } else {
          endDate = startDate; // Default to start date if not specified
        }
      } catch (e) {
        console.error('Date parsing error:', e);
        startDate = new Date();
        endDate = new Date();
      }
      
      // Get number of days between start and end date
      const numberOfDays = bookingData.numberOfDays || 1;
      
      // Calculate total price based on base price and number of days
      const basePrice = bookingData.basePrice || 0;
      const totalPrice = bookingData.totalPrice || basePrice;
      
      // Prepare the data in the format the backend expects
      const formattedData = {
        userId: bookingData.userId,
        eventId: bookingData.eventId,
        venueId: bookingData.eventId || "event_venue", // Required by schema
        venueName: bookingData.eventTitle || "Event Venue", // Required by schema
        venueImage: bookingData.image || "",
        bookingDate: new Date(), // Current date as booking date
        eventDate: startDate, // Start date for the event
        endDate: endDate, // End date (might be same as start for single-day events)
        numberOfDays: numberOfDays,
        startTime: "10:00 AM", // Default time
        endTime: "01:00 PM", // Default time
        eventType: bookingData.category || "Event",
        guestCount: parseInt(bookingData.numberOfGuests) || 1,
        totalAmount: totalPrice,
        basePrice: basePrice,
        specialRequests: bookingData.additionalRequests || "",
        contactName: bookingData.name,
        contactEmail: bookingData.email,
        contactPhone: bookingData.phone,
        location: bookingData.location || ""
      };
      
      console.log('Formatted event booking data:', formattedData);
      
      // Use ApiService post method which handles auth headers
      const response = await ApiService.post('/booking/create', formattedData);
      return response;
    } catch (error) {
      console.error('Error booking event:', error);
      
      // Handle different error scenarios
      if (error.response) {
        // Server responded with error
        const errorMsg = error.response.data.message || 'Failed to book event';
        throw new Error(errorMsg);
      } else if (error.request) {
        // No response received
        throw new Error('No response from server. Please check your internet connection.');
      } else {
        // Request setup error
        throw error;
      }
    }
  }
  
  /**
   * Book a venue
   * @param {Object} bookingData Venue booking details
   * @returns {Promise<Object>} Booking response
   */
  static async bookVenue(bookingData) {
    try {
      const token = AuthService.getToken();
      
      if (!token) {
        throw new Error('Authentication required to book a venue');
      }
      
      // Format the dates properly
      let startDate, endDate;
      try {
        // Parse start date
        if (typeof bookingData.startDate === 'string') {
          startDate = new Date(bookingData.startDate);
        } else if (bookingData.startDate instanceof Date) {
          startDate = bookingData.startDate;
        } else {
          startDate = new Date(); // Fallback to current date
        }
        
        // Parse end date
        if (typeof bookingData.endDate === 'string' && bookingData.endDate) {
          endDate = new Date(bookingData.endDate);
        } else if (bookingData.endDate instanceof Date) {
          endDate = bookingData.endDate;
        } else {
          endDate = startDate; // Default to start date if not specified
        }
      } catch (e) {
        console.error('Date parsing error:', e);
        startDate = new Date();
        endDate = new Date();
      }
      
      // Get number of days between start and end date
      const numberOfDays = bookingData.numberOfDays || 1;
      
      // Calculate total price based on base price and number of days
      const basePrice = bookingData.basePrice || 0;
      const totalPrice = bookingData.totalPrice || (basePrice * numberOfDays + 999); // Add service fee
      
      // Prepare the data in the format the backend expects
      const formattedData = {
        userId: bookingData.userId,
        eventId: null, // No event for venue booking
        venueId: bookingData.venueId || "venue_id",
        venueName: bookingData.venueTitle || "Venue",
        venueImage: bookingData.image || "",
        bookingDate: new Date(), // Current date as booking date
        eventDate: startDate, // Start date for the booking
        endDate: endDate, // End date for the booking
        numberOfDays: numberOfDays,
        startTime: "10:00 AM", // Default time
        endTime: "06:00 PM", // Default time for venue
        eventType: bookingData.eventType || "Other",
        guestCount: parseInt(bookingData.numberOfGuests) || 2,
        totalAmount: totalPrice,
        basePrice: basePrice,
        serviceFee: 999, // Service fee for venue bookings
        specialRequests: bookingData.additionalRequests || "",
        contactName: bookingData.name,
        contactEmail: bookingData.email,
        contactPhone: bookingData.phone,
        location: bookingData.location || ""
      };
      
      console.log('Formatted venue booking data:', formattedData);
      
      // Use ApiService post method which handles auth headers
      const response = await ApiService.post('/booking/create', formattedData);
      return response;
    } catch (error) {
      console.error('Error booking venue:', error);
      
      // Handle different error scenarios
      if (error.response) {
        // Server responded with error
        const errorMsg = error.response.data.message || 'Failed to book venue';
        throw new Error(errorMsg);
      } else if (error.request) {
        // No response received
        throw new Error('No response from server. Please check your internet connection.');
      } else {
        // Request setup error
        throw error;
      }
    }
  }
  
  /**
   * Toggle interest in an event or venue
   * @param {string} itemId ID of the event or venue
   * @param {string} itemType Type of item ('event' or 'venue')
   * @returns {Promise<Object>} Response data
   */
  static async toggleInterest(itemId, itemType='event') {
    try {
      const token = AuthService.getToken();
      
      if (!token) {
        throw new Error('Authentication required to show interest');
      }
      
      const config = {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      };
      
      // Ensure itemType is lowercase
      const type = itemType.toLowerCase();
      const response = await axios.post(`${ConfigService.getApiUrl()}/api/interest/${type}/${itemId}`, {}, config);
      return response.data;
    } catch (error) {
      console.error(`Error toggling interest for ${itemType} ${itemId}:`, error);
      throw error;
    }
  }
  
  /**
   * Check if user is interested in an item
   * @param {string} itemId ID of the event or venue
   * @param {string} itemType Type of item ('event' or 'venue')
   * @returns {Promise<boolean>} Whether the user is interested
   */
  static async checkInterest(itemId, itemType='event') {
    try {
      const token = AuthService.getToken();
      
      if (!token) {
        return false;
      }
      
      const config = {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      };
      
      // Ensure itemType is lowercase
      const type = itemType.toLowerCase();
      const response = await axios.get(`${ConfigService.getApiUrl()}/api/interest/${type}/${itemId}/check`, config);
      return response.data.interested || false;
    } catch (error) {
      console.error(`Error checking interest for ${itemType} ${itemId}:`, error);
      return false;
    }
  }
}

export default EventService; 